"use client";

import { ComponentExample } from "@/components/component-example";
// import { CustomTextInput } from "../components/ui/custom-inputs";
import { EmployeeListTable } from "../components/employee-list-table";

import { useRouter } from "next/navigation";
import { useEffect } from "react";

export default function Page() {
  // return <ComponentExample />;
  // return <EmployeeListTable />;
  const router = useRouter();
  
  useEffect(() => {
    router.push('/login');
  }, [router]);
  
  return (
    <div>
      Redirection to login...
    </div>
  );
  // return (
  //   <input type="datetime-local" className="border border-gray-300 rounded px-2 py-1" />
  // )
}
