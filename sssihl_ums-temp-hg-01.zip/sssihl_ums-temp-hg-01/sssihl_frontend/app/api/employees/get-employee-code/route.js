import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

/**
 * GET /api/employees/get-employee-code
 * 
 * This is the "me" endpoint that fetches the current user's employee information.
 * It forwards the request to the backend which uses the JWT to identify the user
 * and returns full employee details including roles, employee code, etc.
 */

// import "@/lib/env";


export async function GET() {
    try {
        const accessToken = (await cookies()).get('accessToken')?.value;
        console.log('Get Employee Code API - Access Token:', accessToken);
        if (!accessToken) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        // Call backend endpoint that will extract user info from JWT and return employee details
        const backendUrl = process.env.EMP_LAMBDA_URL || 'http://localhost:8000';
        const response = await fetch(`${backendUrl}/employees/me`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
            },
        });


        if (!response.ok) {
            if (response.status === 404) {
                return NextResponse.json({ error: 'Employee not found' }, { status: 404 });
            }
            if (response.status === 401) {
                console.log('Unauthorized access - invalid or expired token');
                console.log('Response status:', response.status);
                console.log('Response status text:', response.statusText);
                console.log('Response headers:', response.headers);
                console.log('Response body:', await response.json());
                console.log('Access token used:', accessToken);
                console.log('Backend URL:', backendUrl);
                return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
            }
            return NextResponse.json({ error: 'Failed to fetch employee details' }, { status: response.status });
        }

        const employeeData = await response.json();

        console.log('Fetched employee data:', employeeData);
        return NextResponse.json(employeeData);

    } catch (error) {
        console.error('Error in /api/employees/get-employee-code:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
