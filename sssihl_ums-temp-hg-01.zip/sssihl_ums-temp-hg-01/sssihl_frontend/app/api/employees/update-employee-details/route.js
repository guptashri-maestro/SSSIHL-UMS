import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

// import "@/lib/env";


export async function PATCH(req) {
    try {
        const accessToken = (await cookies()).get('accessToken')?.value;

        // console.log('Update API - Access Token:', accessToken);

        if (!accessToken) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const body = await req.json();
        
        // console.log('Update API - Request Body:', body);

        const employee_code = body.employee_code;

        const backendUrl = process.env.EMP_LAMBDA_URL || 'http://localhost:8000';
        const response = await fetch(`${backendUrl}/employees/${employee_code}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`,
            },
            body: JSON.stringify(body.fields),
        });

        // const data = await response.json();

        if (!response.ok) {
            return NextResponse.json({ error: data.error || 'Failed to update employee details' }, { status: response.status });
        }

        // console.log('Update API - Response Data:', data);

        return NextResponse.json({ message: 'Employee details updated successfully' });
    } catch (error) {
        console.error('Error updating employee details:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}

// export async function POST(req) {
//     try {
//         const accessToken = (await cookies()).get('accessToken')?.value;

//         console.log('Search API - Access Token:', accessToken);

//         if (!accessToken) {
//             return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
//         }

//         const body = await req.json();

//         const response = await fetch('http://localhost:8000/employees/search', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json',
//                 'Authorization': `Bearer ${accessToken}`,
//             },
//             body: JSON.stringify(body),
//         });

//         const data = await response.json();

//         if (!response.ok) {
//             return NextResponse.json({ error: data.error || 'Failed to fetch employees' }, { status: response.status });
//         }

//         return NextResponse.json(data);
//     } catch (error) {
//         console.error('Error searching employees:', error);
//         return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
//     }
// }
