import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';

// import "@/lib/env";


export async function POST(req) {
    try {
        const accessToken = (await cookies()).get('accessToken')?.value;

        console.log('Search API - Access Token:', accessToken);
        

        if (!accessToken) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const body = await req.json();
        
        console.log('Search API - Request Body:', body);

        const backendUrl = process.env.EMP_LAMBDA_URL || 'http://localhost:8000';
        const response = await fetch(`${backendUrl}/employees/search`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${accessToken}`,
            },
            body: JSON.stringify(body),
        });

        const data = await response.json();

        if (!response.ok) {
            return NextResponse.json({ error: data.error || 'Failed to fetch employees' }, { status: response.status });
        }

        return NextResponse.json(data);
    } catch (error) {
        console.error('Error searching employees:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}
