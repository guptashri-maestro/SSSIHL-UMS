import { NextResponse } from 'next/server';
import { requireUser } from '../../lib/auth/requireUser';
import { cookies } from 'next/headers';

// import "@/lib/env";


export async function GET(req) {
    try{
        const accessToken = (await cookies()).get('accessToken')?.value;

        if (!accessToken) {
            return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
        }

        const employee_code = req.nextUrl.searchParams.get('employee_code');
        if (!employee_code) {
            return NextResponse.json({ error: 'Bad Request: Missing employee_code' }, { status: 400 });
        }

        const backendUrl = process.env.EMP_LAMBDA_URL || 'http://localhost:8000';
        const response = await fetch(`${backendUrl}/employees/get-by-code/${employee_code}`, {
            method: 'GET',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
            },
        });

        if (!response.ok) {
            return NextResponse.json({ error: 'Failed to fetch employee details' }, { status: response.status });
        }

        const employeeDetails = await response.json();
        return NextResponse.json(employeeDetails);

    }catch(error){
        console.error('Error fetching employee details:', error);
        return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
    }
}