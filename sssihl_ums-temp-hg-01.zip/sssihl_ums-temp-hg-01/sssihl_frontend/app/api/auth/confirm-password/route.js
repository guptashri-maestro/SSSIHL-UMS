import { AdminRespondToAuthChallengeCommand } from "@aws-sdk/client-cognito-identity-provider";
import { cognitoClient } from "../../../lib/cognito";
import { setAuthCookies } from "../../../lib/auth/cognitoTokens";
import { setUserSessionCookie } from "../../../lib/auth/userSession";
import { NextResponse } from "next/server";



export const runtime = "nodejs";
export const dynamic = "force-dynamic";


export async function POST(req) {
    const { username, newPassword, session } = await req.json();

    console.log("Environment variables check:");
    console.log("COGNITO_APP_CLIENT_ID:", process.env.COGNITO_APP_CLIENT_ID);
    console.log("COGNITO_USER_POOL_ID:", process.env.COGNITO_USER_POOL_ID);

    if (!process.env.COGNITO_APP_CLIENT_ID || !process.env.COGNITO_USER_POOL_ID) {
            return NextResponse.json({ error: "ENV VARIABLES ARE NOT LOADING"}, { status: 401});
        }

    const command = new AdminRespondToAuthChallengeCommand({
        ClientId: process.env.COGNITO_APP_CLIENT_ID,
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        ChallengeName: "NEW_PASSWORD_REQUIRED",
        Session: session,
        ChallengeResponses: {
            USERNAME: username,
            NEW_PASSWORD: newPassword
        },
    });

    try {
        const res = await cognitoClient.send(command);

        // Normal login flow
        const result = res.AuthenticationResult;

        if (!result?.AccessToken || !result?.IdToken) {
            return NextResponse.json({ error: "Login failed"}, { status: 401});
        }

        // Setting HTTP Cookies
        const response = NextResponse.json({ success: true})

        setAuthCookies(response, result);

        // Fetch user data from backend and cache it
        try {
            const backendUrl = process.env.EMP_LAMBDA_URL || 'http://localhost:8000';
            const userDataResponse = await fetch(`${backendUrl}/employees/me`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${result.AccessToken}`,
                },
            });

            if (userDataResponse.ok) {
                const userData = await userDataResponse.json();
                setUserSessionCookie(response, userData);
                console.log("User data cached successfully after password reset");
            } else {
                console.warn("Failed to fetch user data during password reset, will be fetched on demand");
            }
        } catch (error) {
            console.error("Error fetching user data during password reset:", error);
            // Don't fail the login if user data fetch fails, it can be fetched later
        }

        return response;
    } catch (error) {
        console.error("Error during password reset:", error);
        return NextResponse.json({ error: "Password reset failed"}, { status: 500});
    }
}