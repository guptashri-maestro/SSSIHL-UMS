import { NextResponse }from "next/server";
import {
    AdminInitiateAuthCommand,
} from "@aws-sdk/client-cognito-identity-provider";

import { cognitoClient } from "../../../lib/cognito";

import { setAuthCookies } from "../../../lib/auth/cognitoTokens";
import { setUserSessionCookie } from "../../../lib/auth/userSession";


// test change
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(req) {
    const raa = await req.json();
    const { username, password} = raa;

    console.log("CLIENT ID:", raa);

    console.log("Environment variables check:");
    console.log("COGNITO_APP_CLIENT_ID:", process.env.COGNITO_APP_CLIENT_ID);
    console.log("COGNITO_USER_POOL_ID:", process.env.COGNITO_USER_POOL_ID);

    if (!process.env.COGNITO_APP_CLIENT_ID || !process.env.COGNITO_USER_POOL_ID) {
            return NextResponse.json({ error: "ENV VARIABLES ARE NOT LOADING"}, { status: 401});
        }

    try {
        const command = new AdminInitiateAuthCommand({
        AuthFlow: "ADMIN_USER_PASSWORD_AUTH",
        ClientId: process.env.COGNITO_APP_CLIENT_ID,
        UserPoolId: process.env.COGNITO_USER_POOL_ID,
        AuthParameters: {
            USERNAME: username,
            PASSWORD: password
            }
        });

        const res = await cognitoClient.send(command);

        // Handle case when user needs to reset their password to continue
        if (res.ChallengeName === "NEW_PASSWORD_REQUIRED") {
            const baba = NextResponse.json({
                challenge: "NEW_PASSWORD_REQUIRED",
                session: res.Session,
                username
            });

            console.log("PASSWORD RESET REQUIRED:", baba);
            return baba;
        }

        // Normal login flow
        const result = res.AuthenticationResult;

        if (!result?.AccessToken || !result?.IdToken) {
            return NextResponse.json({ error: "Login failed"}, { status: 401});
        }

        // Setting HTTP Cookies
        const response = NextResponse.json({ success: true})

        setAuthCookies(response, result);

        // Fetch user data from backend and cache it
        try {
            const backendUrl = process.env.EMP_LAMBDA_URL || 'http://localhost:8000';
            const userDataResponse = await fetch(`${backendUrl}/employees/me`, {
                method: 'GET',
                headers: {
                    'Authorization': `Bearer ${result.AccessToken}`,
                },
            });

            if (userDataResponse.ok) {
                const userData = await userDataResponse.json();
                setUserSessionCookie(response, userData);
                console.log("User data cached successfully");
            } else {
                console.warn("Failed to fetch user data during login, will be fetched on demand");
            }
        } catch (error) {
            console.error("Error fetching user data during login:", error);
            // Don't fail the login if user data fetch fails, it can be fetched later
        }
        
        console.log("LOGIN SUCCESSFUL:", response);
        return response;
    } catch (error) {
        console.error("Error during login:", error);
        return NextResponse.json({ error: "Invalid Credentials"}, { status: 401});
    }

}