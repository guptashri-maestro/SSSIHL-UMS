import { NextResponse } from "next/server";

export async function POST(request) {
    const res = NextResponse.json({ success: true, message: "Logged out successfully"})

    res.cookies.set(
        "accessToken",
        "",
        {
            httpOnly: true,
            expires: new Date(0),
            path: "/",
        }
    );

    res.cookies.set(
        "refreshToken",
        "",
        {
            httpOnly: true,
            expires: new Date(0),
            path: "/",
        }
    );

    return res;
}