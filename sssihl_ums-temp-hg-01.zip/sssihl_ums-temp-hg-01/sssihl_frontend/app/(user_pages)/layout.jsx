"use client"

import  Navbar  from "../../components/navbar.jsx";

export function UserPagesLayout({ children }){
    return (
        <div>
            <Navbar />
            {children}
        </div>
    )
} 

export default UserPagesLayout;


