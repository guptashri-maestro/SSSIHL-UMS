"use client"

import { useState, useEffect } from "react"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import Stepper, { Step } from "@/components/Stepper"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"

export default function ManageEmployeesPage() {
  const [employees, setEmployees] = useState([])
  const [loading, setLoading] = useState(false)
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [pagination, setPagination] = useState({ limit: 20, offset: 0 })
  const [currentStep, setCurrentStep] = useState(1)
  const [newlyCreatedEmployee, setNewlyCreatedEmployee] = useState(null)
  const [showCredentialsDialog, setShowCredentialsDialog] = useState(false)
  const [pendingPasswordUsers, setPendingPasswordUsers] = useState([])

  // Filter tree structure - supports nested groups
  const [filterTree, setFilterTree] = useState({
    type: "group",
    logic: "and_",
    conditions: [],
    id: Date.now(),
  })

  // New employee form state
  const [newEmployee, setNewEmployee] = useState({
    employee_code: "",
    first_name: "",
    last_name: "",
    salutation: "",
    gender_code: "",
    date_of_birth_val: "",
    blood_group: "",
    official_email: "",
    personal_email: "",
    mobile_number: "",
    alternate_mobile_number: "",
    emergency_contact_name: "",
    emergency_contact_phone: "",
    designation: "",
    role_nm: "",
    department_id: "",
    unit_id: "",
    campus_id: "",
    reporting_manager_id: "",
    employee_category_code: "",
    employee_type_code: "",
    hire_date: "",
    probation_ended_dt: "",
    employment_status_code: "",
    aadhaar_no: "",
    pan_no: "",
    uan_no: "",
  })

  // Available fields for filtering
  const filterableFields = [
    { value: "employee_id", label: "Employee ID" },
    { value: "employee_code", label: "Employee Code" },
    { value: "first_name", label: "First Name" },
    { value: "last_name", label: "Last Name" },
    { value: "designation", label: "Designation" },
    { value: "department_id", label: "Department ID" },
    { value: "employment_status_code", label: "Employment Status" },
    { value: "role_nm", label: "Role" },
    { value: "hire_date", label: "Hire Date" },
    { value: "age", label: "Age" },
  ]

  // Build filter tree for backend
  const buildBackendFilterTree = (node) => {
    if (!node || (node.type === "group" && node.conditions.length === 0)) {
      return null
    }

    if (node.type === "condition") {
      return {
        field: node.field,
        operator: node.operator,
        value: node.value,
      }
    }

    if (node.type === "group") {
      const children = node.conditions
        .map(buildBackendFilterTree)
        .filter((c) => c !== null)

      if (children.length === 0) return null

      return {
        [node.logic]: children,
      }
    }

    return null
  }

  // Search employees with filters
  const searchEmployees = async () => {
    setLoading(true)
    try {
      const backendFilter = buildBackendFilterTree(filterTree)
      
      const payload = {
        filter: backendFilter ? { root: backendFilter } : null,
        pagination: pagination,
      }

      const response = await fetch("/api/employees/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(payload),
      })

      if (response.ok) {
        const data = await response.json()
        setEmployees(data)
      } else {
        console.error("Failed to fetch employees")
      }
    } catch (error) {
      console.error("Error searching employees:", error)
    } finally {
      setLoading(false)
    }
  }

  // Add condition to a group
  const addCondition = (groupId) => {
    const addToGroup = (node) => {
      if (node.id === groupId) {
        return {
          ...node,
          conditions: [
            ...node.conditions,
            {
              type: "condition",
              field: "",
              operator: "eq",
              value: "",
              id: Date.now(),
            },
          ],
        }
      }
      if (node.type === "group") {
        return {
          ...node,
          conditions: node.conditions.map(addToGroup),
        }
      }
      return node
    }
    setFilterTree(addToGroup(filterTree))
  }

  // Add nested group
  const addGroup = (parentGroupId) => {
    const addToGroup = (node) => {
      if (node.id === parentGroupId) {
        return {
          ...node,
          conditions: [
            ...node.conditions,
            {
              type: "group",
              logic: "and_",
              conditions: [],
              id: Date.now(),
            },
          ],
        }
      }
      if (node.type === "group") {
        return {
          ...node,
          conditions: node.conditions.map(addToGroup),
        }
      }
      return node
    }
    setFilterTree(addToGroup(filterTree))
  }

  // Update condition
  const updateCondition = (conditionId, field, value) => {
    const update = (node) => {
      if (node.id === conditionId) {
        return { ...node, [field]: value }
      }
      if (node.type === "group") {
        return {
          ...node,
          conditions: node.conditions.map(update),
        }
      }
      return node
    }
    setFilterTree(update(filterTree))
  }

  // Remove condition or group
  const removeNode = (nodeId) => {
    const remove = (node) => {
      if (node.type === "group") {
        return {
          ...node,
          conditions: node.conditions
            .filter((c) => c.id !== nodeId)
            .map(remove),
        }
      }
      return node
    }
    setFilterTree(remove(filterTree))
  }

  // Clear all filters
  const clearAllFilters = () => {
    setFilterTree({
      type: "group",
      logic: "and_",
      conditions: [],
      id: Date.now(),
    })
  }


  // Create new employee
  const createEmployee = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/employees/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newEmployee),
      })

      if (response.ok) {
        const data = await response.json()
        setEmployees([...employees, data])
        
        // Store cognito user info if present
        if (data.cognito_user) {
          setNewlyCreatedEmployee(data)
          setShowCredentialsDialog(true)
          
          // Add to pending password users list
          if (data.cognito_user.status === "FORCE_CHANGE_PASSWORD") {
            setPendingPasswordUsers([...pendingPasswordUsers, {
              employee_id: data.employee_id,
              name: `${data.first_name} ${data.last_name}`,
              username: data.cognito_user.username,
              email: data.official_email,
              created_at: data.created_at
            }])
          }
        }
        
        setShowCreateDialog(false)
        // Reset form
        setNewEmployee({
          employee_code: "",
          first_name: "",
          last_name: "",
          salutation: "",
          gender_code: "",
          date_of_birth_val: "",
          blood_group: "",
          official_email: "",
          personal_email: "",
          mobile_number: "",
          alternate_mobile_number: "",
          emergency_contact_name: "",
          emergency_contact_phone: "",
          designation: "",
          role_nm: "",
          department_id: "",
          unit_id: "",
          campus_id: "",
          reporting_manager_id: "",
          employee_category_code: "",
          employee_type_code: "",
          hire_date: "",
          probation_ended_dt: "",
          employment_status_code: "",
          aadhaar_no: "",
          pan_no: "",
          uan_no: "",
          reporting_manager_id: "9",
        })
      } else {
        console.error("Failed to create employee")
      }
    } catch (error) {
      console.error("Error creating employee:", error)
    } finally {
      setLoading(false)
    }
  }

  // Render filter node (recursive for nested groups)
  const renderFilterNode = (node, depth = 0) => {
    if (node.type === "condition") {
      return (
        <div
          key={node.id}
          className="flex items-center gap-2 p-3 bg-muted/30 rounded-lg"
          style={{ marginLeft: `${depth * 20}px` }}
        >
          <Select
            value={node.field}
            onValueChange={(value) => updateCondition(node.id, "field", value)}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Select field" />
            </SelectTrigger>
            <SelectContent>
              {filterableFields.map((field) => (
                <SelectItem key={field.value} value={field.value}>
                  {field.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={node.operator}
            onValueChange={(value) => updateCondition(node.id, "operator", value)}
          >
            <SelectTrigger className="w-[120px]">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="eq">Equals</SelectItem>
              <SelectItem value="contains">Contains</SelectItem>
              <SelectItem value="in">In</SelectItem>
              <SelectItem value="gte">≥</SelectItem>
              <SelectItem value="lte">≤</SelectItem>
            </SelectContent>
          </Select>

          <Input
            value={node.value}
            onChange={(e) => updateCondition(node.id, "value", e.target.value)}
            placeholder="Value"
            className="w-[200px]"
          />

          <Button
            variant="ghost"
            size="sm"
            onClick={() => removeNode(node.id)}
            className="text-destructive hover:text-destructive"
          >
            Remove
          </Button>
        </div>
      )
    }

    if (node.type === "group") {
      return (
        <div
          key={node.id}
          className="border-l-2 border-primary/30 pl-4 space-y-2"
          style={{ marginLeft: `${depth * 20}px` }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Badge variant={node.logic === "and_" ? "default" : "secondary"}>
              {node.logic === "and_" ? "AND" : "OR"}
            </Badge>
            <Button
              variant="ghost"
              size="sm"
              onClick={() =>
                updateCondition(node.id, "logic", node.logic === "and_" ? "or_" : "and_")
              }
            >
              Toggle Logic
            </Button>
            <Button variant="outline" size="sm" onClick={() => addCondition(node.id)}>
              + Condition
            </Button>
            <Button variant="outline" size="sm" onClick={() => addGroup(node.id)}>
              + Group
            </Button>
            {depth > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => removeNode(node.id)}
                className="text-destructive"
              >
                Remove Group
              </Button>
            )}
          </div>
          {node.conditions.map((child) => renderFilterNode(child, depth + 1))}
        </div>
      )
    }

    return null
  }

  // Load all employees on mount
  useEffect(() => {
    searchEmployees()
  }, [pagination])

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Manage Employees</h1>
            <p className="text-muted-foreground mt-1">
              Create, search, and manage employee records
            </p>
          </div>
          <AlertDialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
            <AlertDialogTrigger asChild>
              <Button size="lg" className="gap-2">
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 4v16m8-8H4"
                  />
                </svg>
                Create Employee
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent className="max-w-5xl max-h-[90vh] overflow-hidden p-0">
              <div className="p-6">
                <AlertDialogHeader>
                  <AlertDialogTitle>Create New Employee</AlertDialogTitle>
                  <AlertDialogDescription>
                    Fill in the employee details. Use the stepper to navigate through sections.
                  </AlertDialogDescription>
                </AlertDialogHeader>
              </div>

              <Stepper
                initialStep={1}
                onStepChange={(step) => setCurrentStep(step)}
                onFinalStepCompleted={createEmployee}
                stepCircleContainerClassName=""
                contentClassName="max-h-[60vh] overflow-y-auto"
                footerClassName=""
                nextButtonText="Next"
                backButtonText="Back"
              >
                {/* Step 1: Basic Information */}
                <Step>
                  <div className="space-y-4 py-4">
                    <h3 className="text-lg font-semibold">Basic Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="employee_code">Employee Code *</Label>
                        <Input
                          id="employee_code"
                          value={newEmployee.employee_code}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, employee_code: e.target.value, reporting_manager_id: "9" })
                          }
                          placeholder="EMP-001"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="salutation">Salutation</Label>
                        <Select
                          value={newEmployee.salutation}
                          onValueChange={(value) =>
                            setNewEmployee({ ...newEmployee, salutation: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Mr">Mr</SelectItem>
                            <SelectItem value="Ms">Ms</SelectItem>
                            <SelectItem value="Mrs">Mrs</SelectItem>
                            <SelectItem value="Dr">Dr</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="first_name">First Name *</Label>
                        <Input
                          id="first_name"
                          value={newEmployee.first_name}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, first_name: e.target.value })
                          }
                          placeholder="John"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="last_name">Last Name *</Label>
                        <Input
                          id="last_name"
                          value={newEmployee.last_name}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, last_name: e.target.value })
                          }
                          placeholder="Doe"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="gender_code">Gender</Label>
                        <Select
                          value={newEmployee.gender_code}
                          onValueChange={(value) =>
                            setNewEmployee({ ...newEmployee, gender_code: value })
                          }
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="M">Male</SelectItem>
                            <SelectItem value="F">Female</SelectItem>
                            <SelectItem value="O">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="date_of_birth_val">Date of Birth *</Label>
                        <Input
                          id="date_of_birth_val"
                          type="date"
                          value={newEmployee.date_of_birth_val}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, date_of_birth_val: e.target.value })
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="blood_group">Blood Group</Label>
                        <Input
                          id="blood_group"
                          value={newEmployee.blood_group}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, blood_group: e.target.value })
                          }
                          placeholder="A+"
                        />
                      </div>
                    </div>
                  </div>
                </Step>

                {/* Step 2: Contact Information */}
                <Step>
                  <div className="space-y-4 py-4">
                    <h3 className="text-lg font-semibold">Contact Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="official_email">Official Email</Label>
                        <Input
                          id="official_email"
                          type="email"
                          value={newEmployee.official_email}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, official_email: e.target.value })
                          }
                          placeholder="john@sssihl.edu.in"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="personal_email">Personal Email</Label>
                        <Input
                          id="personal_email"
                          type="email"
                          value={newEmployee.personal_email}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, personal_email: e.target.value })
                          }
                          placeholder="john@example.com"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="mobile_number">Mobile Number</Label>
                        <Input
                          id="mobile_number"
                          value={newEmployee.mobile_number}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, mobile_number: e.target.value })
                          }
                          placeholder="+91 98765 43210"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="alternate_mobile_number">Alternate Mobile</Label>
                        <Input
                          id="alternate_mobile_number"
                          value={newEmployee.alternate_mobile_number}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, alternate_mobile_number: e.target.value })
                          }
                          placeholder="+91 98765 43210"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="emergency_contact_name">Emergency Contact</Label>
                        <Input
                          id="emergency_contact_name"
                          value={newEmployee.emergency_contact_name}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, emergency_contact_name: e.target.value })
                          }
                          placeholder="Jane Doe"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="emergency_contact_phone">Emergency Phone</Label>
                        <Input
                          id="emergency_contact_phone"
                          value={newEmployee.emergency_contact_phone}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, emergency_contact_phone: e.target.value })
                          }
                          placeholder="+91 98765 43210"
                        />
                      </div>
                    </div>
                  </div>
                </Step>

                {/* Step 3: Professional Information */}
                <Step>
                  <div className="space-y-4 py-4">
                    <h3 className="text-lg font-semibold">Professional Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="designation">Designation</Label>
                        <Input
                          id="designation"
                          value={newEmployee.designation}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, designation: e.target.value })
                          }
                          placeholder="Assistant Professor"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="role_nm">Role Name</Label>
                        <Input
                          id="role_nm"
                          value={newEmployee.role_nm}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, role_nm: e.target.value })
                          }
                          placeholder="Faculty"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="hire_date">Hire Date *</Label>
                        <Input
                          id="hire_date"
                          type="date"
                          value={newEmployee.hire_date}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, hire_date: e.target.value })
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="probation_ended_dt">Probation End</Label>
                        <Input
                          id="probation_ended_dt"
                          type="date"
                          value={newEmployee.probation_ended_dt}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, probation_ended_dt: e.target.value })
                          }
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="employment_status_code">Employment Status</Label>
                        <Input
                          id="employment_status_code"
                          value={newEmployee.employment_status_code}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, employment_status_code: e.target.value })
                          }
                          placeholder="ACTIVE"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="department_id">Department ID</Label>
                        <Input
                          id="department_id"
                          type="number"
                          value={newEmployee.department_id}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, department_id: e.target.value })
                          }
                          placeholder="1"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="unit_id">Unit ID</Label>
                        <Input
                          id="unit_id"
                          type="number"
                          value={newEmployee.unit_id}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, unit_id: e.target.value })
                          }
                          placeholder="1"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="campus_id">Campus ID</Label>
                        <Input
                          id="campus_id"
                          type="number"
                          value={newEmployee.campus_id}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, campus_id: e.target.value })
                          }
                          placeholder="1"
                        />
                      </div>
                    </div>
                  </div>
                </Step>

                {/* Step 4: Government IDs */}
                <Step>
                  <div className="space-y-4 py-4">
                    <h3 className="text-lg font-semibold">Government IDs</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="aadhaar_no">Aadhaar Number</Label>
                        <Input
                          id="aadhaar_no"
                          value={newEmployee.aadhaar_no}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, aadhaar_no: e.target.value })
                          }
                          placeholder="1234 5678 9012"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="pan_no">PAN Number</Label>
                        <Input
                          id="pan_no"
                          value={newEmployee.pan_no}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, pan_no: e.target.value })
                          }
                          placeholder="ABCDE1234F"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="uan_no">UAN Number</Label>
                        <Input
                          id="uan_no"
                          value={newEmployee.uan_no}
                          onChange={(e) =>
                            setNewEmployee({ ...newEmployee, uan_no: e.target.value })
                          }
                          placeholder="123456789012"
                        />
                      </div>
                    </div>
                  </div>
                </Step>
              </Stepper>

            </AlertDialogContent>
          </AlertDialog>

          {/* Credentials Dialog */}
          <AlertDialog open={showCredentialsDialog} onOpenChange={setShowCredentialsDialog}>
            <AlertDialogContent className="max-w-2xl">
              <AlertDialogHeader>
                <AlertDialogTitle className="flex items-center gap-2">
                  <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Employee Created Successfully!
                </AlertDialogTitle>
                <AlertDialogDescription>
                  Please share these temporary credentials with the employee. They will be required to change their password on first login.
                </AlertDialogDescription>
              </AlertDialogHeader>
              
              {newlyCreatedEmployee && newlyCreatedEmployee.cognito_user && (
                <div className="space-y-4 py-4">
                  <div className="p-4 bg-muted rounded-lg space-y-3">
                    <div>
                      <Label className="text-sm font-semibold">Employee Name</Label>
                      <p className="text-lg">{newlyCreatedEmployee.first_name} {newlyCreatedEmployee.last_name}</p>
                    </div>
                    <Separator />
                    <div>
                      <Label className="text-sm font-semibold">Username</Label>
                      <p className="text-lg font-mono">{newlyCreatedEmployee.cognito_user.username}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">Temporary Password</Label>
                      <p className="text-lg font-mono text-red-600">{newlyCreatedEmployee.cognito_user.temp_password}</p>
                    </div>
                    <div>
                      <Label className="text-sm font-semibold">Email</Label>
                      <p className="text-lg">{newlyCreatedEmployee.employee.official_email}</p>
                    </div>
                    <Separator />
                    <div className="flex items-start gap-2 p-3 bg-orange-50 border border-orange-200 rounded">
                      <svg className="w-5 h-5 text-orange-600 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                      </svg>
                      <div className="text-sm">
                        <p className="font-semibold text-orange-900">Important:</p>
                        <p className="text-orange-800">This is a temporary password. The user must change it on their first login. Make sure to save these credentials now as they won't be shown again.</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <AlertDialogFooter>
                <AlertDialogAction onClick={() => {
                  setShowCredentialsDialog(false)
                  setNewlyCreatedEmployee(null)
                }}>
                  I've Saved the Credentials
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        {/* Pending Password Changes Dashboard */}
        {pendingPasswordUsers.length > 0 && (
          <Card className="border-orange-200 bg-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                </svg>
                Pending Password Changes ({pendingPasswordUsers.length})
              </CardTitle>
              <CardDescription>
                Users who need to change their temporary password on first login
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {pendingPasswordUsers.map((user) => (
                  <div key={user.employee_id} className="p-3 bg-white rounded-lg border border-orange-200">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-semibold">{user.name}</p>
                        <p className="text-sm text-muted-foreground">Username: {user.username}</p>
                        <p className="text-sm text-muted-foreground">{user.email}</p>
                      </div>
                      <Badge variant="outline" className="bg-orange-100 text-orange-700 border-orange-300">
                        Awaiting Password Change
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Filters Section */}
        <Card>
          <CardHeader>
            <CardTitle>Advanced Search Filters</CardTitle>
            <CardDescription>
              Build complex nested filters with AND/OR logic to search for specific employees
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Filter Tree */}
            <div className="space-y-3">
              {renderFilterNode(filterTree)}
            </div>

            <div className="flex gap-2 pt-4 border-t">
              <Button onClick={searchEmployees} disabled={loading}>
                {loading ? "Searching..." : "Search Employees"}
              </Button>
              <Button variant="outline" onClick={() => addCondition(filterTree.id)}>
                Add Condition
              </Button>
              <Button variant="outline" onClick={() => addGroup(filterTree.id)}>
                Add Group
              </Button>
              {filterTree.conditions.length > 0 && (
                <Button variant="outline" onClick={clearAllFilters}>
                  Clear All Filters
                </Button>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Employees List */}
        <Card>
          <CardHeader>
            <CardTitle>Employees ({employees.length})</CardTitle>
            <CardDescription>
              List of all employees matching your search criteria
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading employees...
              </div>
            ) : employees.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No employees found. Try adjusting your filters.
              </div>
            ) : (
              <div className="space-y-3">
                {employees.map((employee) => (
                  <div
                    key={employee.employee_id}
                    className="p-4 bg-muted/50 rounded-lg hover:bg-muted/70 transition-colors"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex gap-4">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white font-bold">
                          {employee.first_name[0]}
                          {employee.last_name[0]}
                        </div>
                        <div>
                          <h3 className="font-semibold text-lg">
                            {employee.salutation} {employee.first_name}{" "}
                            {employee.last_name}
                          </h3>
                          <p className="text-sm text-muted-foreground">
                            {employee.employee_code}
                          </p>
                          <div className="flex gap-2 mt-2">
                            {employee.designation && (
                              <Badge variant="outline">{employee.designation}</Badge>
                            )}
                            {employee.role_nm && (
                              <Badge variant="secondary">{employee.role_nm}</Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">
                          Joined: {new Date(employee.hire_date).toLocaleDateString()}
                        </p>
                        {employee.official_email && (
                          <p className="text-sm text-muted-foreground">
                            {employee.official_email}
                          </p>
                        )}
                        {employee.mobile_number && (
                          <p className="text-sm text-muted-foreground">
                            {employee.mobile_number}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Pagination */}
            {employees.length > 0 && (
              <div className="flex items-center justify-between mt-6 pt-4 border-t">
                <Button
                  variant="outline"
                  disabled={pagination.offset === 0}
                  onClick={() =>
                    setPagination({
                      ...pagination,
                      offset: Math.max(0, pagination.offset - pagination.limit),
                    })
                  }
                >
                  Previous
                </Button>
                <span className="text-sm text-muted-foreground">
                  Showing {pagination.offset + 1} -{" "}
                  {Math.min(pagination.offset + pagination.limit, employees.length)} of{" "}
                  {employees.length}
                </span>
                <Button
                  variant="outline"
                  disabled={pagination.offset + pagination.limit >= employees.length}
                  onClick={() =>
                    setPagination({
                      ...pagination,
                      offset: pagination.offset + pagination.limit,
                    })
                  }
                >
                  Next
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
