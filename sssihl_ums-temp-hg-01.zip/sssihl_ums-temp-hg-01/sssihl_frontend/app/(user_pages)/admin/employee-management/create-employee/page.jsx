"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import Stepper, { Step } from "@/components/Stepper"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

export default function CreateEmployeePage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [currentStep, setCurrentStep] = useState(1)
  const [newlyCreatedEmployee, setNewlyCreatedEmployee] = useState(null)
  const [showCredentialsDialog, setShowCredentialsDialog] = useState(false)

  // New employee form state
  const [newEmployee, setNewEmployee] = useState({
    employee_code: "",
    first_name: "",
    last_name: "",
    salutation: "",
    gender_code: "",
    date_of_birth_val: "",
    blood_group: "",
    official_email: "",
    personal_email: "",
    mobile_number: "",
    alternate_mobile_number: "",
    emergency_contact_name: "",
    emergency_contact_phone: "",
    designation: "",
    role_nm: "",
    department_id: "",
    unit_id: "",
    campus_id: "",
    reporting_manager_id: "",
    employee_category_code: "",
    employee_type_code: "",
    hire_date: "",
    probation_ended_dt: "",
    employment_status_code: "",
    aadhaar_no: "",
    pan_no: "",
    uan_no: "",
  })

  // Create new employee
  const createEmployee = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/employees/create", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(newEmployee),
      })

      if (response.ok) {
        const data = await response.json()
        
        // Store cognito user info if present
        if (data.cognito_user) {
          setNewlyCreatedEmployee(data)
          setShowCredentialsDialog(true)
        } else {
          // If no cognito user, redirect back to employee management
          router.push("/admin/employee-management")
        }
        
        // Reset form
        setNewEmployee({
          employee_code: "",
          first_name: "",
          last_name: "",
          salutation: "",
          gender_code: "",
          date_of_birth_val: "",
          blood_group: "",
          official_email: "",
          personal_email: "",
          mobile_number: "",
          alternate_mobile_number: "",
          emergency_contact_name: "",
          emergency_contact_phone: "",
          designation: "",
          role_nm: "",
          department_id: "",
          unit_id: "",
          campus_id: "",
          reporting_manager_id: "",
          employee_category_code: "",
          employee_type_code: "",
          hire_date: "",
          probation_ended_dt: "",
          employment_status_code: "",
          aadhaar_no: "",
          pan_no: "",
          uan_no: "",
          reporting_manager_id: "9",
        })
      } else {
        const errorData = await response.json()
        console.error("Failed to create employee:", errorData)
        alert(`Failed to create employee: ${errorData.message || 'Unknown error'}`)
      }
    } catch (error) {
      console.error("Error creating employee:", error)
      alert("Error creating employee. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-5xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold">Create New Employee</h1>
            <p className="text-muted-foreground mt-1">
              Fill in the employee details using the step-by-step form
            </p>
          </div>
          <Button
            variant="outline"
            onClick={() => router.push("/admin/employee-management")}
          >
            <svg
              className="w-5 h-5 mr-2"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M10 19l-7-7m0 0l7-7m-7 7h18"
              />
            </svg>
            Back to Employee Management
          </Button>
        </div>

        {/* Main Form Card */}
        <Card>
          <CardHeader>
            <CardTitle>Employee Information</CardTitle>
            <CardDescription>
              Use the stepper below to navigate through different sections
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Stepper
              initialStep={1}
              onStepChange={(step) => setCurrentStep(step)}
              onFinalStepCompleted={createEmployee}
              stepCircleContainerClassName=""
              contentClassName="min-h-[400px]"
              footerClassName=""
              nextButtonText="Next"
              backButtonText="Back"
            >
              {/* Step 1: Basic Information */}
              <Step>
                <div className="space-y-4 py-4">
                  <h3 className="text-lg font-semibold">Basic Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="employee_code">Employee Code *</Label>
                      <Input
                        id="employee_code"
                        value={newEmployee.employee_code}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, employee_code: e.target.value, reporting_manager_id: "9" })
                        }
                        placeholder="EMP-001"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="salutation">Salutation</Label>
                      <Select
                        value={newEmployee.salutation}
                        onValueChange={(value) =>
                          setNewEmployee({ ...newEmployee, salutation: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Mr">Mr</SelectItem>
                          <SelectItem value="Ms">Ms</SelectItem>
                          <SelectItem value="Mrs">Mrs</SelectItem>
                          <SelectItem value="Dr">Dr</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="first_name">First Name *</Label>
                      <Input
                        id="first_name"
                        value={newEmployee.first_name}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, first_name: e.target.value })
                        }
                        placeholder="John"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="last_name">Last Name *</Label>
                      <Input
                        id="last_name"
                        value={newEmployee.last_name}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, last_name: e.target.value })
                        }
                        placeholder="Doe"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="gender_code">Gender</Label>
                      <Select
                        value={newEmployee.gender_code}
                        onValueChange={(value) =>
                          setNewEmployee({ ...newEmployee, gender_code: value })
                        }
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="M">Male</SelectItem>
                          <SelectItem value="F">Female</SelectItem>
                          <SelectItem value="O">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="date_of_birth_val">Date of Birth *</Label>
                      <Input
                        id="date_of_birth_val"
                        type="date"
                        value={newEmployee.date_of_birth_val}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, date_of_birth_val: e.target.value })
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="blood_group">Blood Group</Label>
                      <Input
                        id="blood_group"
                        value={newEmployee.blood_group}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, blood_group: e.target.value })
                        }
                        placeholder="A+"
                      />
                    </div>
                  </div>
                </div>
              </Step>

              {/* Step 2: Contact Information */}
              <Step>
                <div className="space-y-4 py-4">
                  <h3 className="text-lg font-semibold">Contact Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="official_email">Official Email</Label>
                      <Input
                        id="official_email"
                        type="email"
                        value={newEmployee.official_email}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, official_email: e.target.value })
                        }
                        placeholder="john@sssihl.edu.in"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="personal_email">Personal Email</Label>
                      <Input
                        id="personal_email"
                        type="email"
                        value={newEmployee.personal_email}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, personal_email: e.target.value })
                        }
                        placeholder="john@example.com"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="mobile_number">Mobile Number</Label>
                      <Input
                        id="mobile_number"
                        value={newEmployee.mobile_number}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, mobile_number: e.target.value })
                        }
                        placeholder="+91 98765 43210"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="alternate_mobile_number">Alternate Mobile</Label>
                      <Input
                        id="alternate_mobile_number"
                        value={newEmployee.alternate_mobile_number}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, alternate_mobile_number: e.target.value })
                        }
                        placeholder="+91 98765 43210"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="emergency_contact_name">Emergency Contact</Label>
                      <Input
                        id="emergency_contact_name"
                        value={newEmployee.emergency_contact_name}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, emergency_contact_name: e.target.value })
                        }
                        placeholder="Jane Doe"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="emergency_contact_phone">Emergency Phone</Label>
                      <Input
                        id="emergency_contact_phone"
                        value={newEmployee.emergency_contact_phone}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, emergency_contact_phone: e.target.value })
                        }
                        placeholder="+91 98765 43210"
                      />
                    </div>
                  </div>
                </div>
              </Step>

              {/* Step 3: Professional Information */}
              <Step>
                <div className="space-y-4 py-4">
                  <h3 className="text-lg font-semibold">Professional Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="designation">Designation</Label>
                      <Input
                        id="designation"
                        value={newEmployee.designation}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, designation: e.target.value })
                        }
                        placeholder="Assistant Professor"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="role_nm">Role Name</Label>
                      <Input
                        id="role_nm"
                        value={newEmployee.role_nm}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, role_nm: e.target.value })
                        }
                        placeholder="Faculty"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="hire_date">Hire Date *</Label>
                      <Input
                        id="hire_date"
                        type="date"
                        value={newEmployee.hire_date}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, hire_date: e.target.value })
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="probation_ended_dt">Probation End</Label>
                      <Input
                        id="probation_ended_dt"
                        type="date"
                        value={newEmployee.probation_ended_dt}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, probation_ended_dt: e.target.value })
                        }
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="employment_status_code">Employment Status</Label>
                      <Input
                        id="employment_status_code"
                        value={newEmployee.employment_status_code}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, employment_status_code: e.target.value })
                        }
                        placeholder="ACTIVE"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="department_id">Department ID</Label>
                      <Input
                        id="department_id"
                        type="number"
                        value={newEmployee.department_id}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, department_id: e.target.value })
                        }
                        placeholder="1"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="unit_id">Unit ID</Label>
                      <Input
                        id="unit_id"
                        type="number"
                        value={newEmployee.unit_id}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, unit_id: e.target.value })
                        }
                        placeholder="1"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="campus_id">Campus ID</Label>
                      <Input
                        id="campus_id"
                        type="number"
                        value={newEmployee.campus_id}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, campus_id: e.target.value })
                        }
                        placeholder="1"
                      />
                    </div>
                  </div>
                </div>
              </Step>

              {/* Step 4: Government IDs */}
              <Step>
                <div className="space-y-4 py-4">
                  <h3 className="text-lg font-semibold">Government IDs</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="aadhaar_no">Aadhaar Number</Label>
                      <Input
                        id="aadhaar_no"
                        value={newEmployee.aadhaar_no}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, aadhaar_no: e.target.value })
                        }
                        placeholder="1234 5678 9012"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="pan_no">PAN Number</Label>
                      <Input
                        id="pan_no"
                        value={newEmployee.pan_no}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, pan_no: e.target.value })
                        }
                        placeholder="ABCDE1234F"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="uan_no">UAN Number</Label>
                      <Input
                        id="uan_no"
                        value={newEmployee.uan_no}
                        onChange={(e) =>
                          setNewEmployee({ ...newEmployee, uan_no: e.target.value })
                        }
                        placeholder="123456789012"
                      />
                    </div>
                  </div>
                </div>
              </Step>
            </Stepper>
          </CardContent>
        </Card>

        {/* Credentials Dialog */}
        <AlertDialog open={showCredentialsDialog} onOpenChange={setShowCredentialsDialog}>
          <AlertDialogContent className="max-w-2xl">
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Employee Created Successfully!
              </AlertDialogTitle>
              <AlertDialogDescription>
                Please share these temporary credentials with the employee. They will be required to change their password on first login.
              </AlertDialogDescription>
            </AlertDialogHeader>
            
            {newlyCreatedEmployee && newlyCreatedEmployee.cognito_user && (
              <div className="space-y-4 py-4">
                <div className="p-4 bg-muted rounded-lg space-y-3">
                  <div>
                    <Label className="text-sm font-semibold">Employee Name</Label>
                    <p className="text-lg">{newlyCreatedEmployee.first_name} {newlyCreatedEmployee.last_name}</p>
                  </div>
                  <Separator />
                  <div>
                    <Label className="text-sm font-semibold">Username</Label>
                    <p className="text-lg font-mono">{newlyCreatedEmployee.cognito_user.username}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-semibold">Temporary Password</Label>
                    <p className="text-lg font-mono text-red-600">{newlyCreatedEmployee.cognito_user.temp_password}</p>
                  </div>
                  <div>
                    <Label className="text-sm font-semibold">Email</Label>
                    <p className="text-lg">{newlyCreatedEmployee.employee.official_email}</p>
                  </div>
                  <Separator />
                  <div className="flex items-start gap-2 p-3 bg-orange-50 border border-orange-200 rounded">
                    <svg className="w-5 h-5 text-orange-600 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <div className="text-sm">
                      <p className="font-semibold text-orange-900">Important:</p>
                      <p className="text-orange-800">This is a temporary password. The user must change it on their first login. Make sure to save these credentials now as they won't be shown again.</p>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            <AlertDialogFooter>
              <AlertDialogAction onClick={() => {
                setShowCredentialsDialog(false)
                setNewlyCreatedEmployee(null)
                router.push("/admin/employee-management")
              }}>
                I've Saved the Credentials
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </div>
    </div>
  )
}
