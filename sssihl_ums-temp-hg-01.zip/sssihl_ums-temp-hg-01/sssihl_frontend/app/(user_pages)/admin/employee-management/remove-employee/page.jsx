"use client"

import { useState } from "react"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Search, Trash2, CheckCircle2, XCircle, AlertCircle, X } from "lucide-react"

// Mock employee data - some will fail during deletion
const MOCK_EMPLOYEES = [
  {
    employee_id: 1,
    employee_code: "EMP001",
    first_name: "John",
    last_name: "Doe",
    official_email: "john.doe@sssihl.edu.in",
    designation: "Professor",
    department: "Computer Science",
    employment_status_code: "active",
    will_fail: false, // This employee will delete successfully
  },
  {
    employee_id: 2,
    employee_code: "EMP002",
    first_name: "Jane",
    last_name: "Smith",
    official_email: "jane.smith@sssihl.edu.in",
    designation: "Associate Professor",
    department: "Mathematics",
    employment_status_code: "active",
    will_fail: true, // This employee will fail to delete (has dependent records)
  },
  {
    employee_id: 3,
    employee_code: "EMP003",
    first_name: "Robert",
    last_name: "Johnson",
    official_email: "robert.j@sssihl.edu.in",
    designation: "Assistant Professor",
    department: "Physics",
    employment_status_code: "active",
    will_fail: false,
  },
  {
    employee_id: 4,
    employee_code: "EMP004",
    first_name: "Emily",
    last_name: "Williams",
    official_email: "emily.w@sssihl.edu.in",
    designation: "Lecturer",
    department: "Chemistry",
    employment_status_code: "probation",
    will_fail: false,
  },
  {
    employee_id: 5,
    employee_code: "EMP005",
    first_name: "Michael",
    last_name: "Brown",
    official_email: "michael.b@sssihl.edu.in",
    designation: "Senior Professor",
    department: "Computer Science",
    employment_status_code: "active",
    will_fail: true, // This employee will fail to delete (is a reporting manager)
  },
  {
    employee_id: 6,
    employee_code: "EMP006",
    first_name: "Sarah",
    last_name: "Davis",
    official_email: "sarah.d@sssihl.edu.in",
    designation: "Research Assistant",
    department: "Biology",
    employment_status_code: "contract",
    will_fail: false,
  },
  {
    employee_id: 7,
    employee_code: "EMP007",
    first_name: "David",
    last_name: "Martinez",
    official_email: "david.m@sssihl.edu.in",
    designation: "Lab Technician",
    department: "Chemistry",
    employment_status_code: "active",
    will_fail: false,
  },
  {
    employee_id: 8,
    employee_code: "EMP008",
    first_name: "Lisa",
    last_name: "Anderson",
    official_email: "lisa.a@sssihl.edu.in",
    designation: "Department Head",
    department: "Mathematics",
    employment_status_code: "active",
    will_fail: true, // This employee will fail to delete (department head)
  },
]

export default function RemoveEmployeePage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedEmployees, setSelectedEmployees] = useState([])
  const [showConfirmDialog, setShowConfirmDialog] = useState(false)
  const [deletionResult, setDeletionResult] = useState(null)
  const [isDeleting, setIsDeleting] = useState(false)

  // Filter employees based on search term
  const filteredEmployees = MOCK_EMPLOYEES.filter((emp) => {
    if (!searchTerm) return false
    const search = searchTerm.toLowerCase()
    return (
      emp.employee_code.toLowerCase().includes(search) ||
      emp.first_name.toLowerCase().includes(search) ||
      emp.last_name.toLowerCase().includes(search) ||
      emp.official_email.toLowerCase().includes(search) ||
      emp.designation.toLowerCase().includes(search) ||
      emp.department.toLowerCase().includes(search)
    )
  })

  // Toggle employee selection
  const toggleEmployeeSelection = (employee) => {
    setSelectedEmployees((prev) => {
      const isSelected = prev.some((e) => e.employee_id === employee.employee_id)
      if (isSelected) {
        return prev.filter((e) => e.employee_id !== employee.employee_id)
      } else {
        return [...prev, employee]
      }
    })
  }

  // Check if employee is selected
  const isEmployeeSelected = (employee) => {
    return selectedEmployees.some((e) => e.employee_id === employee.employee_id)
  }

  // Handle delete button click
  const handleDeleteClick = () => {
    if (selectedEmployees.length === 0) return
    setShowConfirmDialog(true)
  }

  // Simulate deletion with mock failures
  const handleConfirmDelete = async () => {
    setIsDeleting(true)
    setShowConfirmDialog(false)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1500))

    // Simulate deletion results
    const results = {
      successful: [],
      failed: [],
    }

    selectedEmployees.forEach((emp) => {
      if (emp.will_fail) {
        results.failed.push({
          employee_id: emp.employee_id,
          employee_code: emp.employee_code,
          name: `${emp.first_name} ${emp.last_name}`,
          reason: getFailureReason(emp),
        })
      } else {
        results.successful.push({
          employee_id: emp.employee_id,
          employee_code: emp.employee_code,
          name: `${emp.first_name} ${emp.last_name}`,
        })
      }
    })

    setDeletionResult(results)
    setIsDeleting(false)
    setSelectedEmployees([])
    setSearchTerm("")
  }

  // Get failure reason based on employee
  const getFailureReason = (emp) => {
    if (emp.designation.includes("Head")) {
      return "Cannot delete department head. Please assign a new head first."
    }
    if (emp.designation.includes("Senior")) {
      return "Employee has subordinates reporting to them. Reassign reports first."
    }
    return "Employee has dependent records that prevent deletion."
  }

  // Handle cancel deletion
  const handleCancelDelete = () => {
    setShowConfirmDialog(false)
  }

  // Close results dialog
  const closeDeletionResults = () => {
    setDeletionResult(null)
  }

  const getStatusBadgeVariant = (status) => {
    switch (status) {
      case "active":
        return "default"
      case "probation":
        return "secondary"
      case "contract":
        return "outline"
      default:
        return "default"
    }
  }

  return (
    <div className="container mx-auto py-8 px-4 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Remove Employee</h1>
        <p className="text-muted-foreground mt-2">
          Search for employees and remove them from the system
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Search Employees</CardTitle>
          <CardDescription>
            Search by employee code, name, email, designation, or department
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Search Bar */}
          <div className="relative flex items-center gap-2" >
            <Search className="text-muted-foreground h-4 w-4" />
            <Input
              type="text"
              placeholder="Search employees..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Selected Employees Count and Delete Button */}
          {selectedEmployees.length > 0 && (
            <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
              <div className="flex items-center gap-2">
                <Badge variant="secondary" className="text-base px-3 py-1">
                  {selectedEmployees.length} employee{selectedEmployees.length !== 1 ? "s" : ""} selected
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  onClick={() => setSelectedEmployees([])}
                  disabled={isDeleting}
                >
                  <X className="mr-2 h-4 w-4" />
                  Clear Selection
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleDeleteClick}
                  disabled={isDeleting}
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete Selected
                </Button>
              </div>
            </div>
          )}

          <Separator />

          {/* Search Results */}
          {searchTerm && (
            <div>
              <h3 className="text-lg font-semibold mb-4">
                Search Results ({filteredEmployees.length})
              </h3>
              
              {filteredEmployees.length === 0 ? (
                <div className="text-center py-12 text-muted-foreground">
                  <Search className="mx-auto h-12 w-12 mb-4 opacity-50" />
                  <p>No employees found matching your search</p>
                </div>
              ) : (
                <div className="border rounded-lg overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">Select</TableHead>
                        <TableHead>Employee Code</TableHead>
                        <TableHead>Name</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Designation</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredEmployees.map((employee) => (
                        <TableRow
                          key={employee.employee_id}
                          className={`cursor-pointer hover:bg-muted/50 ${
                            isEmployeeSelected(employee) ? "bg-muted" : ""
                          }`}
                          onClick={() => toggleEmployeeSelection(employee)}
                        >
                          <TableCell>
                            <input
                              type="checkbox"
                              checked={isEmployeeSelected(employee)}
                              onChange={() => toggleEmployeeSelection(employee)}
                              className="h-4 w-4 cursor-pointer"
                            />
                          </TableCell>
                          <TableCell className="font-medium">
                            {employee.employee_code}
                          </TableCell>
                          <TableCell>
                            {employee.first_name} {employee.last_name}
                          </TableCell>
                          <TableCell className="text-muted-foreground">
                            {employee.official_email}
                          </TableCell>
                          <TableCell>{employee.designation}</TableCell>
                          <TableCell>{employee.department}</TableCell>
                          <TableCell>
                            <Badge variant={getStatusBadgeVariant(employee.employment_status_code)}>
                              {employee.employment_status_code}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </div>
          )}

          {!searchTerm && (
            <div className="text-center py-12 text-muted-foreground">
              <Search className="mx-auto h-12 w-12 mb-4 opacity-50" />
              <p>Start typing to search for employees</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Confirmation Dialog */}
      <AlertDialog open={showConfirmDialog} onOpenChange={setShowConfirmDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-destructive" />
              Confirm Deletion
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-4">
                <div>
                  Are you sure you want to delete the following{" "}
                  <strong>{selectedEmployees.length}</strong> employee
                  {selectedEmployees.length !== 1 ? "s" : ""}?
                </div>
                <div className="max-h-60 overflow-y-auto space-y-2 rounded-md border p-4">
                  {selectedEmployees.map((emp) => (
                    <div
                      key={emp.employee_id}
                      className="flex items-center justify-between py-2"
                    >
                      <div>
                        <div className="font-medium text-foreground">
                          {emp.first_name} {emp.last_name}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {emp.employee_code} - {emp.designation}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="text-destructive font-semibold">
                  This action cannot be undone.
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={handleCancelDelete}>
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Deletion Results Dialog */}
      {deletionResult && (
        <AlertDialog open={!!deletionResult} onOpenChange={() => closeDeletionResults()}>
          <AlertDialogContent className="max-w-2xl">
            <AlertDialogHeader>
              <AlertDialogTitle className="flex items-center gap-2">
                {deletionResult.failed.length === 0 ? (
                  <>
                    <CheckCircle2 className="h-5 w-5 text-green-600" />
                    Deletion Successful
                  </>
                ) : (
                  <>
                    <AlertCircle className="h-5 w-5 text-yellow-600" />
                    Deletion Completed with Errors
                  </>
                )}
              </AlertDialogTitle>
              <AlertDialogDescription asChild>
                <div className="space-y-4">
                  {/* Successful Deletions */}
                  {deletionResult.successful.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-green-600">
                        <CheckCircle2 className="h-4 w-4" />
                        <div className="font-semibold text-foreground">
                          Successfully deleted {deletionResult.successful.length} employee
                          {deletionResult.successful.length !== 1 ? "s" : ""}:
                        </div>
                      </div>
                      <div className="max-h-40 overflow-y-auto space-y-1 rounded-md border border-green-200 bg-green-50 dark:bg-green-950/20 p-3">
                        {deletionResult.successful.map((emp) => (
                          <div key={emp.employee_id} className="flex items-center gap-2">
                            <CheckCircle2 className="h-3 w-3 text-green-600 flex-shrink-0" />
                            <div className="text-sm text-foreground">
                              {emp.name} ({emp.employee_code})
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Failed Deletions */}
                  {deletionResult.failed.length > 0 && (
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 text-destructive">
                        <XCircle className="h-4 w-4" />
                        <div className="font-semibold text-foreground">
                          Failed to delete {deletionResult.failed.length} employee
                          {deletionResult.failed.length !== 1 ? "s" : ""}:
                        </div>
                      </div>
                      <div className="max-h-60 overflow-y-auto space-y-3 rounded-md border border-red-200 bg-red-50 dark:bg-red-950/20 p-3">
                        {deletionResult.failed.map((emp) => (
                          <div key={emp.employee_id} className="space-y-1">
                            <div className="flex items-center gap-2">
                              <XCircle className="h-3 w-3 text-destructive flex-shrink-0" />
                              <div className="text-sm font-medium text-foreground">
                                {emp.name} ({emp.employee_code})
                              </div>
                            </div>
                            <div className="text-xs text-muted-foreground ml-5">
                              {emp.reason}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogAction onClick={closeDeletionResults}>
                Close
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      {/* Loading Overlay */}
      {isDeleting && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center">
          <Card className="w-64">
            <CardContent className="pt-6">
              <div className="flex flex-col items-center gap-4">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                <p className="text-sm font-medium">Deleting employees...</p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
