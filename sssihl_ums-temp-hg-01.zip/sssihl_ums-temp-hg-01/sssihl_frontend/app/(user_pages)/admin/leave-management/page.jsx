"use client"

import { useState } from "react"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Calendar, Clock, CheckCircle2, XCircle, Search, User, FileText, AlertCircle } from "lucide-react"
import { toast } from "sonner"

// Mock data for active leave requests
const mockLeaveRequests = [
  {
    id: 1,
    employeeId: 1,
    employeeName: "John Smith",
    employeeEmail: "john.smith@sssihl.edu.in",
    department: "Engineering",
    designation: "Senior Developer",
    submittedDate: "2026-01-08",
    startDate: "2026-01-15",
    endDate: "2026-01-17",
    leaveType: "Casual Leave",
    reason: "Family function",
    status: "pending",
    leavesAvailable: {
      casualLeave: 5,
      sickLeave: 8,
      earnedLeave: 12,
      maternityLeave: 0,
      paternityLeave: 5,
    },
    leavesUsed: {
      casualLeave: 7,
      sickLeave: 4,
      earnedLeave: 3,
    },
  },
  {
    id: 2,
    employeeId: 2,
    employeeName: "Sarah Johnson",
    employeeEmail: "sarah.johnson@sssihl.edu.in",
    department: "Engineering",
    designation: "Tech Lead",
    submittedDate: "2026-01-09",
    startDate: "2026-01-20",
    endDate: "2026-01-22",
    leaveType: "Sick Leave",
    reason: "Medical appointment and recovery",
    status: "pending",
    leavesAvailable: {
      casualLeave: 8,
      sickLeave: 10,
      earnedLeave: 15,
      maternityLeave: 0,
      paternityLeave: 0,
    },
    leavesUsed: {
      casualLeave: 4,
      sickLeave: 2,
      earnedLeave: 0,
    },
  },
  {
    id: 3,
    employeeId: 3,
    employeeName: "Michael Chen",
    employeeEmail: "michael.chen@sssihl.edu.in",
    department: "Engineering",
    designation: "Software Engineer",
    submittedDate: "2026-01-10",
    startDate: "2026-02-01",
    endDate: "2026-02-07",
    leaveType: "Earned Leave",
    reason: "Vacation with family",
    status: "pending",
    leavesAvailable: {
      casualLeave: 10,
      sickLeave: 12,
      earnedLeave: 18,
      maternityLeave: 0,
      paternityLeave: 5,
    },
    leavesUsed: {
      casualLeave: 2,
      sickLeave: 0,
      earnedLeave: 2,
    },
  },
  {
    id: 4,
    employeeId: 4,
    employeeName: "Emily Davis",
    employeeEmail: "emily.davis@sssihl.edu.in",
    department: "Product",
    designation: "Product Manager",
    submittedDate: "2026-01-09",
    startDate: "2026-01-16",
    endDate: "2026-01-16",
    leaveType: "Casual Leave",
    reason: "Personal work",
    status: "pending",
    leavesAvailable: {
      casualLeave: 6,
      sickLeave: 11,
      earnedLeave: 20,
      maternityLeave: 90,
      paternityLeave: 0,
    },
    leavesUsed: {
      casualLeave: 6,
      sickLeave: 1,
      earnedLeave: 0,
    },
  },
  {
    id: 5,
    employeeId: 5,
    employeeName: "David Wilson",
    employeeEmail: "david.wilson@sssihl.edu.in",
    department: "Engineering",
    designation: "DevOps Engineer",
    submittedDate: "2026-01-08",
    startDate: "2026-01-18",
    endDate: "2026-01-19",
    leaveType: "Sick Leave",
    reason: "Flu symptoms",
    status: "pending",
    leavesAvailable: {
      casualLeave: 9,
      sickLeave: 9,
      earnedLeave: 14,
      maternityLeave: 0,
      paternityLeave: 5,
    },
    leavesUsed: {
      casualLeave: 3,
      sickLeave: 3,
      earnedLeave: 6,
    },
  },
]

// Mock data for employee leave history
const mockEmployeeLeaveHistory = {
  1: [
    { id: 101, startDate: "2025-12-20", endDate: "2025-12-24", leaveType: "Earned Leave", status: "approved", reason: "Christmas holidays" },
    { id: 102, startDate: "2025-11-15", endDate: "2025-11-16", leaveType: "Casual Leave", status: "approved", reason: "Family event" },
    { id: 103, startDate: "2025-10-10", endDate: "2025-10-10", leaveType: "Sick Leave", status: "approved", reason: "Not feeling well" },
    { id: 104, startDate: "2025-09-05", endDate: "2025-09-06", leaveType: "Casual Leave", status: "rejected", reason: "Personal work", rejectionReason: "Insufficient coverage during critical project phase" },
  ],
  2: [
    { id: 201, startDate: "2025-12-15", endDate: "2025-12-17", leaveType: "Casual Leave", status: "approved", reason: "Travel" },
    { id: 202, startDate: "2025-11-20", endDate: "2025-11-20", leaveType: "Sick Leave", status: "approved", reason: "Medical checkup" },
    { id: 203, startDate: "2025-10-05", endDate: "2025-10-08", leaveType: "Earned Leave", status: "approved", reason: "Vacation" },
  ],
  3: [
    { id: 301, startDate: "2025-12-28", endDate: "2025-12-31", leaveType: "Earned Leave", status: "approved", reason: "New Year celebration" },
    { id: 302, startDate: "2025-11-10", endDate: "2025-11-11", leaveType: "Casual Leave", status: "approved", reason: "Moving house" },
  ],
  4: [
    { id: 401, startDate: "2025-12-23", endDate: "2025-12-27", leaveType: "Earned Leave", status: "approved", reason: "Year end holidays" },
    { id: 402, startDate: "2025-11-18", endDate: "2025-11-19", leaveType: "Casual Leave", status: "approved", reason: "Family function" },
    { id: 403, startDate: "2025-10-25", endDate: "2025-10-25", leaveType: "Casual Leave", status: "rejected", reason: "Personal", rejectionReason: "Too many leaves in the same month" },
  ],
  5: [
    { id: 501, startDate: "2025-12-18", endDate: "2025-12-19", leaveType: "Sick Leave", status: "approved", reason: "Fever" },
    { id: 502, startDate: "2025-11-08", endDate: "2025-11-12", leaveType: "Earned Leave", status: "approved", reason: "Vacation" },
    { id: 503, startDate: "2025-10-15", endDate: "2025-10-17", leaveType: "Earned Leave", status: "approved", reason: "Family trip" },
  ],
}

// All employees for search
const allEmployees = [
  { id: 1, name: "John Smith", email: "john.smith@sssihl.edu.in", department: "Engineering", designation: "Senior Developer" },
  { id: 2, name: "Sarah Johnson", email: "sarah.johnson@sssihl.edu.in", department: "Engineering", designation: "Tech Lead" },
  { id: 3, name: "Michael Chen", email: "michael.chen@sssihl.edu.in", department: "Engineering", designation: "Software Engineer" },
  { id: 4, name: "Emily Davis", email: "emily.davis@sssihl.edu.in", department: "Product", designation: "Product Manager" },
  { id: 5, name: "David Wilson", email: "david.wilson@sssihl.edu.in", department: "Engineering", designation: "DevOps Engineer" },
  { id: 6, name: "Lisa Anderson", email: "lisa.anderson@sssihl.edu.in", department: "Design", designation: "UX Designer" },
  { id: 7, name: "Robert Taylor", email: "robert.taylor@sssihl.edu.in", department: "Engineering", designation: "Backend Developer" },
  { id: 8, name: "Jennifer Martinez", email: "jennifer.martinez@sssihl.edu.in", department: "HR", designation: "HR Manager" },
  { id: 9, name: "James Brown", email: "james.brown@sssihl.edu.in", department: "Engineering", designation: "Frontend Developer" },
  { id: 10, name: "Patricia Garcia", email: "patricia.garcia@sssihl.edu.in", department: "Marketing", designation: "Marketing Manager" },
]

export default function LeaveManagementPage() {
  const [leaveRequests, setLeaveRequests] = useState(mockLeaveRequests)
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [isDetailsModalOpen, setIsDetailsModalOpen] = useState(false)
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false)
  const [rejectionReason, setRejectionReason] = useState("")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedEmployee, setSelectedEmployee] = useState(null)
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState(false)

  // Filter employees based on search
  const filteredEmployees = allEmployees.filter(emp =>
    emp.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
    emp.department.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleRequestClick = (request) => {
    setSelectedRequest(request)
    setIsDetailsModalOpen(true)
  }

  const handleApprove = () => {
    if (!selectedRequest) return
    
    setLeaveRequests(prevRequests =>
      prevRequests.map(req =>
        req.id === selectedRequest.id ? { ...req, status: "approved" } : req
      )
    )
    
    toast.success(`Leave request for ${selectedRequest.employeeName} approved successfully`)
    setIsDetailsModalOpen(false)
    setSelectedRequest(null)
  }

  const openRejectModal = () => {
    setIsDetailsModalOpen(false)
    setIsRejectModalOpen(true)
  }

  const handleReject = () => {
    if (!selectedRequest || !rejectionReason.trim()) {
      toast.error("Please provide a reason for rejection")
      return
    }
    
    setLeaveRequests(prevRequests =>
      prevRequests.map(req =>
        req.id === selectedRequest.id 
          ? { ...req, status: "rejected", rejectionReason } 
          : req
      )
    )
    
    toast.success(`Leave request for ${selectedRequest.employeeName} rejected`)
    setIsRejectModalOpen(false)
    setRejectionReason("")
    setSelectedRequest(null)
  }

  const handleEmployeeClick = (employee) => {
    setSelectedEmployee(employee)
    setIsHistoryModalOpen(true)
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
  }

  const calculateDays = (startDate, endDate) => {
    const start = new Date(startDate)
    const end = new Date(endDate)
    const diffTime = Math.abs(end - start)
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1
    return diffDays
  }

  const getStatusBadge = (status) => {
    const variants = {
      pending: "warning",
      approved: "success",
      rejected: "destructive",
    }
    const labels = {
      pending: "Pending",
      approved: "Approved",
      rejected: "Rejected",
    }
    return (
      <Badge variant={variants[status]}>
        {labels[status]}
      </Badge>
    )
  }

  const getLeaveTypeBadge = (type) => {
    const colors = {
      "Casual Leave": "bg-blue-100 text-blue-800",
      "Sick Leave": "bg-red-100 text-red-800",
      "Earned Leave": "bg-green-100 text-green-800",
      "Maternity Leave": "bg-purple-100 text-purple-800",
      "Paternity Leave": "bg-orange-100 text-orange-800",
    }
    return (
      <Badge className={colors[type] || "bg-gray-100 text-gray-800"}>
        {type}
      </Badge>
    )
  }

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Leave Management</h1>
        <p className="text-muted-foreground">
          Review and manage employee leave requests
        </p>
      </div>

      {/* Active Leave Requests Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Active Leave Requests
          </CardTitle>
          <CardDescription>
            Pending leave requests requiring approval
          </CardDescription>
        </CardHeader>
        <CardContent>
          {leaveRequests.filter(req => req.status === "pending").length === 0 ? (
            <div className="text-center py-12 text-muted-foreground">
              <AlertCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No pending leave requests</p>
            </div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee Name</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Leave Type</TableHead>
                  <TableHead>Submitted Date</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Action</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {leaveRequests
                  .filter(req => req.status === "pending")
                  .map((request) => (
                    <TableRow key={request.id} className="cursor-pointer hover:bg-muted/50">
                      <TableCell className="font-medium">
                        <div>
                          <div>{request.employeeName}</div>
                          <div className="text-sm text-muted-foreground">{request.designation}</div>
                        </div>
                      </TableCell>
                      <TableCell>{request.department}</TableCell>
                      <TableCell>{getLeaveTypeBadge(request.leaveType)}</TableCell>
                      <TableCell>{formatDate(request.submittedDate)}</TableCell>
                      <TableCell>
                        {calculateDays(request.startDate, request.endDate)} day(s)
                      </TableCell>
                      <TableCell>{getStatusBadge(request.status)}</TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          onClick={() => handleRequestClick(request)}
                        >
                          Review
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Separator />

      {/* Employee Leave History Search Section */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5" />
            Employee Leave History
          </CardTitle>
          <CardDescription>
            Search for employees to view their leave history
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name, email, or department..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>

          {searchQuery && (
            <div className="border rounded-lg max-h-96 overflow-y-auto">
              {filteredEmployees.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <User className="h-8 w-8 mx-auto mb-2 opacity-50" />
                  <p>No employees found</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Department</TableHead>
                      <TableHead>Designation</TableHead>
                      <TableHead>Action</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredEmployees.map((employee) => (
                      <TableRow key={employee.id}>
                        <TableCell className="font-medium">{employee.name}</TableCell>
                        <TableCell>{employee.email}</TableCell>
                        <TableCell>{employee.department}</TableCell>
                        <TableCell>{employee.designation}</TableCell>
                        <TableCell>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEmployeeClick(employee)}
                          >
                            View History
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Leave Request Details Modal */}
      <Dialog open={isDetailsModalOpen} onOpenChange={setIsDetailsModalOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Leave Request Details</DialogTitle>
            <DialogDescription>
              Review the leave request information
            </DialogDescription>
          </DialogHeader>
          
          {selectedRequest && (
            <div className="space-y-6">
              {/* Employee Information */}
              <div className="border rounded-lg p-4 bg-muted/30">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <User className="h-4 w-4" />
                  Employee Information
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Name</Label>
                    <p className="font-medium">{selectedRequest.employeeName}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Email</Label>
                    <p className="font-medium">{selectedRequest.employeeEmail}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Department</Label>
                    <p className="font-medium">{selectedRequest.department}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Designation</Label>
                    <p className="font-medium">{selectedRequest.designation}</p>
                  </div>
                </div>
              </div>

              {/* Leave Request Information */}
              <div className="border rounded-lg p-4 bg-muted/30">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  Leave Details
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Leave Type</Label>
                    <div className="mt-1">
                      {getLeaveTypeBadge(selectedRequest.leaveType)}
                    </div>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Submitted On</Label>
                    <p className="font-medium">{formatDate(selectedRequest.submittedDate)}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Start Date</Label>
                    <p className="font-medium">{formatDate(selectedRequest.startDate)}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">End Date</Label>
                    <p className="font-medium">{formatDate(selectedRequest.endDate)}</p>
                  </div>
                  <div className="col-span-2">
                    <Label className="text-muted-foreground">Duration</Label>
                    <p className="font-medium">
                      {calculateDays(selectedRequest.startDate, selectedRequest.endDate)} day(s)
                    </p>
                  </div>
                  <div className="col-span-2">
                    <Label className="text-muted-foreground">Reason</Label>
                    <p className="font-medium mt-1">{selectedRequest.reason}</p>
                  </div>
                </div>
              </div>

              {/* Leave Balance Information */}
              <div className="border rounded-lg p-4 bg-muted/30">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Leave Balance
                </h3>
                <div className="space-y-3">
                  <div className="grid grid-cols-3 gap-2 text-sm font-medium text-muted-foreground">
                    <div>Leave Type</div>
                    <div>Available</div>
                    <div>Used</div>
                  </div>
                  <Separator />
                  <div className="grid grid-cols-3 gap-2 items-center">
                    <div className="text-sm font-medium">Casual Leave</div>
                    <div className="text-lg font-bold text-green-600">
                      {selectedRequest.leavesAvailable.casualLeave}
                    </div>
                    <div className="text-lg font-bold text-red-600">
                      {selectedRequest.leavesUsed.casualLeave}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 items-center">
                    <div className="text-sm font-medium">Sick Leave</div>
                    <div className="text-lg font-bold text-green-600">
                      {selectedRequest.leavesAvailable.sickLeave}
                    </div>
                    <div className="text-lg font-bold text-red-600">
                      {selectedRequest.leavesUsed.sickLeave}
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 items-center">
                    <div className="text-sm font-medium">Earned Leave</div>
                    <div className="text-lg font-bold text-green-600">
                      {selectedRequest.leavesAvailable.earnedLeave}
                    </div>
                    <div className="text-lg font-bold text-red-600">
                      {selectedRequest.leavesUsed.earnedLeave}
                    </div>
                  </div>
                  {selectedRequest.leavesAvailable.maternityLeave > 0 && (
                    <div className="grid grid-cols-3 gap-2 items-center">
                      <div className="text-sm font-medium">Maternity Leave</div>
                      <div className="text-lg font-bold text-green-600">
                        {selectedRequest.leavesAvailable.maternityLeave}
                      </div>
                      <div className="text-lg font-bold text-red-600">0</div>
                    </div>
                  )}
                  {selectedRequest.leavesAvailable.paternityLeave > 0 && (
                    <div className="grid grid-cols-3 gap-2 items-center">
                      <div className="text-sm font-medium">Paternity Leave</div>
                      <div className="text-lg font-bold text-green-600">
                        {selectedRequest.leavesAvailable.paternityLeave}
                      </div>
                      <div className="text-lg font-bold text-red-600">0</div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDetailsModalOpen(false)}>
              Close
            </Button>
            <Button variant="destructive" onClick={openRejectModal}>
              <XCircle className="h-4 w-4 mr-2" />
              Reject
            </Button>
            <Button onClick={handleApprove}>
              <CheckCircle2 className="h-4 w-4 mr-2" />
              Approve
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Rejection Modal */}
      <Dialog open={isRejectModalOpen} onOpenChange={setIsRejectModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Leave Request</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this leave request
            </DialogDescription>
          </DialogHeader>
          
          {selectedRequest && (
            <div className="space-y-4">
              <div>
                <Label className="text-muted-foreground">Employee</Label>
                <p className="font-medium">{selectedRequest.employeeName}</p>
              </div>
              <div>
                <Label htmlFor="rejection-reason">Reason for Rejection *</Label>
                <Textarea
                  id="rejection-reason"
                  placeholder="Please explain why this leave request is being rejected..."
                  value={rejectionReason}
                  onChange={(e) => setRejectionReason(e.target.value)}
                  rows={4}
                  className="mt-2"
                />
              </div>
            </div>
          )}

          <DialogFooter>
            <Button variant="outline" onClick={() => {
              setIsRejectModalOpen(false)
              setRejectionReason("")
              setIsDetailsModalOpen(true)
            }}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleReject}>
              <XCircle className="h-4 w-4 mr-2" />
              Reject Leave Request
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Employee Leave History Modal */}
      <Dialog open={isHistoryModalOpen} onOpenChange={setIsHistoryModalOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Leave History</DialogTitle>
            <DialogDescription>
              {selectedEmployee && `${selectedEmployee.name}'s leave history`}
            </DialogDescription>
          </DialogHeader>
          
          {selectedEmployee && (
            <div className="space-y-6">
              {/* Employee Info */}
              <div className="border rounded-lg p-4 bg-muted/30">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label className="text-muted-foreground">Name</Label>
                    <p className="font-medium">{selectedEmployee.name}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Email</Label>
                    <p className="font-medium">{selectedEmployee.email}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Department</Label>
                    <p className="font-medium">{selectedEmployee.department}</p>
                  </div>
                  <div>
                    <Label className="text-muted-foreground">Designation</Label>
                    <p className="font-medium">{selectedEmployee.designation}</p>
                  </div>
                </div>
              </div>

              {/* Leave History */}
              <div>
                <h3 className="font-semibold mb-3">Previous Leave Requests</h3>
                {mockEmployeeLeaveHistory[selectedEmployee.id] ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Start Date</TableHead>
                        <TableHead>End Date</TableHead>
                        <TableHead>Days</TableHead>
                        <TableHead>Leave Type</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Reason</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {mockEmployeeLeaveHistory[selectedEmployee.id].map((leave) => (
                        <TableRow key={leave.id}>
                          <TableCell>{formatDate(leave.startDate)}</TableCell>
                          <TableCell>{formatDate(leave.endDate)}</TableCell>
                          <TableCell>
                            {calculateDays(leave.startDate, leave.endDate)}
                          </TableCell>
                          <TableCell>{getLeaveTypeBadge(leave.leaveType)}</TableCell>
                          <TableCell>{getStatusBadge(leave.status)}</TableCell>
                          <TableCell>
                            <div>
                              <p className="text-sm">{leave.reason}</p>
                              {leave.status === "rejected" && leave.rejectionReason && (
                                <p className="text-xs text-red-600 mt-1">
                                  Rejected: {leave.rejectionReason}
                                </p>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <AlertCircle className="h-12 w-12 mx-auto mb-4 opacity-50" />
                    <p>No leave history found for this employee</p>
                  </div>
                )}
              </div>
            </div>
          )}

          <DialogFooter>
            <Button onClick={() => setIsHistoryModalOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
