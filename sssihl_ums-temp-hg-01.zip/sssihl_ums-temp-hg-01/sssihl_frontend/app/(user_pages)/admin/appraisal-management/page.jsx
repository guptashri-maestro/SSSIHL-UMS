"use client"

import { useState } from "react"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Calendar, Clock, CheckCircle2, AlertCircle, Plus, Trash2, Eye, Edit, UserPlus } from "lucide-react"
import { Checkbox } from "../../../../components/ui/checkbox"
import { toast } from "sonner"

// Mock employee data for assignment
const mockEmployees = [
  { id: 1, name: "John Smith", email: "john.smith@sssihl.edu.in", department: "Engineering", designation: "Senior Developer" },
  { id: 2, name: "Sarah Johnson", email: "sarah.johnson@sssihl.edu.in", department: "Engineering", designation: "Tech Lead" },
  { id: 3, name: "Michael Chen", email: "michael.chen@sssihl.edu.in", department: "Engineering", designation: "Software Engineer" },
  { id: 4, name: "Emily Davis", email: "emily.davis@sssihl.edu.in", department: "Product", designation: "Product Manager" },
  { id: 5, name: "David Wilson", email: "david.wilson@sssihl.edu.in", department: "Engineering", designation: "DevOps Engineer" },
  { id: 6, name: "Lisa Anderson", email: "lisa.anderson@sssihl.edu.in", department: "Design", designation: "UX Designer" },
  { id: 7, name: "Robert Taylor", email: "robert.taylor@sssihl.edu.in", department: "Engineering", designation: "Backend Developer" },
  { id: 8, name: "Jennifer Martinez", email: "jennifer.martinez@sssihl.edu.in", department: "HR", designation: "HR Manager" },
  { id: 9, name: "James Brown", email: "james.brown@sssihl.edu.in", department: "Engineering", designation: "Frontend Developer" },
  { id: 10, name: "Patricia Garcia", email: "patricia.garcia@sssihl.edu.in", department: "Marketing", designation: "Marketing Manager" },
  { id: 11, name: "Daniel Rodriguez", email: "daniel.rodriguez@sssihl.edu.in", department: "Engineering", designation: "QA Engineer" },
  { id: 12, name: "Maria Hernandez", email: "maria.hernandez@sssihl.edu.in", department: "Finance", designation: "Financial Analyst" },
  { id: 13, name: "Christopher Lopez", email: "christopher.lopez@sssihl.edu.in", department: "Engineering", designation: "Data Engineer" },
  { id: 14, name: "Jessica Wilson", email: "jessica.wilson@sssihl.edu.in", department: "Product", designation: "Product Designer" },
  { id: 15, name: "Matthew Moore", email: "matthew.moore@sssihl.edu.in", department: "Engineering", designation: "Full Stack Developer" },
]

// Mock data for appraisals
const mockAppraisalsData = {
  pending: [
    {
      id: 1,
      name: "Annual Performance Review 2026",
      createdDate: "2026-01-01",
      dueDate: "2026-01-31",
      assignedTo: [
        { id: 1, name: "John Smith", email: "john.smith@sssihl.edu.in", status: "in_progress", progress: 60 },
        { id: 2, name: "Sarah Johnson", email: "sarah.johnson@sssihl.edu.in", status: "not_started", progress: 0 },
        { id: 3, name: "Michael Chen", email: "michael.chen@sssihl.edu.in", status: "in_progress", progress: 40 },
        { id: 4, name: "Emily Davis", email: "emily.davis@sssihl.edu.in", status: "not_started", progress: 0 },
      ],
      questions: [
        {
          id: "q1",
          type: "text",
          question: "What were your key accomplishments this year?",
          required: true
        },
        {
          id: "q2",
          type: "textarea",
          question: "Describe a challenging situation you faced and how you overcame it.",
          required: true
        },
        {
          id: "q3",
          type: "multiple_choice",
          question: "How would you rate your collaboration with team members?",
          options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
          required: true
        },
        {
          id: "q4",
          type: "multiple_choice",
          question: "How satisfied are you with your current role?",
          options: ["Very Satisfied", "Satisfied", "Neutral", "Dissatisfied", "Very Dissatisfied"],
          required: true
        },
        {
          id: "q5",
          type: "textarea",
          question: "What are your professional development goals for the next year?",
          required: true
        }
      ]
    },
    {
      id: 2,
      name: "Q1 Objectives Review",
      createdDate: "2026-01-05",
      dueDate: "2026-01-20",
      assignedTo: [
        { id: 5, name: "David Wilson", email: "david.wilson@sssihl.edu.in", status: "not_started", progress: 0 },
        { id: 6, name: "Lisa Anderson", email: "lisa.anderson@sssihl.edu.in", status: "not_started", progress: 0 },
        { id: 7, name: "Robert Taylor", email: "robert.taylor@sssihl.edu.in", status: "in_progress", progress: 33 },
      ],
      questions: [
        {
          id: "q1",
          type: "textarea",
          question: "List your objectives for Q1 2026.",
          required: true
        },
        {
          id: "q2",
          type: "multiple_choice",
          question: "How confident are you in achieving these objectives?",
          options: ["Very Confident", "Confident", "Somewhat Confident", "Not Confident"],
          required: true
        },
        {
          id: "q3",
          type: "textarea",
          question: "What resources or support do you need to achieve your objectives?",
          required: true
        }
      ]
    },
    {
      id: 3,
      name: "Leadership Assessment 2026",
      createdDate: "2026-01-08",
      dueDate: "2026-02-15",
      assignedTo: [
        { id: 8, name: "Jennifer Martinez", email: "jennifer.martinez@sssihl.edu.in", status: "not_started", progress: 0 },
        { id: 9, name: "James Brown", email: "james.brown@sssihl.edu.in", status: "not_started", progress: 0 },
      ],
      questions: [
        {
          id: "q1",
          type: "multiple_choice",
          question: "How would you rate your leadership skills?",
          options: ["Excellent", "Very Good", "Good", "Fair", "Needs Improvement"],
          required: true
        },
        {
          id: "q2",
          type: "textarea",
          question: "Describe a situation where you demonstrated leadership.",
          required: true
        },
        {
          id: "q3",
          type: "text",
          question: "What leadership training would benefit you?",
          required: false
        }
      ]
    }
  ],
  completed: [
    {
      id: 100,
      name: "Mid-Year Review 2025",
      createdDate: "2025-06-01",
      dueDate: "2025-06-30",
      completedDate: "2025-06-29",
      assignedTo: [
        { 
          id: 1, 
          name: "John Smith", 
          email: "john.smith@sssihl.edu.in", 
          status: "completed", 
          progress: 100,
          completedDate: "2025-06-25",
          responses: [
            {
              questionId: "q1",
              question: "What were your key accomplishments in the first half of 2025?",
              type: "text",
              answer: "Led the migration of legacy systems to cloud infrastructure, resulting in 40% cost reduction."
            },
            {
              questionId: "q2",
              question: "What challenges did you face?",
              type: "textarea",
              answer: "The main challenge was coordinating with multiple teams across different time zones. We overcame this by implementing better communication protocols and using async collaboration tools."
            },
            {
              questionId: "q3",
              question: "How would you rate your overall performance?",
              type: "multiple_choice",
              options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
              answer: "Good"
            },
            {
              questionId: "q4",
              question: "How satisfied were you with your work-life balance?",
              type: "multiple_choice",
              options: ["Very Satisfied", "Satisfied", "Neutral", "Dissatisfied"],
              answer: "Satisfied"
            }
          ]
        },
        { 
          id: 2, 
          name: "Sarah Johnson", 
          email: "sarah.johnson@sssihl.edu.in", 
          status: "completed", 
          progress: 100,
          completedDate: "2025-06-28",
          responses: [
            {
              questionId: "q1",
              question: "What were your key accomplishments in the first half of 2025?",
              type: "text",
              answer: "Successfully launched three major product features and received exceptional customer feedback."
            },
            {
              questionId: "q2",
              question: "What challenges did you face?",
              type: "textarea",
              answer: "Balancing multiple projects simultaneously was challenging. I improved by using better time management techniques and prioritization frameworks."
            },
            {
              questionId: "q3",
              question: "How would you rate your overall performance?",
              type: "multiple_choice",
              options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
              answer: "Excellent"
            },
            {
              questionId: "q4",
              question: "How satisfied were you with your work-life balance?",
              type: "multiple_choice",
              options: ["Very Satisfied", "Satisfied", "Neutral", "Dissatisfied"],
              answer: "Neutral"
            }
          ]
        },
        { 
          id: 3, 
          name: "Michael Chen", 
          email: "michael.chen@sssihl.edu.in", 
          status: "completed", 
          progress: 100,
          completedDate: "2025-06-27",
          responses: [
            {
              questionId: "q1",
              question: "What were your key accomplishments in the first half of 2025?",
              type: "text",
              answer: "Improved system performance by 35% and mentored two junior developers."
            },
            {
              questionId: "q2",
              question: "What challenges did you face?",
              type: "textarea",
              answer: "Technical debt in legacy code made some optimizations difficult. Collaborated with the team to refactor critical components."
            },
            {
              questionId: "q3",
              question: "How would you rate your overall performance?",
              type: "multiple_choice",
              options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
              answer: "Good"
            },
            {
              questionId: "q4",
              question: "How satisfied were you with your work-life balance?",
              type: "multiple_choice",
              options: ["Very Satisfied", "Satisfied", "Neutral", "Dissatisfied"],
              answer: "Very Satisfied"
            }
          ]
        }
      ],
      questions: [
        {
          id: "q1",
          type: "text",
          question: "What were your key accomplishments in the first half of 2025?",
          required: true
        },
        {
          id: "q2",
          type: "textarea",
          question: "What challenges did you face?",
          required: true
        },
        {
          id: "q3",
          type: "multiple_choice",
          question: "How would you rate your overall performance?",
          options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
          required: true
        },
        {
          id: "q4",
          type: "multiple_choice",
          question: "How satisfied were you with your work-life balance?",
          options: ["Very Satisfied", "Satisfied", "Neutral", "Dissatisfied"],
          required: true
        }
      ]
    },
    {
      id: 101,
      name: "Annual Performance Review 2025",
      createdDate: "2025-01-01",
      dueDate: "2025-01-31",
      completedDate: "2025-01-30",
      assignedTo: [
        { 
          id: 4, 
          name: "Emily Davis", 
          email: "emily.davis@sssihl.edu.in", 
          status: "completed", 
          progress: 100,
          completedDate: "2025-01-28",
          responses: [
            {
              questionId: "q1",
              question: "Summarize your achievements in 2025.",
              type: "textarea",
              answer: "Delivered 5 major projects on time, improved team efficiency by 25%, and received positive feedback from stakeholders."
            },
            {
              questionId: "q2",
              question: "How would you rate your technical skills development?",
              type: "multiple_choice",
              options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
              answer: "Excellent"
            },
            {
              questionId: "q3",
              question: "What is your top achievement of 2025?",
              type: "text",
              answer: "Successfully architected and deployed a real-time analytics platform used by 10,000+ users."
            }
          ]
        },
        { 
          id: 5, 
          name: "David Wilson", 
          email: "david.wilson@sssihl.edu.in", 
          status: "completed", 
          progress: 100,
          completedDate: "2025-01-30",
          responses: [
            {
              questionId: "q1",
              question: "Summarize your achievements in 2025.",
              type: "textarea",
              answer: "Led team transformation initiatives and implemented new development practices that increased productivity by 30%."
            },
            {
              questionId: "q2",
              question: "How would you rate your technical skills development?",
              type: "multiple_choice",
              options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
              answer: "Good"
            },
            {
              questionId: "q3",
              question: "What is your top achievement of 2025?",
              type: "text",
              answer: "Built and scaled a microservices architecture handling 1M+ daily requests."
            }
          ]
        }
      ],
      questions: [
        {
          id: "q1",
          type: "textarea",
          question: "Summarize your achievements in 2025.",
          required: true
        },
        {
          id: "q2",
          type: "multiple_choice",
          question: "How would you rate your technical skills development?",
          options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
          required: true
        },
        {
          id: "q3",
          type: "text",
          question: "What is your top achievement of 2025?",
          required: true
        }
      ]
    }
  ]
}

export default function AppraisalManagementPage() {
  const [pendingAppraisals, setPendingAppraisals] = useState(mockAppraisalsData.pending)
  const [completedAppraisals, setCompletedAppraisals] = useState(mockAppraisalsData.completed)
  const [selectedAppraisal, setSelectedAppraisal] = useState(null)
  const [selectedEmployee, setSelectedEmployee] = useState(null)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isAssignDialogOpen, setIsAssignDialogOpen] = useState(false)
  const [activeTab, setActiveTab] = useState("pending")
  const [selectedEmployeeIds, setSelectedEmployeeIds] = useState([])
  const [searchQuery, setSearchQuery] = useState("")

  // Create appraisal form state
  const [newAppraisal, setNewAppraisal] = useState({
    name: "",
    dueDate: "",
    questions: []
  })
  const [currentQuestion, setCurrentQuestion] = useState({
    question: "",
    type: "text",
    options: [],
    required: true
  })
  const [optionInput, setOptionInput] = useState("")

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    })
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "in_progress":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">In Progress</Badge>
      case "not_started":
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Not Started</Badge>
      case "completed":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Completed</Badge>
      default:
        return null
    }
  }

  const handleViewResponses = (appraisal, employee) => {
    setSelectedAppraisal(appraisal)
    setSelectedEmployee(employee)
    setIsViewDialogOpen(true)
  }

  const handleAddOption = () => {
    if (optionInput.trim()) {
      setCurrentQuestion(prev => ({
        ...prev,
        options: [...prev.options, optionInput.trim()]
      }))
      setOptionInput("")
    }
  }

  const handleRemoveOption = (index) => {
    setCurrentQuestion(prev => ({
      ...prev,
      options: prev.options.filter((_, i) => i !== index)
    }))
  }

  const handleAddQuestion = () => {
    if (!currentQuestion.question.trim()) {
      toast.error("Please enter a question")
      return
    }

    if (currentQuestion.type === "multiple_choice" && currentQuestion.options.length === 0) {
      toast.error("Please add at least one option for multiple choice questions")
      return
    }

    const question = {
      id: `q${newAppraisal.questions.length + 1}`,
      ...currentQuestion,
      options: currentQuestion.type === "multiple_choice" ? currentQuestion.options : undefined
    }

    setNewAppraisal(prev => ({
      ...prev,
      questions: [...prev.questions, question]
    }))

    // Reset current question
    setCurrentQuestion({
      question: "",
      type: "text",
      options: [],
      required: true
    })
    setOptionInput("")
    toast.success("Question added successfully")
  }

  const handleRemoveQuestion = (index) => {
    setNewAppraisal(prev => ({
      ...prev,
      questions: prev.questions.filter((_, i) => i !== index)
    }))
    toast.success("Question removed")
  }

  const handleCreateAppraisal = () => {
    if (!newAppraisal.name.trim()) {
      toast.error("Please enter appraisal name")
      return
    }

    if (!newAppraisal.dueDate) {
      toast.error("Please select a due date")
      return
    }

    if (newAppraisal.questions.length === 0) {
      toast.error("Please add at least one question")
      return
    }

    // Create new appraisal
    const appraisal = {
      id: Date.now(),
      name: newAppraisal.name,
      createdDate: new Date().toISOString().split('T')[0],
      dueDate: newAppraisal.dueDate,
      assignedTo: [],
      questions: newAppraisal.questions
    }

    setPendingAppraisals(prev => [appraisal, ...prev])
    
    // Reset form
    setNewAppraisal({
      name: "",
      dueDate: "",
      questions: []
    })
    setCurrentQuestion({
      question: "",
      type: "text",
      options: [],
      required: true
    })
    setIsCreateDialogOpen(false)
    toast.success("Appraisal created successfully!")
  }

  const handleOpenAssignDialog = (appraisal) => {
    setSelectedAppraisal(appraisal)
    // Pre-select already assigned employees
    const assignedIds = appraisal.assignedTo.map(emp => emp.id)
    setSelectedEmployeeIds(assignedIds)
    setSearchQuery("")
    setIsAssignDialogOpen(true)
  }

  const handleToggleEmployee = (employeeId) => {
    setSelectedEmployeeIds(prev => {
      if (prev.includes(employeeId)) {
        return prev.filter(id => id !== employeeId)
      } else {
        return [...prev, employeeId]
      }
    })
  }

  const handleSelectAllEmployees = () => {
    const filteredEmployees = getFilteredEmployees()
    const allFiltered = filteredEmployees.map(emp => emp.id)
    
    // If all filtered employees are selected, deselect them
    const allSelected = allFiltered.every(id => selectedEmployeeIds.includes(id))
    
    if (allSelected) {
      setSelectedEmployeeIds(prev => prev.filter(id => !allFiltered.includes(id)))
    } else {
      // Add all filtered employees that aren't already selected
      setSelectedEmployeeIds(prev => [...new Set([...prev, ...allFiltered])])
    }
  }

  const handleAssignEmployees = () => {
    if (selectedEmployeeIds.length === 0) {
      toast.error("Please select at least one employee")
      return
    }

    // Update the appraisal with assigned employees
    setPendingAppraisals(prev => prev.map(appraisal => {
      if (appraisal.id === selectedAppraisal.id) {
        // Get existing assignments that should be kept
        const existingAssignments = appraisal.assignedTo.filter(emp => 
          selectedEmployeeIds.includes(emp.id)
        )
        
        // Get new assignments
        const newAssignments = selectedEmployeeIds
          .filter(empId => !appraisal.assignedTo.some(emp => emp.id === empId))
          .map(empId => {
            const employee = mockEmployees.find(e => e.id === empId)
            return {
              id: employee.id,
              name: employee.name,
              email: employee.email,
              status: "not_started",
              progress: 0
            }
          })
        
        return {
          ...appraisal,
          assignedTo: [...existingAssignments, ...newAssignments]
        }
      }
      return appraisal
    }))

    setIsAssignDialogOpen(false)
    toast.success(`Successfully assigned appraisal to ${selectedEmployeeIds.length} employee(s)`)
  }

  const getFilteredEmployees = () => {
    if (!searchQuery.trim()) return mockEmployees
    
    const query = searchQuery.toLowerCase()
    return mockEmployees.filter(emp => 
      emp.name.toLowerCase().includes(query) ||
      emp.email.toLowerCase().includes(query) ||
      emp.department.toLowerCase().includes(query) ||
      emp.designation.toLowerCase().includes(query)
    )
  }

  const calculateStats = () => {
    const totalPending = pendingAppraisals.reduce((sum, appraisal) => sum + appraisal.assignedTo.length, 0)
    const totalCompleted = completedAppraisals.reduce((sum, appraisal) => {
      return sum + appraisal.assignedTo.filter(emp => emp.status === "completed").length
    }, 0)
    const pendingNotStarted = pendingAppraisals.reduce((sum, appraisal) => {
      return sum + appraisal.assignedTo.filter(emp => emp.status === "not_started").length
    }, 0)

    return { totalPending, totalCompleted, pendingNotStarted }
  }

  const stats = calculateStats()

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Appraisal Management</h1>
          <p className="text-muted-foreground mt-1">
            Create and manage employee performance appraisals
          </p>
        </div>
        <Button onClick={() => setIsCreateDialogOpen(true)} className="gap-2">
          <Plus className="h-4 w-4" />
          Create Appraisal
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Pending</p>
                <p className="text-3xl font-bold mt-2">{stats.totalPending}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                <Clock className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Not Started</p>
                <p className="text-3xl font-bold mt-2">{stats.pendingNotStarted}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-orange-100 flex items-center justify-center">
                <AlertCircle className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Completed</p>
                <p className="text-3xl font-bold mt-2">{stats.totalCompleted}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-100 flex items-center justify-center">
                <CheckCircle2 className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b">
        <button
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === "pending" 
              ? "border-b-2 border-primary text-primary" 
              : "text-muted-foreground hover:text-foreground"
          }`}
          onClick={() => setActiveTab("pending")}
        >
          Pending Appraisals ({pendingAppraisals.length})
        </button>
        <button
          className={`px-4 py-2 font-medium transition-colors ${
            activeTab === "completed" 
              ? "border-b-2 border-primary text-primary" 
              : "text-muted-foreground hover:text-foreground"
          }`}
          onClick={() => setActiveTab("completed")}
        >
          Completed Appraisals ({completedAppraisals.length})
        </button>
      </div>

      {/* Pending Appraisals Tab */}
      {activeTab === "pending" && (
        <div className="space-y-4">
          {pendingAppraisals.map((appraisal) => (
            <Card key={appraisal.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{appraisal.name}</CardTitle>
                    <CardDescription className="flex items-center gap-4 mt-2">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        Created: {formatDate(appraisal.createdDate)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        Due: {formatDate(appraisal.dueDate)}
                      </span>
                    </CardDescription>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                      {appraisal.assignedTo.length} Assigned
                    </Badge>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="gap-2"
                      onClick={() => handleOpenAssignDialog(appraisal)}
                    >
                      <UserPlus className="h-4 w-4" />
                      Assign Employees
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm font-medium">Assigned Employees:</div>
                  {appraisal.assignedTo.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No employees assigned yet</p>
                  ) : (
                    <div className="space-y-2">
                      {appraisal.assignedTo.map((employee) => (
                        <div 
                          key={employee.id} 
                          className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex-1">
                            <p className="font-medium">{employee.name}</p>
                            <p className="text-sm text-muted-foreground">{employee.email}</p>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="text-right">
                              <div className="text-sm font-medium">{employee.progress}%</div>
                              <div className="text-xs text-muted-foreground">Progress</div>
                            </div>
                            {getStatusBadge(employee.status)}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Completed Appraisals Tab */}
      {activeTab === "completed" && (
        <div className="space-y-4">
          {completedAppraisals.map((appraisal) => (
            <Card key={appraisal.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{appraisal.name}</CardTitle>
                    <CardDescription className="flex items-center gap-4 mt-2">
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        Created: {formatDate(appraisal.createdDate)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        Due: {formatDate(appraisal.dueDate)}
                      </span>
                      <span className="flex items-center gap-1">
                        <CheckCircle2 className="h-4 w-4" />
                        Completed: {formatDate(appraisal.completedDate)}
                      </span>
                    </CardDescription>
                  </div>
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    {appraisal.assignedTo.filter(e => e.status === "completed").length} Completed
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="text-sm font-medium">Responses:</div>
                  <div className="space-y-2">
                    {appraisal.assignedTo.map((employee) => (
                      <div 
                        key={employee.id} 
                        className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50 transition-colors cursor-pointer"
                        onClick={() => handleViewResponses(appraisal, employee)}
                      >
                        <div className="flex-1">
                          <p className="font-medium">{employee.name}</p>
                          <p className="text-sm text-muted-foreground">{employee.email}</p>
                          <p className="text-xs text-muted-foreground mt-1">
                            Completed: {formatDate(employee.completedDate)}
                          </p>
                        </div>
                        <div className="flex items-center gap-3">
                          <Button variant="ghost" size="sm" className="gap-2">
                            <Eye className="h-4 w-4" />
                            View Responses
                          </Button>
                          {getStatusBadge(employee.status)}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* View Responses Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedAppraisal?.name}</DialogTitle>
            <DialogDescription>
              Responses from {selectedEmployee?.name} - Completed on {selectedEmployee?.completedDate && formatDate(selectedEmployee.completedDate)}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {selectedEmployee?.responses?.map((response, index) => (
              <div key={response.questionId} className="space-y-3">
                <Label className="text-base font-medium">
                  {index + 1}. {response.question}
                </Label>
                
                {response.type === "text" && (
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm">{response.answer}</p>
                  </div>
                )}

                {response.type === "textarea" && (
                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm whitespace-pre-wrap">{response.answer}</p>
                  </div>
                )}

                {response.type === "multiple_choice" && (
                  <div className="space-y-2">
                    {response.options.map((option) => (
                      <div 
                        key={option} 
                        className={`p-3 rounded-lg border ${
                          option === response.answer 
                            ? "bg-primary/10 border-primary font-medium" 
                            : "bg-muted"
                        }`}
                      >
                        {option}
                        {option === response.answer && " ✓"}
                      </div>
                    ))}
                  </div>
                )}

                {index < selectedEmployee.responses.length - 1 && (
                  <Separator className="mt-4" />
                )}
              </div>
            ))}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Create Appraisal Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Create New Appraisal</DialogTitle>
            <DialogDescription>
              Set up a new appraisal form with custom questions
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Basic Info */}
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="appraisal-name">Appraisal Name *</Label>
                <Input
                  id="appraisal-name"
                  placeholder="e.g., Annual Performance Review 2026"
                  value={newAppraisal.name}
                  onChange={(e) => setNewAppraisal(prev => ({ ...prev, name: e.target.value }))}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="due-date">Due Date *</Label>
                <Input
                  id="due-date"
                  type="date"
                  value={newAppraisal.dueDate}
                  onChange={(e) => setNewAppraisal(prev => ({ ...prev, dueDate: e.target.value }))}
                />
              </div>
            </div>

            <Separator />

            {/* Questions Section */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Questions</h3>
              
              {/* Display added questions */}
              {newAppraisal.questions.length > 0 && (
                <div className="space-y-3 mb-4">
                  {newAppraisal.questions.map((q, index) => (
                    <Card key={q.id}>
                      <CardContent className="pt-4">
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Badge variant="outline">{q.type.replace('_', ' ')}</Badge>
                              {q.required && <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Required</Badge>}
                            </div>
                            <p className="font-medium">{index + 1}. {q.question}</p>
                            {q.options && (
                              <div className="mt-2 ml-4 space-y-1">
                                {q.options.map((opt, i) => (
                                  <p key={i} className="text-sm text-muted-foreground">• {opt}</p>
                                ))}
                              </div>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleRemoveQuestion(index)}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}

              {/* Add New Question Form */}
              <Card className="border-dashed">
                <CardContent className="pt-6">
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="question-text">Question Text *</Label>
                      <Textarea
                        id="question-text"
                        placeholder="Enter your question..."
                        value={currentQuestion.question}
                        onChange={(e) => setCurrentQuestion(prev => ({ ...prev, question: e.target.value }))}
                        rows={2}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="question-type">Question Type *</Label>
                        <Select
                          value={currentQuestion.type}
                          onValueChange={(value) => setCurrentQuestion(prev => ({ 
                            ...prev, 
                            type: value,
                            options: value === "multiple_choice" ? prev.options : []
                          }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="text">Short Text</SelectItem>
                            <SelectItem value="textarea">Long Text</SelectItem>
                            <SelectItem value="multiple_choice">Multiple Choice</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="required">Required</Label>
                        <Select
                          value={currentQuestion.required ? "yes" : "no"}
                          onValueChange={(value) => setCurrentQuestion(prev => ({ ...prev, required: value === "yes" }))}
                        >
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="yes">Yes</SelectItem>
                            <SelectItem value="no">No</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    {/* Multiple Choice Options */}
                    {currentQuestion.type === "multiple_choice" && (
                      <div className="space-y-2">
                        <Label>Options</Label>
                        <div className="flex gap-2">
                          <Input
                            placeholder="Enter an option..."
                            value={optionInput}
                            onChange={(e) => setOptionInput(e.target.value)}
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault()
                                handleAddOption()
                              }
                            }}
                          />
                          <Button type="button" onClick={handleAddOption} variant="outline">
                            Add
                          </Button>
                        </div>
                        {currentQuestion.options.length > 0 && (
                          <div className="space-y-1 mt-2">
                            {currentQuestion.options.map((option, index) => (
                              <div key={index} className="flex items-center justify-between p-2 bg-muted rounded">
                                <span className="text-sm">{option}</span>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleRemoveOption(index)}
                                >
                                  <Trash2 className="h-3 w-3" />
                                </Button>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}

                    <Button type="button" onClick={handleAddQuestion} variant="outline" className="w-full">
                      <Plus className="h-4 w-4 mr-2" />
                      Add Question
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateAppraisal}>
              Create Appraisal
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Assign Employees Dialog */}
      <Dialog open={isAssignDialogOpen} onOpenChange={setIsAssignDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle>Assign Employees</DialogTitle>
            <DialogDescription>
              Select employees to assign to "{selectedAppraisal?.name}"
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 flex-1 overflow-hidden flex flex-col">
            {/* Search and Select All */}
            <div className="space-y-3">
              <Input
                placeholder="Search by name, email, department, or designation..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full"
              />
              
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Checkbox 
                    id="select-all"
                    checked={
                      getFilteredEmployees().length > 0 && 
                      getFilteredEmployees().every(emp => selectedEmployeeIds.includes(emp.id))
                    }
                    onCheckedChange={handleSelectAllEmployees}
                  />
                  <Label 
                    htmlFor="select-all" 
                    className="text-sm font-medium cursor-pointer"
                  >
                    Select All ({getFilteredEmployees().length})
                  </Label>
                </div>
                <div className="text-sm text-muted-foreground">
                  {selectedEmployeeIds.length} selected
                </div>
              </div>
            </div>

            {/* Employee List */}
            <div className="flex-1 overflow-y-auto border rounded-lg">
              <div className="space-y-1 p-2">
                {getFilteredEmployees().length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    No employees found matching your search
                  </div>
                ) : (
                  getFilteredEmployees().map((employee) => {
                    const isSelected = selectedEmployeeIds.includes(employee.id)
                    const isAlreadyAssigned = selectedAppraisal?.assignedTo.some(emp => emp.id === employee.id)
                    
                    return (
                      <div
                        key={employee.id}
                        className={`flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors cursor-pointer ${
                          isSelected ? "bg-muted" : ""
                        }`}
                        onClick={() => handleToggleEmployee(employee.id)}
                      >
                        <Checkbox
                          checked={isSelected}
                          onCheckedChange={() => handleToggleEmployee(employee.id)}
                          onClick={(e) => e.stopPropagation()}
                        />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <p className="font-medium">{employee.name}</p>
                            {isAlreadyAssigned && (
                              <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200 text-xs">
                                Already Assigned
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground truncate">{employee.email}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-xs">{employee.department}</Badge>
                            <span className="text-xs text-muted-foreground">{employee.designation}</span>
                          </div>
                        </div>
                      </div>
                    )
                  })
                )}
              </div>
            </div>

            {/* Summary */}
            {selectedEmployeeIds.length > 0 && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm font-medium">
                  Ready to assign to {selectedEmployeeIds.length} employee{selectedEmployeeIds.length !== 1 ? 's' : ''}
                </p>
              </div>
            )}
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAssignDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleAssignEmployees} disabled={selectedEmployeeIds.length === 0}>
              Assign to {selectedEmployeeIds.length} Employee{selectedEmployeeIds.length !== 1 ? 's' : ''}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
