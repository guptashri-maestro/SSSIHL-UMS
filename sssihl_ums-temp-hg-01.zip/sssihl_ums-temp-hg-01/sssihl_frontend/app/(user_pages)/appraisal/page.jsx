"use client"

import { useState } from "react"
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog"
import { Calendar, Clock, CheckCircle2, AlertCircle, FileText } from "lucide-react"
import { toast } from "sonner"

// Mock data for appraisals
const mockAppraisals = {
  active: [
    {
      id: 1,
      name: "Annual Performance Review 2026",
      assignedDate: "2026-01-01",
      dueDate: "2026-01-31",
      status: "in_progress",
      progress: 60,
      questions: [
        {
          id: "q1",
          type: "text",
          question: "What were your key accomplishments this year?",
          answer: "Successfully delivered 3 major projects and mentored 2 junior developers."
        },
        {
          id: "q2",
          type: "textarea",
          question: "Describe a challenging situation you faced and how you overcame it.",
          answer: ""
        },
        {
          id: "q3",
          type: "multiple_choice",
          question: "How would you rate your collaboration with team members?",
          options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
          answer: ""
        },
        {
          id: "q4",
          type: "multiple_choice",
          question: "How satisfied are you with your current role?",
          options: ["Very Satisfied", "Satisfied", "Neutral", "Dissatisfied", "Very Dissatisfied"],
          answer: "Satisfied"
        },
        {
          id: "q5",
          type: "textarea",
          question: "What are your professional development goals for the next year?",
          answer: ""
        },
        {
          id: "q6",
          type: "multiple_choice",
          question: "How would you rate the support you receive from your manager?",
          options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
          answer: ""
        },
        {
          id: "q7",
          type: "text",
          question: "What new skills or technologies would you like to learn?",
          answer: ""
        }
      ]
    },
    {
      id: 2,
      name: "Q1 Objectives Review",
      assignedDate: "2026-01-05",
      dueDate: "2026-01-20",
      status: "not_started",
      progress: 0,
      questions: [
        {
          id: "q1",
          type: "textarea",
          question: "List your objectives for Q1 2026.",
          answer: ""
        },
        {
          id: "q2",
          type: "multiple_choice",
          question: "How confident are you in achieving these objectives?",
          options: ["Very Confident", "Confident", "Somewhat Confident", "Not Confident"],
          answer: ""
        },
        {
          id: "q3",
          type: "textarea",
          question: "What resources or support do you need to achieve your objectives?",
          answer: ""
        }
      ]
    }
  ],
  completed: [
    {
      id: 100,
      name: "Mid-Year Review 2025",
      assignedDate: "2025-06-01",
      dueDate: "2025-06-30",
      completedDate: "2025-06-25",
      status: "completed",
      questions: [
        {
          id: "q1",
          type: "text",
          question: "What were your key accomplishments in the first half of 2025?",
          answer: "Led the migration of legacy systems to cloud infrastructure, resulting in 40% cost reduction."
        },
        {
          id: "q2",
          type: "textarea",
          question: "What challenges did you face?",
          answer: "The main challenge was coordinating with multiple teams across different time zones. We overcame this by implementing better communication protocols and using async collaboration tools."
        },
        {
          id: "q3",
          type: "multiple_choice",
          question: "How would you rate your overall performance?",
          options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
          answer: "Good"
        },
        {
          id: "q4",
          type: "multiple_choice",
          question: "How satisfied were you with your work-life balance?",
          options: ["Very Satisfied", "Satisfied", "Neutral", "Dissatisfied"],
          answer: "Satisfied"
        }
      ]
    },
    {
      id: 101,
      name: "Annual Performance Review 2025",
      assignedDate: "2025-01-01",
      dueDate: "2025-01-31",
      completedDate: "2025-01-28",
      status: "completed",
      questions: [
        {
          id: "q1",
          type: "textarea",
          question: "Summarize your achievements in 2025.",
          answer: "Delivered 5 major projects on time, improved team efficiency by 25%, and received positive feedback from stakeholders."
        },
        {
          id: "q2",
          type: "multiple_choice",
          question: "How would you rate your technical skills development?",
          options: ["Excellent", "Good", "Satisfactory", "Needs Improvement"],
          answer: "Excellent"
        },
        {
          id: "q3",
          type: "text",
          question: "What is your top achievement of 2025?",
          answer: "Successfully architected and deployed a real-time analytics platform used by 10,000+ users."
        }
      ]
    }
  ]
}

export default function AppraisalPage() {
  const [activeAppraisals, setActiveAppraisals] = useState(mockAppraisals.active)
  const [completedAppraisals, setCompletedAppraisals] = useState(mockAppraisals.completed)
  const [selectedAppraisal, setSelectedAppraisal] = useState(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [isReadOnly, setIsReadOnly] = useState(false)
  const [formData, setFormData] = useState({})

  // Calculate dashboard stats
  const pendingCount = activeAppraisals.filter(a => a.status === "not_started").length
  const nextDueDate = activeAppraisals.length > 0 
    ? activeAppraisals.reduce((earliest, curr) => 
        new Date(curr.dueDate) < new Date(earliest.dueDate) ? curr : earliest
      ).dueDate 
    : null

  const handleOpenAppraisal = (appraisal, readOnly = false) => {
    setSelectedAppraisal(appraisal)
    setIsReadOnly(readOnly)
    
    // Initialize form data with existing answers
    const initialData = {}
    appraisal.questions.forEach(q => {
      initialData[q.id] = q.answer || ""
    })
    setFormData(initialData)
    setIsDialogOpen(true)
  }

  const handleInputChange = (questionId, value) => {
    setFormData(prev => ({
      ...prev,
      [questionId]: value
    }))
  }

  const handleSaveProgress = () => {
    // Update the appraisal with current form data
    const updatedAppraisals = activeAppraisals.map(appraisal => {
      if (appraisal.id === selectedAppraisal.id) {
        const updatedQuestions = appraisal.questions.map(q => ({
          ...q,
          answer: formData[q.id] || q.answer
        }))
        
        // Calculate progress
        const answeredCount = updatedQuestions.filter(q => q.answer && q.answer.trim() !== "").length
        const progress = Math.round((answeredCount / updatedQuestions.length) * 100)
        
        return {
          ...appraisal,
          questions: updatedQuestions,
          progress,
          status: progress > 0 ? "in_progress" : "not_started"
        }
      }
      return appraisal
    })
    
    setActiveAppraisals(updatedAppraisals)
    toast.success("Progress saved successfully!")
  }

  const handleSubmitAppraisal = () => {
    // Check if all questions are answered
    const allAnswered = selectedAppraisal.questions.every(q => {
      const answer = formData[q.id]
      return answer && answer.trim() !== ""
    })
    
    if (!allAnswered) {
      toast.error("Please answer all questions before submitting.")
      return
    }

    // Move appraisal from active to completed
    const completedAppraisal = {
      ...selectedAppraisal,
      status: "completed",
      completedDate: new Date().toISOString().split('T')[0],
      progress: 100,
      questions: selectedAppraisal.questions.map(q => ({
        ...q,
        answer: formData[q.id]
      }))
    }
    
    setCompletedAppraisals(prev => [completedAppraisal, ...prev])
    setActiveAppraisals(prev => prev.filter(a => a.id !== selectedAppraisal.id))
    
    setIsDialogOpen(false)
    toast.success("Appraisal submitted successfully! Thank you for your feedback.", {
      duration: 5000,
    })
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case "in_progress":
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">In Progress</Badge>
      case "not_started":
        return <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">Not Started</Badge>
      case "completed":
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Completed</Badge>
      default:
        return null
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    })
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold">Appraisals</h1>
        <p className="text-muted-foreground mt-1">
          Complete your performance appraisals and track your progress
        </p>
      </div>

      {/* Dashboard Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending Appraisals</p>
                <p className="text-3xl font-bold mt-2">{pendingCount}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-orange-100 flex items-center justify-center">
                <AlertCircle className="h-6 w-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Next Due Date</p>
                <p className="text-xl font-bold mt-2">
                  {nextDueDate ? formatDate(nextDueDate) : "No upcoming appraisals"}
                </p>
              </div>
              <div className="h-12 w-12 rounded-full bg-blue-100 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Appraisals */}
      <Card>
        <CardHeader>
          <CardTitle>Active Appraisals</CardTitle>
          <CardDescription>
            Complete these appraisals before the due date
          </CardDescription>
        </CardHeader>
        <CardContent>
          {activeAppraisals.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No active appraisals at the moment</p>
            </div>
          ) : (
            <div className="space-y-4">
              {activeAppraisals.map((appraisal) => (
                <Card 
                  key={appraisal.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => handleOpenAppraisal(appraisal, false)}
                >
                  <CardContent className="pt-6">
                    <div className="space-y-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="font-semibold text-lg">{appraisal.name}</h3>
                          <div className="flex flex-wrap gap-4 mt-2 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              <span>Assigned: {formatDate(appraisal.assignedDate)}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Clock className="h-4 w-4" />
                              <span>Due: {formatDate(appraisal.dueDate)}</span>
                            </div>
                          </div>
                        </div>
                        {getStatusBadge(appraisal.status)}
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium">{appraisal.progress}%</span>
                        </div>
                        <Progress value={appraisal.progress} className="h-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Completed Appraisals */}
      <Card>
        <CardHeader>
          <CardTitle>Completed Appraisals</CardTitle>
          <CardDescription>
            View your previously submitted appraisals
          </CardDescription>
        </CardHeader>
        <CardContent>
          {completedAppraisals.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <CheckCircle2 className="h-12 w-12 mx-auto mb-3 opacity-50" />
              <p>No completed appraisals yet</p>
            </div>
          ) : (
            <div className="space-y-4">
              {completedAppraisals.map((appraisal) => (
                <Card 
                  key={appraisal.id} 
                  className="cursor-pointer hover:shadow-md transition-shadow"
                  onClick={() => handleOpenAppraisal(appraisal, true)}
                >
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{appraisal.name}</h3>
                        <div className="flex flex-wrap gap-4 mt-2 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            <span>Assigned: {formatDate(appraisal.assignedDate)}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <CheckCircle2 className="h-4 w-4" />
                            <span>Completed: {formatDate(appraisal.completedDate)}</span>
                          </div>
                        </div>
                      </div>
                      {getStatusBadge(appraisal.status)}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Appraisal Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedAppraisal?.name}</DialogTitle>
            <DialogDescription>
              {isReadOnly 
                ? `Completed on ${formatDate(selectedAppraisal?.completedDate)}`
                : `Due date: ${formatDate(selectedAppraisal?.dueDate)}`
              }
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {selectedAppraisal?.questions.map((question, index) => (
              <div key={question.id} className="space-y-3">
                <Label className="text-base font-medium">
                  {index + 1}. {question.question}
                </Label>
                
                {question.type === "text" && (
                  <Input
                    value={formData[question.id] || ""}
                    onChange={(e) => handleInputChange(question.id, e.target.value)}
                    placeholder="Enter your answer..."
                    disabled={isReadOnly}
                    className={isReadOnly ? "bg-muted" : ""}
                  />
                )}

                {question.type === "textarea" && (
                  <Textarea
                    value={formData[question.id] || ""}
                    onChange={(e) => handleInputChange(question.id, e.target.value)}
                    placeholder="Enter your detailed answer..."
                    rows={4}
                    disabled={isReadOnly}
                    className={isReadOnly ? "bg-muted" : ""}
                  />
                )}

                {question.type === "multiple_choice" && (
                  <RadioGroup
                    value={formData[question.id] || ""}
                    onValueChange={(value) => handleInputChange(question.id, value)}
                    disabled={isReadOnly}
                  >
                    {question.options.map((option) => (
                      <div key={option} className="flex items-center space-x-2">
                        <RadioGroupItem 
                          value={option} 
                          id={`${question.id}-${option}`}
                          disabled={isReadOnly}
                        />
                        <Label 
                          htmlFor={`${question.id}-${option}`}
                          className={`font-normal ${isReadOnly ? "cursor-default" : "cursor-pointer"}`}
                        >
                          {option}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}

                {index < selectedAppraisal.questions.length - 1 && (
                  <Separator className="mt-4" />
                )}
              </div>
            ))}
          </div>

          {!isReadOnly && (
            <DialogFooter className="gap-2">
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button variant="outline" onClick={handleSaveProgress}>
                Save Progress
              </Button>
              <Button onClick={handleSubmitAppraisal}>
                Submit Appraisal
              </Button>
            </DialogFooter>
          )}

          {isReadOnly && (
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
