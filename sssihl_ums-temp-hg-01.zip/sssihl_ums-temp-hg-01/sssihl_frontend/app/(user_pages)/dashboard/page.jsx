'use client'

import React from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { User, FileText, TrendingUp, Users, UserPlus, UserMinus, Calendar, ClipboardCheck } from 'lucide-react'

import { useState, useEffect } from 'react'
import { LoadingSpinner } from '@/components/loading-state'
import { useUser } from '../../lib/auth/UserProvider'

const DashboardPage = () => {

  const curr_user = useUser();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (curr_user.loading) {
      return;
    }
    
    setLoading(false);
  }, [curr_user, curr_user.loading]);


  const employeePages = [
    {
      title: 'Profile',
      description: 'View and manage your personal information',
      icon: User,
      href: '/profile',
      color: 'text-blue-600'
    },
    {
      title: 'Leave Requests',
      description: 'Submit and track your leave requests',
      icon: FileText,
      href: '/leave-requests',
      color: 'text-green-600'
    },
    {
      title: 'Appraisal',
      description: 'View and submit appraisal requests',
      icon: TrendingUp,
      href: '/appraisal',
      color: 'text-purple-600'
    }
  ]

  const adminPages = [
    {
      title: 'Employee Management',
      description: 'View and manage all employee records',
      icon: Users,
      href: '/admin/employee-management',
      color: 'text-orange-600'
    },
    {
      title: 'Create Employee',
      description: 'Add a new employee to the system',
      icon: UserPlus,
      href: '/admin/employee-management/create-employee',
      color: 'text-green-600'
    },
    {
      title: 'Remove Employee',
      description: 'Remove or deactivate employee accounts',
      icon: UserMinus,
      href: '/admin/employee-management/remove-employee',
      color: 'text-red-600'
    },
    {
      title: 'Leave Management',
      description: 'Review and manage employee leave requests',
      icon: Calendar,
      href: '/admin/leave-management',
      color: 'text-blue-600'
    },
    {
      title: 'Appraisal Management',
      description: 'Manage employee appraisals and reviews',
      icon: ClipboardCheck,
      href: '/admin/appraisal-management',
      color: 'text-purple-600'
    }
  ]

  if (loading) {
    return <LoadingSpinner />
  }

  return (
    <div className="container mx-auto p-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-2">
          Welcome back! Select a page to get started.
        </p>
      </div>

      {/* Employee Section */}
      <section>
        <h2 className="text-2xl font-semibold mb-4">Employee Services</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {employeePages.map((page) => {
            const Icon = page.icon
            return (
              <Link key={page.href} href={page.href}>
                <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg bg-gray-100 ${page.color}`}>
                        <Icon className="h-6 w-6" />
                      </div>
                      <CardTitle>{page.title}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardDescription>{page.description}</CardDescription>
                  </CardContent>
                </Card>
              </Link>
            )
          })}
        </div>
      </section>

      {/* Admin Section */}
      {curr_user.user && curr_user.user.role_nm === "admin" && (
        <section>
          <h2 className="text-2xl font-semibold mb-4">Admin Management</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {adminPages.map((page) => {
              const Icon = page.icon
              return (
                <Link key={page.href} href={page.href}>
                  <Card className="h-full hover:shadow-lg transition-shadow cursor-pointer border-orange-200">
                    <CardHeader>
                      <div className="flex items-center space-x-3">
                        <div className={`p-2 rounded-lg bg-gray-100 ${page.color}`}>
                          <Icon className="h-6 w-6" />
                        </div>
                        <CardTitle>{page.title}</CardTitle>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <CardDescription>{page.description}</CardDescription>
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        </section>
      )}
      
    </div>
  )
}

export default DashboardPage
