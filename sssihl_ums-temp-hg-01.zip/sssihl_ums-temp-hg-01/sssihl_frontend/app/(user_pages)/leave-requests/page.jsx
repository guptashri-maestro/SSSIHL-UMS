"use client"

import * as React from "react"
import { DayPicker } from 'react-day-picker'
import 'react-day-picker/style.css'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { CalendarDays, Plus, Clock, CheckCircle2, XCircle, AlertCircle } from 'lucide-react'

// Custom styles for leave days
const customStyles = `
  .leave-day {
    background-color: hsl(var(--primary)) !important;
    color: hsl(var(--primary-foreground)) !important;
    font-weight: 600 !important;
  }
`

// Dummy data for leave statistics
const leaveStats = {
  totalLeaves: 24,
  usedLeaves: 12,
  pendingLeaves: 2,
  remainingLeaves: 10
}

// Dummy data for taken leaves (for calendar display)
const takenLeaves = [
  { from: new Date(2026, 0, 5), to: new Date(2026, 0, 7), type: 'Sick Leave' },
  { from: new Date(2026, 0, 20), to: new Date(2026, 0, 21), type: 'Casual Leave' },
]

// Dummy data for previous leave requests
const previousRequests = [
  {
    id: 1,
    startDate: '2025-12-15',
    endDate: '2025-12-17',
    type: 'Annual Leave',
    reason: 'Family vacation',
    status: 'approved',
    appliedOn: '2025-12-01'
  },
  {
    id: 2,
    startDate: '2026-01-05',
    endDate: '2026-01-07',
    type: 'Sick Leave',
    reason: 'Medical appointment and recovery',
    status: 'approved',
    appliedOn: '2026-01-03'
  },
  {
    id: 3,
    startDate: '2026-01-20',
    endDate: '2026-01-21',
    type: 'Casual Leave',
    reason: 'Personal work',
    status: 'being reviewed',
    appliedOn: '2026-01-08'
  },
  {
    id: 4,
    startDate: '2025-11-10',
    endDate: '2025-11-12',
    type: 'Casual Leave',
    reason: 'Weekend trip',
    status: 'rejected',
    appliedOn: '2025-11-05'
  },
  {
    id: 5,
    startDate: '2026-02-14',
    endDate: '2026-02-16',
    type: 'Annual Leave',
    reason: 'Attending wedding ceremony',
    status: 'being reviewed',
    appliedOn: '2026-01-09'
  }
]

const leaveTypes = [
  'Annual Leave',
  'Sick Leave',
  'Casual Leave',
  'Maternity Leave',
  'Paternity Leave',
  'Emergency Leave',
  'Unpaid Leave'
]

export default function LeaveRequestsPage() {
  const [isModalOpen, setIsModalOpen] = React.useState(false)
  const [showSuccessAlert, setShowSuccessAlert] = React.useState(false)
  const [showErrorAlert, setShowErrorAlert] = React.useState(false)
  
  // Form state
  const [dateRange, setDateRange] = React.useState(undefined)
  const [leaveType, setLeaveType] = React.useState('')
  const [leaveReason, setLeaveReason] = React.useState('')

  const handleApplyLeave = () => {
    // Simulate API call
    if (dateRange?.from && dateRange?.to && leaveType && leaveReason) {
      setIsModalOpen(false)
      // Randomly show success or error for demo
      const isSuccess = Math.random() > 0.2
      if (isSuccess) {
        setShowSuccessAlert(true)
      } else {
        setShowErrorAlert(true)
      }
      // Reset form
      setDateRange(undefined)
      setLeaveType('')
      setLeaveReason('')
    }
  }

  const handleCancelModal = () => {
    setIsModalOpen(false)
    setDateRange(undefined)
    setLeaveType('')
    setLeaveReason('')
  }

  const getStatusBadge = (status) => {
    switch (status) {
      case 'approved':
        return (
          <Badge variant="default" className="bg-green-500 text-white hover:bg-green-600">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Approved
          </Badge>
        )
      case 'rejected':
        return (
          <Badge variant="destructive">
            <XCircle className="w-3 h-3 mr-1" />
            Rejected
          </Badge>
        )
      case 'being reviewed':
        return (
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200">
            <Clock className="w-3 h-3 mr-1" />
            Being Reviewed
          </Badge>
        )
      default:
        return null
    }
  }

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric' 
    })
  }

  // Create array of all leave days
  const leaveDays = []
  takenLeaves.forEach(leave => {
    const current = new Date(leave.from)
    const end = new Date(leave.to)
    
    while (current <= end) {
      leaveDays.push(new Date(current))
      current.setDate(current.getDate() + 1)
    }
  })

  console.log('Leave days array:', leaveDays)
  console.log('Taken leaves:', takenLeaves)

  return (
    <>
      <style dangerouslySetInnerHTML={{ __html: customStyles }} />
      <div className="container mx-auto p-6 space-y-6">
        {/* Page Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold">Leave Requests</h1>
            <p className="text-muted-foreground mt-1">Manage your leave applications and view leave history</p>
          </div>
          <Button onClick={() => setIsModalOpen(true)} size="lg">
            <Plus className="w-4 h-4 mr-2" />
            Apply for Leave
          </Button>
        </div>

      {/* Leave Statistics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Total Leaves</CardDescription>
            <CardTitle className="text-3xl">{leaveStats.totalLeaves}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Used Leaves</CardDescription>
            <CardTitle className="text-3xl text-blue-600">{leaveStats.usedLeaves}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Pending Approval</CardDescription>
            <CardTitle className="text-3xl text-yellow-600">{leaveStats.pendingLeaves}</CardTitle>
          </CardHeader>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Remaining Leaves</CardDescription>
            <CardTitle className="text-3xl text-green-600">{leaveStats.remainingLeaves}</CardTitle>
          </CardHeader>
        </Card>
      </div>

      {/* Calendar Display of Taken Leaves */}
      <Card>
        <CardHeader>
          <CardTitle>Leave Calendar</CardTitle>
          <CardDescription>View your approved and taken leaves</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="w-full overflow-x-auto">
            <div className="inline-block min-w-max mx-auto">
              <DayPicker
                mode="multiple"
                selected={leaveDays}
                numberOfMonths={2}
                disabled={() => true}
              />
            </div>
          </div>
          <div className="mt-6 pt-4 border-t">
            <p className="text-sm font-medium mb-3">Legend:</p>
            <div className="flex flex-wrap gap-4">
              {takenLeaves.map((leave, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <div className="w-3 h-3 rounded-full bg-primary"></div>
                  <span>
                    {leave.from.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - 
                    {leave.to.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}: {leave.type}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Previous Leave Requests */}
      <Card>
        <CardHeader>
          <CardTitle>Leave History</CardTitle>
          <CardDescription>View all your previous leave requests and their status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {previousRequests.map((request) => (
              <div 
                key={request.id} 
                className="flex flex-col md:flex-row md:items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <div className="space-y-2 flex-1">
                  <div className="flex items-center gap-3 flex-wrap">
                    <h3 className="font-semibold text-lg">{request.type}</h3>
                    {getStatusBadge(request.status)}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <CalendarDays className="w-4 h-4" />
                    <span>{formatDate(request.startDate)} - {formatDate(request.endDate)}</span>
                  </div>
                  <p className="text-sm"><span className="font-medium">Reason:</span> {request.reason}</p>
                  <p className="text-xs text-muted-foreground">Applied on: {formatDate(request.appliedOn)}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Apply Leave Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-background rounded-lg shadow-lg max-w-6xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-2xl font-bold mb-2">Apply for Leave</h2>
              <p className="text-muted-foreground mb-6">Select your leave dates and provide details</p>
              
              <div className="grid lg:grid-cols-[1.5fr,1fr] gap-8">
                {/* Calendar Side */}
                <div className="space-y-4">
                  <div>
                    <Label className="text-base font-semibold mb-4 block">Select Leave Dates</Label>
                    <DayPicker
                      mode="range"
                      selected={dateRange}
                      onSelect={setDateRange}
                      numberOfMonths={2}
                      disabled={(date) => date < new Date()}
                    />
                  </div>
                  {dateRange?.from && dateRange?.to && (
                    <div className="p-4 bg-muted/50 rounded-lg border">
                      <p className="text-sm font-semibold mb-2">Selected Range</p>
                      <p className="text-sm text-muted-foreground">
                        {dateRange.from.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })} - 
                        {dateRange.to.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
                      </p>
                      <p className="text-sm font-medium mt-2">
                        Duration: {Math.ceil((dateRange.to - dateRange.from) / (1000 * 60 * 60 * 24)) + 1} days
                      </p>
                    </div>
                  )}
                </div>

                {/* Form Side */}
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="leave-type" className="text-base font-semibold">Leave Type</Label>
                    <Select value={leaveType} onValueChange={setLeaveType}>
                      <SelectTrigger id="leave-type">
                        <SelectValue placeholder="Select leave type" />
                      </SelectTrigger>
                      <SelectContent>
                        {leaveTypes.map((type) => (
                          <SelectItem key={type} value={type}>
                            {type}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="leave-reason" className="text-base font-semibold">Reason for Leave</Label>
                    <Textarea
                      id="leave-reason"
                      placeholder="Please provide a reason for your leave request..."
                      value={leaveReason}
                      onChange={(e) => setLeaveReason(e.target.value)}
                      rows={6}
                      className="resize-none"
                    />
                  </div>

                  <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
                    <div className="flex items-start gap-2">
                      <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                      <div className="text-sm">
                        <p className="font-medium text-blue-900 dark:text-blue-100">Important Note</p>
                        <p className="text-blue-700 dark:text-blue-300 mt-1">
                          Your leave request will be reviewed by your supervisor. You will be notified once a decision is made.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Modal Actions */}
              <div className="flex justify-end gap-3 mt-6 pt-6 border-t">
                <Button variant="outline" onClick={handleCancelModal}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleApplyLeave}
                  disabled={!dateRange?.from || !dateRange?.to || !leaveType || !leaveReason}
                >
                  Submit Leave Request
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Alert */}
      <AlertDialog open={showSuccessAlert} onOpenChange={setShowSuccessAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-green-100 dark:bg-green-900 mx-auto mb-4">
              <CheckCircle2 className="w-6 h-6 text-green-600 dark:text-green-400" />
            </div>
            <AlertDialogTitle className="text-center">Leave Request Submitted Successfully!</AlertDialogTitle>
            <AlertDialogDescription className="text-center">
              Your leave request has been submitted and is now awaiting approval from your supervisor. 
              You will receive a notification once your request is reviewed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-center">
            <AlertDialogAction onClick={() => setShowSuccessAlert(false)}>
              Got it
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Error Alert */}
      <AlertDialog open={showErrorAlert} onOpenChange={setShowErrorAlert}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-100 dark:bg-red-900 mx-auto mb-4">
              <XCircle className="w-6 h-6 text-red-600 dark:text-red-400" />
            </div>
            <AlertDialogTitle className="text-center">Failed to Submit Leave Request</AlertDialogTitle>
            <AlertDialogDescription className="text-center">
              There was an error submitting your leave request. Please check your connection and try again. 
              If the problem persists, contact IT support.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="sm:justify-center">
            <AlertDialogAction onClick={() => setShowErrorAlert(false)}>
              Try Again
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      </div>
    </>
  )
}
