'use client'

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { useState, useEffect } from "react"

import { CustomTextInput } from "../../../components/custom-inputs"

import { useRouter } from "next/navigation"
import { useUser } from "../../lib/auth/UserProvider"

import { LoadingSpinner } from "../../../components/loading-state"

import { ErrorState } from "../../../components/error-state"
import { formatDate, formatDateTime } from "../../../utils/format_dates"

import { CustomDateInput } from "../../../components/custom-inputs"

import {
  Check,
  X,
  SquarePen,
  Eye,
  EyeOff,
  MapPin,
  FileText,
  Download
} from "lucide-react"

export default function ProfilePage() {
    const router = useRouter();

    const [loading, setLoading] = useState(true);
    
    const curr_user = useUser()
    const [employeeCode, setEmployeeCode] = useState(null);

    const [editing_mode, setEditingMode] = useState(false);

    const [employee, setEmployee] = useState(null);
    const [editingEmployee, setEditingEmployee] = useState(null);
    // extract employee code from url query params
    
    
    useEffect(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const empCode = urlParams.get('employee_code');
        setEmployeeCode(empCode);
        console.log('Extracted employee code from URL:', empCode);
    }, []);

    useEffect(() => {
        console.log('Current User from useUser hook:', curr_user);
        console.log('curr_user.loading:', curr_user.loading);
        console.log('curr_user.user:', curr_user.user);
        
        if(curr_user.loading){
            console.log("User is still loading, waiting...")
            return
        }

        console.log('User loading complete. User data:', curr_user.user);
        
        // Check if authenticated user is allowed to view this profile
        // If they are not admin and not viewing their own profile, redirect or show error
        if (!curr_user.user) {
            console.log('No user logged in. Redirecting to login page.');
            router.push('/login');
            return;
        }
        if (curr_user.user.role !== 'admin' && (employeeCode && curr_user.user.employee_code !== employeeCode)) {
            console.log('Unauthorized access attempt. Redirecting to home page.');
            router.push('/'); // Redirect to home if not authorized
            return;
        }

        // If employee code is not present, use current user's employee code
        const codeToFetch = employeeCode || curr_user.user.employee_code;
        setEmployeeCode(codeToFetch);

        // Fetch employee details
        const fetchEmployeeDetails = async () => {
            try {
                const res = await fetch(`/api/get-employee-details?employee_code=${codeToFetch}`, {
                    method: 'GET',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                });

                const data = await res.json();
                console.log('Fetched employee details:', data);

                if (res.ok) {
                    setEmployee(data);
                    setEditingEmployee(data);
                    console.log('Employee details set in state:', data);
                } else {
                    console.error('Failed to fetch employee details:', data.error);
                }
            } catch (error) {
                console.error('Error fetching employee details:', error);
            } finally {
                setLoading(false);
            }
        };
        
        fetchEmployeeDetails();
    }, [curr_user, curr_user.loading])

    // Editing handlers
    const handleEditStart = () => {
        setEditingMode(true);
        // setEditingEmployee({ ...employee });
    }

    const handleEditCancel = () => {
        setEditingMode(false);
        setEditingEmployee({ ...employee });
    }

    const handleEditSave = async () => {
        // Get only the fields that changed
        const changedFields = Object.keys(editingEmployee).reduce((changes, key) => {
        if (editingEmployee[key] !== employee[key]) {
            changes[key] = editingEmployee[key];
        }
        return changes;
        }, {});

        // If no changes, just exit edit mode
        if (Object.keys(changedFields).length === 0) {
        console.log('No changes detected');
        setEditingMode(false);
        return;
        }

        console.log('Changed fields:', changedFields);

        try {
        const response = await fetch("/api/employees/update-employee-details", {
            method: "PATCH",
            headers: {
            "Content-Type": "application/json"
            },
            body: JSON.stringify({
            employee_code: employee.employee_code,
            fields: changedFields
            })
        });

        if (!response.ok) {
            throw new Error('Failed to update employee details');
        }

        console.log("Update request sent successfully");
          setEditingMode(false);
        } catch (error) {
        console.error('Error updating employee:', error);
        // Optionally show error to user
        // For now, keep editing mode active so user can retry
        }
    }

    const handleEditField = (field, value) => {
        setEditingEmployee((prev) => ({
        ...prev,
        [field]: value,
        }));
    }

    const handleResetField = (field) => {
        setEditingEmployee((prev) => ({
        ...prev,
        [field]: employee[field],
        }));
    }

    if(loading){
        return (
            <LoadingSpinner />
        )
    }else{
        const fullName = `${editingEmployee.salutation || ''} ${editingEmployee.first_name} ${editingEmployee.last_name}`.trim()
        const initials = `${editingEmployee.first_name?.[0] || ''}${editingEmployee.last_name?.[0] || ''}`.toUpperCase()


        return (
            <div className="min-h-screen bg-gray-50 p-6">
                  <div className="max-w-7xl mx-auto">
                    <div className="grid md:grid-cols-3 gap-6">
                      {/* Left Section - Profile Picture and Personal Info */}
                      <div className="md:col-span-1 space-y-6">
                        {/* Profile Picture Card */}
                        <Card>
                        <CardContent className="pt-6">
                            <div className="flex flex-col items-center">
                            <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-4xl font-bold mb-4">
                                {initials}
                            </div>
                            <h2 className="text-xl font-bold text-center">{fullName}</h2>
                            <Badge className="mt-2" variant="secondary">
                                {editingEmployee.role_nm || 'Employee'}
                            </Badge>
                            <p className="text-sm text-muted-foreground mt-1">ID: {editingEmployee.employee_code}</p>
                            </div>
                        </CardContent>
                        </Card>

                        {/* Personal Information Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle>Personal Information</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            {editingEmployee.gender_code && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Gender</p>
                                  {/* <p className="font-medium capitalize">{editingEmployee.gender_code}</p> */}
                                  <CustomTextInput 
                                    value={editingEmployee.gender_code} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('gender_code', value)}
                                    validator={null}
                                    onReset={() => handleResetField('gender_code')}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                            <div>
                              <p className="text-sm text-muted-foreground">Date of Birth</p>
                              <CustomTextInput 
                                value={formatDate(editingEmployee.date_of_birth_val)} 
                                editing_mode={editing_mode} 
                                onChange={(value) => handleEditField('date_of_birth_val', value)}
                                validator={null}
                                onReset={() => handleResetField('date_of_birth_val')}
                              />
                            </div>
                            <Separator />
                            {editingEmployee.blood_group && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Blood Group</p>
                                  {/* <p className="font-medium">{editingEmployee.blood_group}</p> */}
                                  <CustomTextInput 
                                    value={editingEmployee.blood_group} 
                                    editing_mode={editing_mode}
                                    onChange={(value) => handleEditField('blood_group', value)}
                                    validator={null}
                                    onReset={() => handleResetField('blood_group')}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                            {editingEmployee.marital_status_code && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Marital Status</p>
                                  <CustomTextInput 
                                    value={editingEmployee.marital_status_code} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('marital_status_code', value)}
                                    validator={null}
                                    onReset={() => handleResetField('marital_status_code')}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                            {editingEmployee.community_code && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Community Code</p>
                                  <CustomTextInput 
                                    value={editingEmployee.community_code} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('community_code', value)}
                                    validator={null}
                                    onReset={() => handleResetField('community_code')}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                          </CardContent>
                        </Card>
            
                        {/* Contact Information Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle>Contact Information</CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            {employee?.official_email && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Official Email</p>
                                  {curr_user.user.role_nm === "admin" ? (
                                    <CustomTextInput 
                                    type="email"
                                    value={editingEmployee.official_email} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('official_email', value)}
                                    validator={validateEmail}
                                    onReset={() => handleResetField('official_email')}
                                  />
                                  ):
                                  (<p className="font-medium">{editingEmployee.official_email}</p>)}
                                  
                                </div>
                                <Separator />
                              </>
                            )}
                            {employee?.personal_email && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Personal Email</p>
                                  <CustomTextInput 
                                    value={editingEmployee.personal_email} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('personal_email', value)}
                                    validator={validateEmail}
                                    onReset={() => handleResetField('personal_email')}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                            {employee.mobile_number && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Mobile Number</p>
                                  <CustomTextInput 
                                    value={editingEmployee.mobile_number} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('mobile_number', value)}
                                    validator={null}
                                    onReset={() => handleResetField('mobile_number')}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                            {employee.alternate_mobile_number && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Alternate Mobile</p>
                                  <CustomTextInput 
                                    value={editingEmployee.alternate_mobile_number} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('alternate_mobile_number', value)}
                                    validator={null}
                                    onReset={() => handleResetField('alternate_mobile_number')}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                          </CardContent>
                        </Card>
            
                        {/* Emergency Contact Card */}
                        {(employee.emergency_contact_name || employee.emergency_contact_phone) && (
                          <Card>
                            <CardHeader>
                              <CardTitle>Emergency Contact</CardTitle>
                            </CardHeader>
                            <CardContent className="space-y-4">
                              {employee.emergency_contact_name && (
                                <>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Contact Name</p>
                                    {/* <p className="font-medium">{editingEmployee.emergency_contact_name}</p>
                                     */}
                                    <CustomTextInput 
                                      value={editingEmployee.emergency_contact_name} 
                                      editing_mode={editing_mode}
                                      onChange={(value) => handleEditField('emergency_contact_name', value)}
                                      validator={null}
                                      onReset={() => handleResetField('emergency_contact_name')}
                                    />
                                  </div>
                                  <Separator />
                                </>
                              )}
                              {employee.emergency_contact_phone && (
                                <div>
                                  <p className="text-sm text-muted-foreground">Contact Phone</p>
                                  <CustomTextInput 
                                    value={editingEmployee.emergency_contact_phone} 
                                    editing_mode={editing_mode}
                                    onChange={(value) => handleEditField('emergency_contact_phone', value)}
                                    validator={null}
                                    onReset={() => handleResetField('emergency_contact_phone')}
                                  />
                                </div>
                              )}
                            </CardContent>
                          </Card>
                        )}
                      </div>
            
                      {/* Right Section - Professional Info and Other Details */}
                      <div className="md:col-span-2 space-y-6">
                        {/* Professional Information Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle>Professional Details</CardTitle>
                          </CardHeader>
                          <CardContent className="grid md:grid-cols-2 gap-6">
                            {employee.designation && (
                              <div>
                                <p className="text-sm text-muted-foreground">Designation</p>
                                <CustomTextInput 
                                  value={editingEmployee.designation} 
                                  editing_mode={editing_mode}
                                  onChange={(value) => handleEditField('designation', value)}
                                  validator={null}
                                  onReset={() => handleResetField('designation')}
                                />
                              </div>
                            )}
                            {employee.employee_category_code && (
                              <div>
                                <p className="text-sm text-muted-foreground">Employee Category</p>
                                <p className="font-medium">{editingEmployee.employee_category_code}</p>
                              </div>
                            )}
                            {employee.employee_type_code && (
                              <div>
                                <p className="text-sm text-muted-foreground">Employee Type</p>
                                <p className="font-medium">{editingEmployee.employee_type_code}</p>
                              </div>
                            )}
                            {employee.employment_status_code && (
                              <div>
                                <p className="text-sm text-muted-foreground">Employment Status</p>
                                <Badge variant="outline" className="mt-1">
                                  {editingEmployee.employment_status_code}
                                </Badge>
                              </div>
                            )}
                            {employee.department_id !== null && employee.department_id !== undefined && (
                              <div>
                                <p className="text-sm text-muted-foreground">Department ID</p>
                                <p className="font-medium">{editingEmployee.department_id}</p>
                              </div>
                            )}
                            {editingEmployee.unit_id !== null && editingEmployee.unit_id !== undefined && (
                              <div>
                                <p className="text-sm text-muted-foreground">Unit ID</p>
                                <p className="font-medium">{editingEmployee.unit_id}</p>
                              </div>
                            )}
                            {editingEmployee.campus_id !== null && editingEmployee.campus_id !== undefined && (
                              <div>
                                <p className="text-sm text-muted-foreground">Campus ID</p>
                                <p className="font-medium">{editingEmployee.campus_id}</p>
                              </div>
                            )}
                            {editingEmployee.reporting_manager_id !== null && editingEmployee.reporting_manager_id !== undefined && (
                              <div>
                                <p className="text-sm text-muted-foreground">Reporting Manager ID</p>
                                <p className="font-medium">{editingEmployee.reporting_manager_id}</p>
                              </div>
                            )}
                          </CardContent>
                        </Card>
            
                        {/* Employment Dates Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle>Employment Timeline</CardTitle>
                          </CardHeader>
                          <CardContent className="grid md:grid-cols-2 gap-6">
                            <div>
                              <p className="text-sm text-muted-foreground">Hire Date</p>
                              {/* <p className="font-medium">{formatDate(employee.hire_date)}</p> */}
                              <CustomDateInput 
                                value={editingEmployee.hire_date} 
                                editing_mode={editing_mode}
                                onChange={(value) => handleEditField('hire_date', value)}
                                onReset={() => handleResetField('hire_date')}
                              />
                            </div>
                            {employee.probation_ended_dt && (
                              <div>
                                <p className="text-sm text-muted-foreground">Probation Ended</p>
                                <p className="font-medium">{formatDate(employee.probation_ended_dt)}</p>
                              </div>
                            )}
                            {employee.separation_date && (
                              <div>
                                <p className="text-sm text-muted-foreground">Separation Date</p>
                                <p className="font-medium">{formatDate(employee.separation_date)}</p>
                              </div>
                            )}
                          </CardContent>
                        </Card>
            
                        {/* Government IDs Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle>Government & Identification Details</CardTitle>
                            <CardDescription>Sensitive information - click eye icon to reveal</CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            {employee.aadhaar_no && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">Aadhaar Number</p>
                                  <CustomTextInput 
                                    value={editingEmployee.aadhaar_no} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('aadhaar_no', value)}
                                    validator={null}
                                    onReset={() => handleResetField('aadhaar_no')}
                                    sensitive={true}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                            {employee.pan_no && (
                              <>
                                <div>
                                  <p className="text-sm text-muted-foreground">PAN Number</p>
                                  <CustomTextInput 
                                    value={editingEmployee.pan_no} 
                                    editing_mode={editing_mode} 
                                    onChange={(value) => handleEditField('pan_no', value)}
                                    validator={null}
                                    onReset={() => handleResetField('pan_no')}
                                    sensitive={true}
                                  />
                                </div>
                                <Separator />
                              </>
                            )}
                            {employee.uan_no && (
                              <div>
                                <p className="text-sm text-muted-foreground">UAN Number</p>
                                <CustomTextInput 
                                  value={editingEmployee.uan_no} 
                                  editing_mode={editing_mode} 
                                  onChange={(value) => handleEditField('uan_no', value)}
                                  validator={null}
                                  onReset={() => handleResetField('uan_no')}
                                  sensitive={true}
                                />
                              </div>
                            )}
                          </CardContent>
                        </Card>
            
                        {/* System Information Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle>System Information</CardTitle>
                          </CardHeader>
                          <CardContent className="grid md:grid-cols-2 gap-6">
                            <div>
                              <p className="text-sm text-muted-foreground">Employee ID</p>
                              <p className="font-medium">{employee.employee_id}</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Employee Code</p>
                              <p className="font-medium font-mono">{employee.employee_code}</p>
                            </div>
                            <div>
                              <p className="text-sm text-muted-foreground">Created At</p>
                              <p className="font-medium text-sm">{formatDateTime(employee.created_at)}</p>
                            </div>
                            {employee.created_by && (
                              <div>
                                <p className="text-sm text-muted-foreground">Created By</p>
                                <p className="font-medium">{employee.created_by}</p>
                              </div>
                            )}
                            <div>
                              <p className="text-sm text-muted-foreground">Last Updated</p>
                              <p className="font-medium text-sm">{formatDateTime(employee.updated_at)}</p>
                            </div>
                            {employee.updated_by && (
                              <div>
                                <p className="text-sm text-muted-foreground">Updated By</p>
                                <p className="font-medium">{employee.updated_by}</p>
                              </div>
                            )}
                          </CardContent>
                        </Card>

                        {/* Address Information Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                              <MapPin className="h-5 w-5" />
                              Address Information
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="space-y-6">
                            {/* Current Address */}
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <h3 className="font-semibold text-lg">Current Address</h3>
                                <Badge variant="outline">Primary</Badge>
                              </div>
                              <div className="pl-4 space-y-2">
                                <div>
                                  <p className="text-sm text-muted-foreground">Street Address</p>
                                  <p className="font-medium">123, Whitefield Main Road</p>
                                </div>
                                <div className="grid md:grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-sm text-muted-foreground">City</p>
                                    <p className="font-medium">Bangalore</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">State</p>
                                    <p className="font-medium">Karnataka</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">PIN Code</p>
                                    <p className="font-medium">560066</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Country</p>
                                    <p className="font-medium">India</p>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <Separator />

                            {/* Permanent Address */}
                            <div className="space-y-3">
                              <div className="flex items-center justify-between">
                                <h3 className="font-semibold text-lg">Permanent Address</h3>
                                <Badge variant="secondary">Secondary</Badge>
                              </div>
                              <div className="pl-4 space-y-2">
                                <div>
                                  <p className="text-sm text-muted-foreground">Street Address</p>
                                  <p className="font-medium">456, MG Road, Near Central Park</p>
                                </div>
                                <div className="grid md:grid-cols-2 gap-4">
                                  <div>
                                    <p className="text-sm text-muted-foreground">City</p>
                                    <p className="font-medium">Puttaparthi</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">State</p>
                                    <p className="font-medium">Andhra Pradesh</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">PIN Code</p>
                                    <p className="font-medium">515134</p>
                                  </div>
                                  <div>
                                    <p className="text-sm text-muted-foreground">Country</p>
                                    <p className="font-medium">India</p>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>

                        {/* Uploaded Files Card */}
                        <Card>
                          <CardHeader>
                            <CardTitle className="flex items-center gap-2">
                              <FileText className="h-5 w-5" />
                              Uploaded Documents
                            </CardTitle>
                            <CardDescription>Employee related documents and files</CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-3">
                            {/* Document 1 */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
                              <div className="flex items-center gap-3">
                                <div className="p-2 rounded-md bg-blue-100 dark:bg-blue-900">
                                  <FileText className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                                </div>
                                <div>
                                  <p className="font-medium">Aadhaar Card.pdf</p>
                                  <p className="text-sm text-muted-foreground">Uploaded on Jan 5, 2024 • 245 KB</p>
                                </div>
                              </div>
                              <Button variant="ghost" size="icon" title="Download">
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>

                            {/* Document 2 */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
                              <div className="flex items-center gap-3">
                                <div className="p-2 rounded-md bg-green-100 dark:bg-green-900">
                                  <FileText className="h-5 w-5 text-green-600 dark:text-green-400" />
                                </div>
                                <div>
                                  <p className="font-medium">PAN Card.pdf</p>
                                  <p className="text-sm text-muted-foreground">Uploaded on Jan 5, 2024 • 189 KB</p>
                                </div>
                              </div>
                              <Button variant="ghost" size="icon" title="Download">
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>

                            {/* Document 3 */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
                              <div className="flex items-center gap-3">
                                <div className="p-2 rounded-md bg-purple-100 dark:bg-purple-900">
                                  <FileText className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                                </div>
                                <div>
                                  <p className="font-medium">Degree Certificate.pdf</p>
                                  <p className="text-sm text-muted-foreground">Uploaded on Dec 20, 2023 • 1.2 MB</p>
                                </div>
                              </div>
                              <Button variant="ghost" size="icon" title="Download">
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>

                            {/* Document 4 */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
                              <div className="flex items-center gap-3">
                                <div className="p-2 rounded-md bg-orange-100 dark:bg-orange-900">
                                  <FileText className="h-5 w-5 text-orange-600 dark:text-orange-400" />
                                </div>
                                <div>
                                  <p className="font-medium">Experience Letter.pdf</p>
                                  <p className="text-sm text-muted-foreground">Uploaded on Dec 15, 2023 • 456 KB</p>
                                </div>
                              </div>
                              <Button variant="ghost" size="icon" title="Download">
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>

                            {/* Document 5 */}
                            <div className="flex items-center justify-between p-3 rounded-lg border bg-card hover:bg-accent/50 transition-colors">
                              <div className="flex items-center gap-3">
                                <div className="p-2 rounded-md bg-red-100 dark:bg-red-900">
                                  <FileText className="h-5 w-5 text-red-600 dark:text-red-400" />
                                </div>
                                <div>
                                  <p className="font-medium">Bank Details.pdf</p>
                                  <p className="text-sm text-muted-foreground">Uploaded on Nov 28, 2023 • 312 KB</p>
                                </div>
                              </div>
                              <Button variant="ghost" size="icon" title="Download">
                                <Download className="h-4 w-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
            
                        {/* Edit Button - Bottom Right */}
                        <div className="flex justify-end">
                            {editing_mode ? 
                            ( 
                            <div className="flex justify-end items-center space-x-2"> 
                              <Button size="lg" title="Cancel Changes" className="bg-red-600/60 hover:bg-red-600/80 gap-2" onClick={() => handleEditCancel()}>
                                <X strokeWidth={4}/> <span className="hidden md:inline">Cancel</span>
                              </Button>
            
                              <Button size="lg" title="Accept Changes" className="bg-green-600/60 hover:bg-green-600/80 gap-2" onClick={() => handleEditSave()}>
                                <Check strokeWidth={4}/> <span className="hidden md:inline">Accept Changes</span> 
                              </Button>
                            </div>
                            )
                            :
                            (
                              <Button size="lg" className="gap-2" onClick={() => handleEditStart()}>
                                <SquarePen />
                                <span className="hidden md:inline">Edit Profile</span>
                              </Button>
                            )}
                        </div>
                            
                      </div>
                    </div>
                  </div>
                </div>
        )
    }

    
}

// Validation functions
const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
        return { isValid: false, message: 'Email is required' };
    }
    if (!emailRegex.test(email)) {
        return { isValid: false, message: 'Please enter a valid email address' };
    }
return { isValid: true, message: '' };
}

const validatePhone = (phone) => {
    const phoneRegex = /^[0-9]{10}$/;
    if (!phone) {
        return { isValid: false, message: 'Phone number is required' };
    }
    if (!phoneRegex.test(phone)) {
        return { isValid: false, message: 'Phone number must be 10 digits' };
    }
    return { isValid: true, message: '' };
}

