import { Eye, EyeOff } from "lucide-react"
import { Button } from "../components/ui/button"
import { CustomTextInput } from "./custom-inputs"
import { useState } from "react"

export const SensitiveField = ({ label, value }) => {
  const [isVisible, setIsVisible] = useState(false)

  if (!value) return null

  return (
    <div>
      <p className="text-sm text-muted-foreground">{label}</p>
      <div className="flex items-center gap-2">
        <p className="font-medium font-mono">
          {isVisible ? value : '••••••••••••'}
        </p>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsVisible(!isVisible)}
          className="h-8 px-2"
        >
          {isVisible ? (
            <EyeOff className="w-4 h-4" />
          ) : (
            <Eye className="w-4 h-4" />
          )}
        </Button>
      </div>
    </div>
  )
}

export default SensitiveField