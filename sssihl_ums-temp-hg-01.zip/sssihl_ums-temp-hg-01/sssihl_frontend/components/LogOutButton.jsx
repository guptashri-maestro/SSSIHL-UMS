"use client"

import { Button } from "./ui/button";
import { LogOut } from "lucide-react";
import { useRouter } from "next/navigation"

const LogOutButton = () => {
    const router = useRouter();
    const logOut = async () => {
        const response = await fetch('/api/auth/logout', { method: 'POST'});
        router.replace('/login');
    }

    return (
        <Button
            variant="ghost"
            size="sm"
            onClick={() => logOut()}
          >
            <LogOut className="size-4 mr-2" />
            Sign Out
        </Button>
    )
}

export default LogOutButton;