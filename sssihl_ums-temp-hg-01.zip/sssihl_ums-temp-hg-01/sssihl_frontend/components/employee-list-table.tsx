"use client"

import { useState } from "react"
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  useReactTable,
  VisibilityState,
} from "@tanstack/react-table"
 
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "./ui/table"
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import { Button } from "./ui/button"

type Employee = {
  employee_id: number | null;
  employee_code: string | null;
  salutation: string | null;
  first_name: string | null;
  last_name: string | null;
  gender_code: string | null;
  date_of_birth_val: string | null; // ISO date format (YYYY-MM-DD)
  blood_group: string | null;
  community_code: string | null;
  marital_status_code: string | null;
  official_email: string | null;
  personal_email: string | null;
  mobile_number: string | null;
  alternate_mobile_number: string | null;
  emergency_contact_name: string | null;
  emergency_contact_phone: string | null;
  department_id: number | null;
  unit_id: number | null;
  campus_id: number | null;
  reporting_manager_id: number | null;
  employee_category_code: string | null;
  employee_type_code: string | null;
  designation: string | null;
  role_nm: string | null;
  hire_date: string | null; // ISO date format (YYYY-MM-DD)
  probation_ended_dt: string | null; // ISO date format (YYYY-MM-DD)
  employment_status_code: string | null;
  separation_date: string | null; // ISO date format (YYYY-MM-DD)
  aadhaar_no: string | null;
  pan_no: string | null;
  uan_no: string | null;
  created_at: string | null; // ISO datetime format
  created_by: string | null;
  updated_at: string | null; // ISO datetime format
  updated_by: string | null;
}

const emps = [
  {
    "employee_id": 1,
    "employee_code": "0001",
    "salutation": null,
    "first_name": "tralaleo",
    "last_name": "tralala",
    "gender_code": null,
    "date_of_birth_val": "1977-01-01",
    "blood_group": null,
    "community_code": null,
    "marital_status_code": null,
    "official_email": null,
    "personal_email": null,
    "mobile_number": null,
    "alternate_mobile_number": null,
    "emergency_contact_name": null,
    "emergency_contact_phone": null,
    "department_id": null,
    "unit_id": null,
    "campus_id": null,
    "reporting_manager_id": null,
    "employee_category_code": null,
    "employee_type_code": null,
    "designation": null,
    "role_nm": null,
    "hire_date": "2020-01-01",
    "probation_ended_dt": "2020-01-01",
    "employment_status_code": "faculty",
    "separation_date": "9999-12-31",
    "aadhaar_no": "XXXX-XXXX-7890",
    "pan_no": "1234567890",
    "uan_no": "1234567890",
    "created_at": "2025-12-31T18:26:05.155902Z",
    "created_by": null,
    "updated_at": "2025-12-31T18:26:05.155902Z",
    "updated_by": null
  },
  {
    "employee_id": 6,
    "employee_code": "fjksfhjsdkfhsd",
    "salutation": "he/him",
    "first_name": "joe",
    "last_name": "bama",
    "gender_code": "daasaaasd",
    "date_of_birth_val": "2016-01-02",
    "blood_group": "fsfsdff",
    "community_code": "fdfsdfsdaf",
    "marital_status_code": "ffdsfsfsfdf",
    "official_email": "no@u.net",
    "personal_email": "user@example.com",
    "mobile_number": "string",
    "alternate_mobile_number": "string",
    "emergency_contact_name": "string",
    "emergency_contact_phone": "string",
    "department_id": 0,
    "unit_id": 0,
    "campus_id": 0,
    "reporting_manager_id": 0,
    "employee_category_code": "string",
    "employee_type_code": "string",
    "designation": "string",
    "role_nm": "string",
    "hire_date": "2026-01-02",
    "probation_ended_dt": "2026-01-02",
    "employment_status_code": "string",
    "separation_date": "2026-01-02",
    "aadhaar_no": "string",
    "pan_no": "string",
    "uan_no": "string",
    "created_at": "2026-01-02T01:20:08.889000Z",
    "created_by": "string",
    "updated_at": "2026-01-02T01:20:08.889000Z",
    "updated_by": "string"
  },
  {
    "employee_id": 7,
    "employee_code": "+9152454525",
    "salutation": "Ms",
    "first_name": "+91524545",
    "last_name": "+91524545",
    "gender_code": "O",
    "date_of_birth_val": "2025-12-29",
    "blood_group": "+91524",
    "community_code": null,
    "marital_status_code": null,
    "official_email": "abc@gmail.com",
    "personal_email": "abc@gmail.com",
    "mobile_number": "+91524545",
    "alternate_mobile_number": "+91524545",
    "emergency_contact_name": "+91524545",
    "emergency_contact_phone": "+9152454525",
    "department_id": 2,
    "unit_id": 2,
    "campus_id": 2,
    "reporting_manager_id": 9,
    "employee_category_code": "",
    "employee_type_code": "",
    "designation": "+9152454525",
    "role_nm": "+9152454525",
    "hire_date": "2026-01-15",
    "probation_ended_dt": "2026-01-14",
    "employment_status_code": "+9152454525",
    "separation_date": null,
    "aadhaar_no": "22222",
    "pan_no": "22222",
    "uan_no": "2222222",
    "created_at": "2026-01-03T02:19:41.319082Z",
    "created_by": null,
    "updated_at": "2026-01-03T02:19:41.319085Z",
    "updated_by": null
  },
  {
    "employee_id": 10,
    "employee_code": "EMP-0001",
    "salutation": "Mr.",
    "first_name": "Arjun",
    "last_name": "Reddy",
    "gender_code": "M",
    "date_of_birth_val": "1996-08-14",
    "blood_group": "O+",
    "community_code": "GEN",
    "marital_status_code": "S",
    "official_email": "arjun.reddy@sssihl.edu",
    "personal_email": "arjun.reddy@gmail.com",
    "mobile_number": "+1-646-555-0142",
    "alternate_mobile_number": "+1-646-555-0188",
    "emergency_contact_name": "Suma Reddy",
    "emergency_contact_phone": "+1-646-555-0111",
    "department_id": 3,
    "unit_id": 2,
    "campus_id": 1,
    "reporting_manager_id": 101,
    "employee_category_code": "FAC",
    "employee_type_code": "FT",
    "designation": "Assistant Professor",
    "role_nm": "faculty",
    "hire_date": "2023-07-10",
    "probation_ended_dt": "2024-01-10",
    "employment_status_code": "ACTIVE",
    "separation_date": "2099-12-31",
    "aadhaar_no": "XXXX-XXXX-1234",
    "pan_no": "ABCDE1234F",
    "uan_no": "100200300400",
    "created_at": "2026-01-04T22:47:49.703000Z",
    "created_by": "system",
    "updated_at": "2026-01-04T22:47:49.703000Z",
    "updated_by": "system"
  },
  {
    "employee_id": 11,
    "employee_code": "EMP-0002",
    "salutation": "Ms.",
    "first_name": "Meera",
    "last_name": "Nair",
    "gender_code": "F",
    "date_of_birth_val": "1992-03-22",
    "blood_group": "A+",
    "community_code": "OBC",
    "marital_status_code": "M",
    "official_email": "meera.nair@sssihl.edu",
    "personal_email": "meera.nair@yahoo.com",
    "mobile_number": "+1-917-555-0107",
    "alternate_mobile_number": "+1-917-555-0199",
    "emergency_contact_name": "Rohit Nair",
    "emergency_contact_phone": "+1-917-555-0122",
    "department_id": 7,
    "unit_id": 1,
    "campus_id": 2,
    "reporting_manager_id": 103,
    "employee_category_code": "ADMIN",
    "employee_type_code": "FT",
    "designation": "HR Officer",
    "role_nm": "hr",
    "hire_date": "2021-11-15",
    "probation_ended_dt": "2022-05-15",
    "employment_status_code": "ACTIVE",
    "separation_date": "2099-12-31",
    "aadhaar_no": "XXXX-XXXX-6789",
    "pan_no": "PQRSX6789K",
    "uan_no": "200300400500",
    "created_at": "2026-01-04T22:47:49.703000Z",
    "created_by": "system",
    "updated_at": "2026-01-04T22:47:49.703000Z",
    "updated_by": "system"
  },
  {
    "employee_id": 12,
    "employee_code": "EMP-0003",
    "salutation": "Dr.",
    "first_name": "Karthik",
    "last_name": "Iyer",
    "gender_code": "M",
    "date_of_birth_val": "1987-12-02",
    "blood_group": "B+",
    "community_code": "GEN",
    "marital_status_code": "M",
    "official_email": "karthik.iyer@sssihl.edu",
    "personal_email": "karthik.iyer@outlook.com",
    "mobile_number": "+1-212-555-0175",
    "alternate_mobile_number": "+1-212-555-0133",
    "emergency_contact_name": "Ananya Iyer",
    "emergency_contact_phone": "+1-212-555-0144",
    "department_id": 4,
    "unit_id": 3,
    "campus_id": 1,
    "reporting_manager_id": 100,
    "employee_category_code": "FAC",
    "employee_type_code": "FT",
    "designation": "Associate Professor",
    "role_nm": "faculty",
    "hire_date": "2018-06-04",
    "probation_ended_dt": "2018-12-04",
    "employment_status_code": "ACTIVE",
    "separation_date": "2099-12-31",
    "aadhaar_no": "XXXX-XXXX-4455",
    "pan_no": "LMNOP4321Z",
    "uan_no": "300400500600",
    "created_at": "2026-01-04T22:47:49.703000Z",
    "created_by": "admin_user_1",
    "updated_at": "2026-01-04T22:47:49.703000Z",
    "updated_by": "admin_user_1"
  },
  {
    "employee_id": 13,
    "employee_code": "EMP-0004",
    "salutation": "Mrs.",
    "first_name": "Divya",
    "last_name": "Sharma",
    "gender_code": "F",
    "date_of_birth_val": "1990-05-30",
    "blood_group": "AB+",
    "community_code": "SC",
    "marital_status_code": "M",
    "official_email": "divya.sharma@sssihl.edu",
    "personal_email": "divya.sharma@gmail.com",
    "mobile_number": "+1-718-555-0161",
    "alternate_mobile_number": "+1-718-555-0102",
    "emergency_contact_name": "Raj Sharma",
    "emergency_contact_phone": "+1-718-555-0191",
    "department_id": 9,
    "unit_id": 2,
    "campus_id": 3,
    "reporting_manager_id": 110,
    "employee_category_code": "SUPPORT",
    "employee_type_code": "FT",
    "designation": "Systems Administrator",
    "role_nm": "it_admin",
    "hire_date": "2020-02-03",
    "probation_ended_dt": "2020-08-03",
    "employment_status_code": "ACTIVE",
    "separation_date": "2099-12-31",
    "aadhaar_no": "XXXX-XXXX-9090",
    "pan_no": "TUVWX9090Q",
    "uan_no": "400500600700",
    "created_at": "2026-01-04T22:47:49.703000Z",
    "created_by": "admin_user_2",
    "updated_at": "2026-01-04T22:47:49.703000Z",
    "updated_by": "admin_user_2"
  },
  {
    "employee_id": 14,
    "employee_code": "EMP-0005",
    "salutation": "Mr",
    "first_name": "Sahil",
    "last_name": "Khan",
    "gender_code": "M",
    "date_of_birth_val": "2026-01-26",
    "blood_group": "O-",
    "community_code": null,
    "marital_status_code": null,
    "official_email": "sahil.khan@sssihl.edu",
    "personal_email": "sahil.khan@gmail.com",
    "mobile_number": "+1-347-555-0129",
    "alternate_mobile_number": "+1-347-555-0170",
    "emergency_contact_name": "Farah Khan",
    "emergency_contact_phone": "+1-347-555-0155",
    "department_id": 1,
    "unit_id": 1,
    "campus_id": 1,
    "reporting_manager_id": 9,
    "employee_category_code": "",
    "employee_type_code": "",
    "designation": "Accounts Assistant",
    "role_nm": "finance",
    "hire_date": "2026-01-14",
    "probation_ended_dt": "2026-01-19",
    "employment_status_code": "ACTIVE",
    "separation_date": null,
    "aadhaar_no": "XXXX-XXXX-2222",
    "pan_no": "FGHIJ2222L",
    "uan_no": "500600700800",
    "created_at": "2026-01-04T23:12:12.971683Z",
    "created_by": null,
    "updated_at": "2026-01-04T23:12:12.971685Z",
    "updated_by": null
  },
  {
    "employee_id": 15,
    "employee_code": "69",
    "salutation": "Dr",
    "first_name": "Hari",
    "last_name": "Gupta",
    "gender_code": "M",
    "date_of_birth_val": "1977-07-09",
    "blood_group": "O+",
    "community_code": null,
    "marital_status_code": null,
    "official_email": "hari.gupta@maestro.com",
    "personal_email": "guptashri@gmail.com",
    "mobile_number": "7326408020",
    "alternate_mobile_number": "8482370731",
    "emergency_contact_name": "Gomathi",
    "emergency_contact_phone": "9087202775",
    "department_id": 1,
    "unit_id": 1,
    "campus_id": 1,
    "reporting_manager_id": 9,
    "employee_category_code": "",
    "employee_type_code": "",
    "designation": "doctor",
    "role_nm": "heart",
    "hire_date": "2025-12-31",
    "probation_ended_dt": "2026-01-06",
    "employment_status_code": "fired",
    "separation_date": null,
    "aadhaar_no": "assdfs",
    "pan_no": "sdfsdfa",
    "uan_no": "dsfsdfs",
    "created_at": "2026-01-04T23:23:11.506501Z",
    "created_by": null,
    "updated_at": "2026-01-04T23:23:11.506503Z",
    "updated_by": null
  },
  {
    "employee_id": 18,
    "employee_code": "lkjhgfdsa",
    "salutation": "lkjhgfd",
    "first_name": "Datha",
    "last_name": "Bindumalam",
    "gender_code": "Male",
    "date_of_birth_val": "2004-08-05",
    "blood_group": "O+",
    "community_code": "bruh",
    "marital_status_code": "hoeless",
    "official_email": "datha@sssihl.edu",
    "personal_email": "db624@njit.edu",
    "mobile_number": "7305500418",
    "alternate_mobile_number": "string",
    "emergency_contact_name": "string",
    "emergency_contact_phone": "string",
    "department_id": 0,
    "unit_id": 0,
    "campus_id": 0,
    "reporting_manager_id": 0,
    "employee_category_code": "string",
    "employee_type_code": "string",
    "designation": "string",
    "role_nm": "admin",
    "hire_date": "2026-01-06",
    "probation_ended_dt": "2026-01-06",
    "employment_status_code": "string",
    "separation_date": "2026-01-06",
    "aadhaar_no": "string",
    "pan_no": "string",
    "uan_no": "string",
    "created_at": "2026-01-06T22:21:20.450000Z",
    "created_by": "string",
    "updated_at": "2026-01-09T02:39:27.820826Z",
    "updated_by": "lkjhgfdsa"
  },
  {
    "employee_id": 19,
    "employee_code": "yeet",
    "salutation": "string",
    "first_name": "test",
    "last_name": "user",
    "gender_code": "string",
    "date_of_birth_val": "2026-01-07",
    "blood_group": "string",
    "community_code": "string",
    "marital_status_code": "string",
    "official_email": "dathster3@gmail.com",
    "personal_email": "user@example.com",
    "mobile_number": "string",
    "alternate_mobile_number": "string",
    "emergency_contact_name": "string",
    "emergency_contact_phone": "string",
    "department_id": 0,
    "unit_id": 0,
    "campus_id": 0,
    "reporting_manager_id": 0,
    "employee_category_code": "string",
    "employee_type_code": "string",
    "designation": "string",
    "role_nm": "string",
    "hire_date": "2026-01-07",
    "probation_ended_dt": null,
    "employment_status_code": "string",
    "separation_date": null,
    "aadhaar_no": "string",
    "pan_no": "string",
    "uan_no": "string",
    "created_at": "2026-01-07T01:34:20.066412Z",
    "created_by": "lkjhgfdsa",
    "updated_at": "2026-01-07T01:34:20.066414Z",
    "updated_by": "2026-01-06 22:39:29.139372-05"
  },
  {
    "employee_id": 35,
    "employee_code": "yeet2",
    "salutation": "string",
    "first_name": "Datha",
    "last_name": "Bindumalam",
    "gender_code": "string",
    "date_of_birth_val": "2026-01-07",
    "blood_group": "string",
    "community_code": "string",
    "marital_status_code": "string",
    "official_email": "dathster3@gmail.com",
    "personal_email": "user@example.com",
    "mobile_number": "string",
    "alternate_mobile_number": "string",
    "emergency_contact_name": "string",
    "emergency_contact_phone": "string",
    "department_id": 0,
    "unit_id": 0,
    "campus_id": 0,
    "reporting_manager_id": 0,
    "employee_category_code": "string",
    "employee_type_code": "string",
    "designation": "string",
    "role_nm": "string",
    "hire_date": "2026-01-07",
    "probation_ended_dt": null,
    "employment_status_code": "string",
    "separation_date": null,
    "aadhaar_no": "string",
    "pan_no": "string",
    "uan_no": "string",
    "created_at": "2026-01-07T22:27:39.759880Z",
    "created_by": "lkjhgfdsa",
    "updated_at": "2026-01-07T22:27:39.759880Z",
    "updated_by": "lkjhgfdsa"
  }
]

const columns: ColumnDef<Employee>[] = [
  { header: 'Employee ID', accessorKey: 'employee_id'},
  { header: 'Employee Code', accessorKey: 'employee_code'},
  { header: 'Salutation', accessorKey: 'salutation'},
  { header: 'First Name', accessorKey: 'first_name'},
  { header: 'Last Name', accessorKey: 'last_name'},
  { header: 'Gender', accessorKey: 'gender_code'},
  { header: 'Date of Birth', accessorKey: 'date_of_birth_val'},
  { header: 'Blood Group', accessorKey: 'blood_group'},
  { header: 'Community Code', accessorKey: 'community_code'},
  { header: 'Marital Status', accessorKey: 'marital_status_code'},
  { header: 'Official Email', accessorKey: 'official_email'},
  { header: 'Personal Email', accessorKey: 'personal_email'},
  { header: 'Mobile Number', accessorKey: 'mobile_number'},
  { header: 'Alternate Mobile Number', accessorKey: 'alternate_mobile_number'},
  { header: 'Emergency Contact Name', accessorKey: 'emergency_contact_name'},
  { header: 'Emergency Contact Phone', accessorKey: 'emergency_contact_phone'},
  { header: 'Department ID', accessorKey: 'department_id'},
  { header: 'Unit ID', accessorKey: 'unit_id'},
  { header: 'Campus ID', accessorKey: 'campus_id'},
  { header: 'Reporting Manager ID', accessorKey: 'reporting_manager_id'},
  { header: 'Employee Category Code', accessorKey: 'employee_category_code'},
  { header: 'Employee Type Code', accessorKey: 'employee_type_code'},
  { header: 'Designation', accessorKey: 'designation'},
  { header: 'Role Name', accessorKey: 'role_nm'},
  { header: 'Hire Date', accessorKey: 'hire_date'},
  { header: 'Probation Ended Date', accessorKey: 'probation_ended_dt'},
  { header: 'Employment Status Code', accessorKey: 'employment_status_code'},
  { header: 'Separation Date', accessorKey: 'separation_date'},
  { header: 'Aadhaar No', accessorKey: 'aadhaar_no'},
  { header: 'PAN No', accessorKey: 'pan_no'},
  { header: 'UAN No', accessorKey: 'uan_no'},
  { header: 'Created At', accessorKey: 'created_at'},
  { header: 'Created By', accessorKey: 'created_by'},
  { header: 'Updated At', accessorKey: 'updated_at'},
  { header: 'Updated By', accessorKey: 'updated_by'},
]



export function EmployeeListTable() {
  const [columnVisibility, setColumnVisibility] = useState<VisibilityState>({})

  const table = useReactTable({
    data: emps,
    columns,
    getCoreRowModel: getCoreRowModel(),
    onColumnVisibilityChange: setColumnVisibility,
    state: {
      columnVisibility,
    },
  })

  return (
    <div className="space-y-4">
      {/* Column Visibility Dropdown */}
      <div className="flex justify-end">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" className="ml-auto">
              Columns
              <svg
                className="ml-2 h-4 w-4"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M19 9l-7 7-7-7"
                />
              </svg>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-[200px]">
            {table
              .getAllColumns()
              .filter((column) => column.getCanHide())
              .map((column) => {
                return (
                  <DropdownMenuCheckboxItem
                    key={column.id}
                    className="capitalize"
                    checked={column.getIsVisible()}
                    onCheckedChange={(value) => column.toggleVisibility(!!value)}
                    onSelect={(e) => e.preventDefault()}
                  >
                    {typeof column.columnDef.header === 'string'
                      ? column.columnDef.header
                      : column.id}
                  </DropdownMenuCheckboxItem>
                )
              })}
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-lg border border-gray-200 bg-white">
        <Table>
        <TableHeader className="bg-gray-50 border-b border-gray-200">
          {table.getHeaderGroups().map((headerGroup) => (
            <TableRow key={headerGroup.id} className="hover:bg-gray-50">
              {
                headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id} className="text-gray-900 font-semibold">
                      {
                        header.isPlaceholder
                        ? null
                        : flexRender(
                          header.column.columnDef.header,
                          header.getContext()
                        )
                      }
                    </TableHead>
                  )
                })
              }
            </TableRow>
          ))}
        </TableHeader>
        <TableBody>
          {table.getRowModel().rows?.length ? (
            table.getRowModel().rows.map((row) => (
              <TableRow
                key={row.id}
                data-state={row.getIsSelected() && "selected"}
                onClick={() => console.log(row.original.employee_code)}
                onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f3f4f6'}
                onMouseLeave={(e) => e.currentTarget.style.backgroundColor = ''}
                style={{ cursor: 'pointer' }}
                className="border-b border-gray-200 bg-white"
              >
                {row.getVisibleCells().map((cell) => (
                  <TableCell key={cell.id} className="text-gray-900">
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </TableCell>
                ))}
              </TableRow>
            ))
          ) : (
            <TableRow className="hover:bg-gray-50">
              <TableCell colSpan={columns.length} className="h-24 text-center text-gray-500">
                No results.
              </TableCell>
            </TableRow>
          )}
        </TableBody>
        </Table>
      </div>
    </div>
  )
}