import { Card, CardContent } from "@/components/ui/card";

export function ErrorState({ title = "Error", message, onRetry }) {
  return (
    <div className="min-h-screen bg-gray-50 p-6 flex items-center justify-center">
      <Card className="max-w-md">
        <CardContent className="pt-6">
          <div className="text-center text-red-500">
            <p className="font-semibold mb-2">{title}</p>
            <p className="text-sm">{message}</p>
            {onRetry && (
              <button
                onClick={onRetry}
                className="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition-colors"
              >
                Retry
              </button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
