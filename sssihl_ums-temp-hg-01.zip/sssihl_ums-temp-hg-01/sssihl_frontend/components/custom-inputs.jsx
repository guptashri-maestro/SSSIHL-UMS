"use client"


import React from 'react'
import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { RotateCcw, Eye, EyeOff, Calendar } from 'lucide-react'
import { Button } from './ui/button'

const CustomInputs = () => {
  return (
    <div>
      
    </div>
  )
}

// export default custom-inputs


const CustomTextInput = ({ label, value, onChange, placeholder, type = "text", editing_mode=false, validator, errorMessage, onReset, className, sensitive = false }) => {

    // const [editing_mode, setEditingMode] = useState(false);
    const [isFocused, setIsFocused] = useState(false);
    const [isValid, setIsValid] = useState(true);
    const [validationError, setValidationError] = useState('');
    const [isVisible, setIsVisible] = useState(false);

    const validateInput = (inputValue) => {
        // Validate the input
        if (validator) {
            const validationResult = validator(inputValue);
            if (typeof validationResult === 'boolean') {
                setIsValid(validationResult);
                setValidationError(validationResult ? '' : errorMessage || 'Invalid input');
            } else if (validationResult && typeof validationResult === 'object') {
                // Validator can return { isValid: boolean, message: string }
                setIsValid(validationResult.isValid);
                setValidationError(validationResult.isValid ? '' : validationResult.message || errorMessage || 'Invalid input');
            }
        } else {
            setIsValid(true);
            setValidationError('');
        }
    }

    const handleChange = (newValue) => {
        // Call onChange first
        onChange?.(newValue);
        
        validateInput(newValue);
    };

    // Validate whenever value changes (including from external resets)
    useEffect(() => {
        if (editing_mode) {
            validateInput(value);
        } else {
            // Reset validation state when not in editing mode
            setIsValid(true);
            setValidationError('');
        }
    }, [value, editing_mode, validator]);

    // If sensitive and not editing, show masked value with toggle
    if (sensitive && !editing_mode) {
        return (
            <div className={`custom-text-input ${className || ''}`}>
                <div className="flex items-center gap-2">
                    <p className="font-medium font-mono">
                        {isVisible ? value : '••••••••••••'}
                    </p>
                    <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsVisible(!isVisible)}
                        className="h-8 px-2"
                    >
                        {isVisible ? (
                            <EyeOff className="w-4 h-4" />
                        ) : (
                            <Eye className="w-4 h-4" />
                        )}
                    </Button>
                </div>
            </div>
        );
    }

    return (
        <div className={`custom-text-input ${className || ''}`}>
            <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                    <motion.input
                        type={type}
                        value={value}
                        onChange={(e) => handleChange(e.target.value)}
                        placeholder={placeholder}
                        readOnly={!editing_mode}
                        onFocus={() => setIsFocused(true)}
                        onBlur={() => setIsFocused(false)}
                        // onClick={() => !editing_mode && setEditingMode(true)}
                        className={`py-1 outline-none bg-transparent transition-colors ${
                            !editing_mode ? 'cursor-pointer' : 'cursor-text'
                        } ${className?.includes('w-') ? '' : 'w-auto min-w-0'}`}
                        style={{
                            backgroundRepeat: 'no-repeat',
                            backgroundPosition: 'center bottom',
                        }}
                        animate={{
                            backgroundImage: !isValid && editing_mode
                                ? 'linear-gradient(rgb(239, 68, 68), rgb(239, 68, 68))'
                                : isFocused && editing_mode 
                                    ? 'linear-gradient(rgb(59, 130, 246), rgb(59, 130, 246))'
                                    : 'linear-gradient(rgb(209, 213, 219), rgb(209, 213, 219))',
                            backgroundSize: editing_mode ? '100% 2px' : '0% 2px',
                        }}
                        transition={{
                            backgroundSize: {
                                duration: 0.3,
                                ease: "easeOut"
                            },
                            backgroundImage: {
                                duration: 0.2,
                                ease: "easeOut"
                            }
                        }}
                    />

                    {/* Reset button - only visible in editing mode */}
                    {editing_mode && onReset && (
                        <button
                            onClick={(e) => {onReset(); setIsValid(true); setValidationError('');}}
                            className="p-1 text-muted-foreground hover:text-foreground transition-colors"
                            title="Reset to original value"
                        >
                            <RotateCcw className="w-5 h-5" />
                        </button>
                    )}
                </div>
                
                {/* Validation error message */}
                {!isValid && editing_mode && validationError && (
                    <motion.p 
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-xs text-red-500 mt-1"
                    >
                        {validationError}
                    </motion.p>
                )}
            </div>
        </div>
    );
}

const CustomDateInput = ({ label, value, onChange, editing_mode = false, validator, errorMessage, onReset, className }) => {
    const [isFocused, setIsFocused] = useState(false);
    const [isValid, setIsValid] = useState(true);
    const [validationError, setValidationError] = useState('');

    const validateInput = (inputValue) => {
        if (validator) {
            const validationResult = validator(inputValue);
            if (typeof validationResult === 'boolean') {
                setIsValid(validationResult);
                setValidationError(validationResult ? '' : errorMessage || 'Invalid date');
            } else if (validationResult && typeof validationResult === 'object') {
                setIsValid(validationResult.isValid);
                setValidationError(validationResult.isValid ? '' : validationResult.message || errorMessage || 'Invalid date');
            }
        } else {
            setIsValid(true);
            setValidationError('');
        }
    }

    const handleChange = (newValue) => {
        onChange?.(newValue);
        validateInput(newValue);
    };

    useEffect(() => {
        if (editing_mode) {
            validateInput(value);
        } else {
            setIsValid(true);
            setValidationError('');
        }
    }, [value, editing_mode, validator]);

    // Format date for display (YYYY-MM-DD -> readable format)
    const formatDateForDisplay = (dateString) => {
        if (!dateString) return '';
        // Extract YYYY-MM-DD without timezone conversion
        const dateOnly = dateString.split('T')[0]; // Handle both "YYYY-MM-DD" and "YYYY-MM-DDTHH:mm:ss"
        const [year, month, day] = dateOnly.split('-').map(Number);
        if (!year || !month || !day) return dateString;
        
        const date = new Date(year, month - 1, day); // Create date in local timezone
        return date.toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' });
    };

    // Format date for input (ensure YYYY-MM-DD format)
    const formatDateForInput = (dateString) => {
        if (!dateString) return '';
        // Extract YYYY-MM-DD without timezone conversion
        const dateOnly = dateString.split('T')[0];
        return dateOnly;
    };

    return (
        <div className={`custom-date-input ${className || ''}`}>
            <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                    {editing_mode ? (
                        <motion.input
                            type="date"
                            value={formatDateForInput(value)}
                            onChange={(e) => handleChange(e.target.value)}
                            onFocus={() => setIsFocused(true)}
                            onBlur={() => setIsFocused(false)}
                            className={`py-1 px-2 outline-none bg-transparent transition-colors cursor-text ${
                                className?.includes('w-') ? '' : 'w-auto min-w-0'
                            }`}
                            style={{
                                backgroundRepeat: 'no-repeat',
                                backgroundPosition: 'center bottom',
                            }}
                            animate={{
                                backgroundImage: !isValid && editing_mode
                                    ? 'linear-gradient(rgb(239, 68, 68), rgb(239, 68, 68))'
                                    : isFocused && editing_mode 
                                        ? 'linear-gradient(rgb(59, 130, 246), rgb(59, 130, 246))'
                                        : 'linear-gradient(rgb(209, 213, 219), rgb(209, 213, 219))',
                                backgroundSize: editing_mode ? '100% 2px' : '0% 2px',
                            }}
                            transition={{
                                backgroundSize: {
                                    duration: 0.3,
                                    ease: "easeOut"
                                },
                                backgroundImage: {
                                    duration: 0.2,
                                    ease: "easeOut"
                                }
                            }}
                        />
                    ) : (
                        <div className="flex items-center gap-2 py-1">
                            <p className="font-medium">{formatDateForDisplay(value) || 'No date set'}</p>
                        </div>
                    )}

                    {/* Reset button - only visible in editing mode */}
                    {editing_mode && onReset && (
                        <button
                            onClick={(e) => {onReset(); setIsValid(true); setValidationError('');}}
                            className="p-1 text-muted-foreground hover:text-foreground transition-colors"
                            title="Reset to original value"
                        >
                            <RotateCcw className="w-5 h-5" />
                        </button>
                    )}
                </div>
                
                {/* Validation error message */}
                {!isValid && editing_mode && validationError && (
                    <motion.p 
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-xs text-red-500 mt-1"
                    >
                        {validationError}
                    </motion.p>
                )}
            </div>
        </div>
    );
}

const CustomDateTimeInput = ({ label, value, onChange, editing_mode = false, validator, errorMessage, onReset, className }) => {
    const [isFocused, setIsFocused] = useState(false);
    const [isValid, setIsValid] = useState(true);
    const [validationError, setValidationError] = useState('');

    const validateInput = (inputValue) => {
        if (validator) {
            const validationResult = validator(inputValue);
            if (typeof validationResult === 'boolean') {
                setIsValid(validationResult);
                setValidationError(validationResult ? '' : errorMessage || 'Invalid datetime');
            } else if (validationResult && typeof validationResult === 'object') {
                setIsValid(validationResult.isValid);
                setValidationError(validationResult.isValid ? '' : validationResult.message || errorMessage || 'Invalid datetime');
            }
        } else {
            setIsValid(true);
            setValidationError('');
        }
    }

    const handleChange = (newValue) => {
        // Convert local datetime to ISO string with timezone for backend
        if (newValue) {
            const isoString = new Date(newValue).toISOString();
            onChange?.(isoString);
            validateInput(isoString);
        } else {
            onChange?.(null);
            validateInput(null);
        }
    };

    useEffect(() => {
        if (editing_mode) {
            validateInput(value);
        } else {
            setIsValid(true);
            setValidationError('');
        }
    }, [value, editing_mode, validator]);

    // Format datetime for display
    const formatDateTimeForDisplay = (dateTimeString) => {
        if (!dateTimeString) return '';
        const date = new Date(dateTimeString);
        if (isNaN(date.getTime())) return dateTimeString;
        return date.toLocaleString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    // Format datetime for input (local datetime-local format: YYYY-MM-DDTHH:mm)
    const formatDateTimeForInput = (dateTimeString) => {
        if (!dateTimeString) return '';
        const date = new Date(dateTimeString);
        if (isNaN(date.getTime())) return '';
        // Get local datetime string in format: YYYY-MM-DDTHH:mm
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        const hours = String(date.getHours()).padStart(2, '0');
        const minutes = String(date.getMinutes()).padStart(2, '0');
        return `${year}-${month}-${day}T${hours}:${minutes}`;
    };

    return (
        <div className={`custom-datetime-input ${className || ''}`}>
            <div className="flex flex-col gap-1">
                <div className="flex items-center gap-2">
                    {editing_mode ? (
                        <motion.input
                            type="datetime-local"
                            value={formatDateTimeForInput(value)}
                            onChange={(e) => handleChange(e.target.value)}
                            onFocus={() => setIsFocused(true)}
                            onBlur={() => setIsFocused(false)}
                            className={`py-1 px-2 outline-none bg-transparent transition-colors cursor-text ${
                                className?.includes('w-') ? '' : 'w-auto min-w-0'
                            }`}
                            style={{
                                backgroundRepeat: 'no-repeat',
                                backgroundPosition: 'center bottom',
                            }}
                            animate={{
                                backgroundImage: !isValid && editing_mode
                                    ? 'linear-gradient(rgb(239, 68, 68), rgb(239, 68, 68))'
                                    : isFocused && editing_mode 
                                        ? 'linear-gradient(rgb(59, 130, 246), rgb(59, 130, 246))'
                                        : 'linear-gradient(rgb(209, 213, 219), rgb(209, 213, 219))',
                                backgroundSize: editing_mode ? '100% 2px' : '0% 2px',
                            }}
                            transition={{
                                backgroundSize: {
                                    duration: 0.3,
                                    ease: "easeOut"
                                },
                                backgroundImage: {
                                    duration: 0.2,
                                    ease: "easeOut"
                                }
                            }}
                        />
                    ) : (
                        <div className="flex items-center gap-2 py-1">
                            <p className="font-medium">{formatDateTimeForDisplay(value) || 'No datetime set'}</p>
                        </div>
                    )}

                    {/* Reset button - only visible in editing mode */}
                    {editing_mode && onReset && (
                        <button
                            onClick={(e) => {onReset(); setIsValid(true); setValidationError('');}}
                            className="p-1 text-muted-foreground hover:text-foreground transition-colors"
                            title="Reset to original value"
                        >
                            <RotateCcw className="w-5 h-5" />
                        </button>
                    )}
                </div>
                
                {/* Validation error message */}
                {!isValid && editing_mode && validationError && (
                    <motion.p 
                        initial={{ opacity: 0, y: -5 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-xs text-red-500 mt-1"
                    >
                        {validationError}
                    </motion.p>
                )}
            </div>
        </div>
    );
}

export { CustomTextInput, CustomDateInput, CustomDateTimeInput };