"use client"

import Link from "next/link"
import { useRouter, usePathname } from "next/navigation"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { LogOut, ChevronDown } from "lucide-react"
import { Button } from "./ui/button"

import LogOutButton from "./LogOutButton"
import { useUser } from "../app/lib/auth/UserProvider"
import { useEffect } from "react"
import { useState } from "react"

const pages = [
    { name: "Dashboard", path: "/dashboard", description: "Overview of your activities" },
    { name: "Profile", path: "/profile", description: "View and edit your profile" },
    { name: "Leave Requests", path: "/leave-requests", description: "Manage your leave applications" },
    { name: "Appraisals", path: "/appraisal", description: "View and submit appraisals" },
    { name: "Admin", sub_paths: [
        { name: "Employee Management", sub_paths: [
            { name: "View Employees", path: "/admin/employee-management", description: "View and edit employee records" },
            { name: "Create Employee", path: "/admin/employee-management/create-employee", description: "Add new employee records" },
            { name: "Remove Employee", path: "/admin/employee-management/remove-employee", description: "Delete employee records" },
        ], description: "Manage employee records" },
        { name: "Appraisal Management", path: "/admin/appraisal-management", description: "Oversee appraisal processes" },
        { name: "Leave Management", path: "/admin/leave-management", description: "Manage leave requests" },
        
    ]},
]

const Navbar = () => {
  const router = useRouter()
  const pathname = usePathname()
  const currentUser = useUser()
  const [name, setName] = useState("")

  useEffect(() => {
    if(currentUser && !currentUser?.loading && currentUser?.user) {
      console.log("Current User in Navbar:", currentUser);
      setName(currentUser.user.first_name || "User");
    }
  }, [currentUser, currentUser?.loading, currentUser?.user]);

  const handleNavigation = (path) => {
    router.push(path)
  }

  const isPathActive = (item) => {
    if (item.path) {
      return pathname === item.path || pathname.startsWith(item.path + "/")
    }
    if (item.sub_paths) {
      return item.sub_paths.some(subItem => isPathActive(subItem))
    }
    return false
  }

  const renderNavItem = (item, index) => {
    // Regular path - direct navigation button
    if (item.path && !item.sub_paths) {
      return (
        <Button
          key={index}
          variant="ghost"
          size="sm"
          onClick={() => handleNavigation(item.path)}
          className={cn(
            "rounded-lg",
            isPathActive(item) && "bg-muted"
          )}
        >
          {item.name}
        </Button>
      )
    }

    // Sub-path - dropdown menu
    if (item.sub_paths) {
      return (
        <DropdownMenu key={index}>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className={cn(
                "rounded-lg",
                isPathActive(item) && "bg-muted"
              )}
            >
              {item.name}
              <ChevronDown className="ml-1 size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="w-auto min-w-[600px] p-4">
            <div className="flex gap-6">
              {item.sub_paths.map((subItem, subIndex) => (
                <div key={subIndex} className="flex-1 min-w-[180px]">
                  {/* If sub-item has sub_paths, render them vertically with header */}
                  {subItem.sub_paths ? (
                    <div className="flex flex-col gap-0.5">
                      <div className="px-3 py-2">
                        <div className="font-medium text-lg leading-tight">
                          {subItem.name}
                        </div>
                        {subItem.description && (
                          <div className="text-sm text-muted-foreground mt-0.5">
                            {subItem.description}
                          </div>
                        )}
                      </div>
                      {subItem.sub_paths.map((nestedItem, nestedIndex) => (
                        <DropdownMenuItem
                          key={nestedIndex}
                          onClick={() => handleNavigation(nestedItem.path)}
                          className="cursor-pointer flex-col items-start py-1.5 gap-0"
                        >
                          <span className="font-semibold text-sm leading-tight">{nestedItem.name}</span>
                          {nestedItem.description && (
                            <span className="text-xs text-muted-foreground leading-tight font-normal">
                              {nestedItem.description}
                            </span>
                          )}
                        </DropdownMenuItem>
                      ))}
                    </div>
                  ) : (
                    /* Regular path item */
                    <DropdownMenuItem
                      onClick={() => handleNavigation(subItem.path)}
                      className="cursor-pointer flex-col items-start py-2 gap-0.5"
                    >
                      <span className="font-medium text-lg leading-tight">{subItem.name}</span>
                      {subItem.description && (
                        <span className="text-sm text-muted-foreground leading-tight">
                          {subItem.description}
                        </span>
                      )}
                    </DropdownMenuItem>
                  )}
                </div>
              ))}
            </div>
          </DropdownMenuContent>
        </DropdownMenu>
      )
    }

    return null
  }

  return (
    <nav className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container mx-auto flex h-16 items-center justify-between px-4">
        <div className="flex items-center gap-2">
          <Link href="/dashboard" className="flex items-center gap-2">
            <span className="text-xl font-bold text-primary">SSSIHL UMS</span>
          </Link>

          <div className="flex items-center gap-1 ml-6">
            {pages.map((item, index) => renderNavItem(item, index))}
          </div>
        </div>

        <div className="flex items-center gap-2">
            <span className="font-medium">
              {name ? `Hello, ${name}` : '\u00A0'}
            </span>
            <LogOutButton />
        </div>
      </div>
    </nav>
  )
}

export default Navbar