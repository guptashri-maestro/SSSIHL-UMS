// TypeScript types mapped from Pydantic schemas in employee_management_backend/app/schemas/EmployeeModels.py

export interface EmployeeCreate {
  employee_code: string;
  salutation: string | null;
  first_name: string;
  last_name: string;
  gender_code: string | null;
  date_of_birth_val: string; // ISO date format (YYYY-MM-DD)
  blood_group: string | null;
  community_code: string | null;
  marital_status_code: string | null;
  official_email: string | null;
  personal_email: string | null;
  mobile_number: string | null;
  alternate_mobile_number: string | null;
  emergency_contact_name: string | null;
  emergency_contact_phone: string | null;
  department_id: number | null;
  unit_id: number | null;
  campus_id: number | null;
  reporting_manager_id: number | null;
  employee_category_code: string | null;
  employee_type_code: string | null;
  designation: string | null;
  role_nm: string | null;
  hire_date: string; // ISO date format (YYYY-MM-DD)
  employment_status_code: string | null;
  aadhaar_no: string | null;
  pan_no: string | null;
  uan_no: string | null;
}

export interface EmployeeResponse {
  employee_id: number;
  employee_code: string;
  salutation: string | null;
  first_name: string;
  last_name: string;
  gender_code: string | null;
  date_of_birth_val: string; // ISO date format (YYYY-MM-DD)
  blood_group: string | null;
  community_code: string | null;
  marital_status_code: string | null;
  official_email: string | null;
  personal_email: string | null;
  mobile_number: string | null;
  alternate_mobile_number: string | null;
  emergency_contact_name: string | null;
  emergency_contact_phone: string | null;
  department_id: number | null;
  unit_id: number | null;
  campus_id: number | null;
  reporting_manager_id: number | null;
  employee_category_code: string | null;
  employee_type_code: string | null;
  designation: string | null;
  role_nm: string | null;
  hire_date: string; // ISO date format (YYYY-MM-DD)
  probation_ended_dt: string | null; // ISO date format (YYYY-MM-DD)
  employment_status_code: string | null;
  separation_date: string | null; // ISO date format (YYYY-MM-DD)
  aadhaar_no: string | null;
  pan_no: string | null;
  uan_no: string | null;
  created_at: string; // ISO datetime format
  created_by: string | null;
  updated_at: string; // ISO datetime format
  updated_by: string | null;
}

export interface CognitoUserResponse {
  username: string;
  temp_password: string;
  status: string;
}

export interface EmployeeCreateResponse {
  employee: EmployeeResponse;
  cognito_user: CognitoUserResponse;
}

export interface EmployeeUpdate {
  employee_code: string | null;
  salutation: string | null;
  first_name: string | null;
  last_name: string | null;
  gender_code: string | null;
  date_of_birth_val: string | null; // ISO date format (YYYY-MM-DD)
  blood_group: string | null;
  community_code: string | null;
  marital_status_code: string | null;
  official_email: string | null;
  personal_email: string | null;
  mobile_number: string | null;
  alternate_mobile_number: string | null;
  emergency_contact_name: string | null;
  emergency_contact_phone: string | null;
  department_id: number | null;
  unit_id: number | null;
  campus_id: number | null;
  reporting_manager_id: number | null;
  employee_category_code: string | null;
  employee_type_code: string | null;
  designation: string | null;
  role_nm: string | null;
  hire_date: string | null; // ISO date format (YYYY-MM-DD)
  probation_ended_dt: string | null; // ISO date format (YYYY-MM-DD)
  employment_status_code: string | null;
  separation_date: string | null; // ISO date format (YYYY-MM-DD)
  aadhaar_no: string | null;
  pan_no: string | null;
  uan_no: string | null;
}
