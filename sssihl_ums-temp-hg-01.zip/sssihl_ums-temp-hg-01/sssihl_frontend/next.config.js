const nextConfig = {
  /* config options here */
  env: {
    COGNITO_ISSUER: process.env.COGNITO_ISSUER,
    COGNITO_USER_POOL_ID: process.env.COGNITO_USER_POOL_ID,
    COGNITO_APP_CLIENT_ID: process.env.COGNITO_APP_CLIENT_ID,
    COGNITO_REGION: process.env.COGNITO_REGION,
    EMP_LAMBDA_URL: process.env.EMP_LAMBDA_URL
  }
};


export default nextConfig;
