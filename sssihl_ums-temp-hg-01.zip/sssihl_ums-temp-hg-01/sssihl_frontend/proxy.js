import { NextResponse } from 'next/server';
import { decodeJwt } from "jose";

const PROTECTED_PATHS = ["/admin", "/profile"];

export function proxy(request) {
    const { pathname } = request.nextUrl;

    const isProtected = PROTECTED_PATHS.some((path) => pathname.startsWith(path));

    if (!isProtected) {
        return NextResponse.next();
    }

    const accessToken = request.cookies.get("accessToken")?.value;

    if(!accessToken) {
        const loginUrl = new URL('/login', request.url);
        // loginUrl.searchParams.set('redirect', pathname);   // Commenting out to avoid showing protected paths
        return NextResponse.redirect(loginUrl);
    }

    try {
        const payload = decodeJwt(accessToken);
        if (payload.exp * 1000 < Date.now()){
            throw new Error("Token expired");
        }
    } catch {
        return NextResponse.redirect(new URL("/login", request.url));
    }

    return NextResponse.next();
}

export const config = {
    matcher: ['/admin/:path*', '/profile/:path*'],
}

