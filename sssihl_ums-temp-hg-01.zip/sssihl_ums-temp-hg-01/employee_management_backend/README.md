# Employee Management Backend

A FastAPI-based backend service for managing employee data with PostgreSQL database and AWS Secrets Manager integration.

## Prerequisites

- Python 3.14+
- Poetry (Python dependency manager)
- PostgreSQL database
- AWS account with Secrets Manager access
- AWS CLI (for setting up secrets)
AWS Setup

### 1. Install AWS CLI

```bash
# macOS
brew install awscli

# Linux
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install

# Windows
# Download and run the AWS CLI MSI installer from:
# https://awscli.amazonaws.com/AWSCLIV2.msi
```

Verify installation:
```bash
aws --version
```

### 2. Configure AWS CLI

```bash
aws configure
```

You'll be prompted for:
employee-db-secret  # The name from AWS Secrets Manager
AWS_REGION=us-east-1                 # Match your AWS CLI configuration
```

**Note**: If you configured AWS CLI (Step 2 of AWS Setup), the application will use those credentials automatically. Otherwise, you can add:

```bash
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
```

### 4

**Note**: Save the secret name (`your-employee-db-secret`) - you'll need it for your `.env` file.

### 4. Verify Secret Creation

```bash
# List your secrets
aws secretsmanager list-secrets

# Retrieve the secret value to verify
aws secretsmanager get-secret-value --secret-id your-employee-db-secret
```

### 5. Set IAM Permissions

Ensure your IAM user/role has the following policy attached:
### 5. Start the Application
```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "secretsmanager:GetSecretValue",
                "secretsmanager:DescribeSecret"
            ],
            "Resource": "arn:aws:secretsmanager:REGION:ACCOUNT_ID:secret:your-employee-db-secret-*"
        }
    ]
}
```

## 
## Quick Start

### 1. Install Poetry

If you don't have Poetry installed:

```bash
# macOS/Linux
curl -sSL https://install.python-poetry.org | python3 -

# Or using pip
pip install poetry
```

### 2. Clone and Setup

```bash
# Navigate to the project directory
cd employee_management_backend

# Install all dependencies
poetry install
```

### 3. Configure Environment Variables

Create a `.env` file in the project root:

```bash
SECRET_NAME=your-aws-secrets-manager-secret-name
AWS_REGION=your-aws-region
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
```

### 4. Setup AWS Secrets Manager

Your AWS Secrets Manager secret should contain the following database credentials:

```json
{
  "username": "your_db_user",
  "password": "your_db_password",
  "host": "your_db_host",
  "port": "5432",
  "dbname": "your_database_name"
}
```

### 5. Run Database Migrations

```bash
# Run migrations to create database tables
poetry run alembic upgrade head
```
AWS CLI not configured
```bash
# Check current configuration
aws configure list

# Reconfigure if needed
aws configure
```

### Cannot access AWS Secrets Manager
- Verify your AWS credentials: `aws sts get-caller-identity`
- Check IAM permissions for Secrets Manager access
- Ensure the secret name in `.env` matches the one in AWS
- Verify the region in `.env` matches where your secret is stored

### Database connection errors
- Verify your AWS credentials are correct
- Ensure the Secrets Manager secret name matches your `.env` file
- Check that your PostgreSQL database is running and accessible
- Test secret retrieval: `aws secretsmanager get-secret-value --secret-id your-secret-name`
# Run the development server
poetry run uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at `http://localhost:8000`

## Development

### Running Tests

```bash
poetry run pytest
```

### Creating New Database Migrations

```bash
# Auto-generate migration from model changes
poetry run alembic revision --autogenerate -m "description of changes"

# Apply the migration
poetry run alembic upgrade head
```

### Adding New Dependencies

```bash
# Add a new package
poetry add package-name

# Add a dev dependency
poetry add --group dev package-name
```

## Project Structure

```
employee_management_backend/
├── app/
│   ├── core/           # Core configurations (AWS, DB, logging)
│   ├── db/             # Database models and session management
│   ├── routes/         # API route handlers
│   ├── schemas/        # Pydantic models for request/response
│   ├── services/       # Business logic layer
│   ├── repositories/   # Data access layer
│   └── main.py         # Application entry point
├── alembic/            # Database migrations
├── tests/              # Test files
├── pyproject.toml      # Poetry dependencies and config
└── alembic.ini         # Alembic configuration
```

## Tech Stack

- **Framework**: FastAPI
- **Database**: PostgreSQL with asyncpg
- **ORM**: SQLAlchemy (async)
- **Migrations**: Alembic
- **Server**: Uvicorn
- **Secrets**: AWS Secrets Manager
- **Package Manager**: Poetry

## Troubleshooting

### Poetry command not found
Add Poetry to your PATH:
```bash
export PATH="$HOME/.local/bin:$PATH"
```

### Database connection errors
- Verify your AWS credentials are correct
- Ensure the Secrets Manager secret name matches your `.env` file
- Check that your PostgreSQL database is running and accessible

### Migration errors
```bash
# Check current migration status
poetry run alembic current

# Rollback one migration
poetry run alembic downgrade -1
```