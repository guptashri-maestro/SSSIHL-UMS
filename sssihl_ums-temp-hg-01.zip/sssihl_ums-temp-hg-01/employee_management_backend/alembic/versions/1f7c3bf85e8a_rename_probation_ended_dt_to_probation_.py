"""rename probation_ended_dt to probation_ended_dt

Revision ID: 1f7c3bf85e8a
Revises: a37836020d52
Create Date: 2025-12-25 20:11:12.872683

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '1f7c3bf85e8a'
down_revision: Union[str, Sequence[str], None] = 'a37836020d52'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    pass


def downgrade() -> None:
    """Downgrade schema."""
    pass
