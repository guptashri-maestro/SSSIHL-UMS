import uuid
from fastapi import Request

async def request_context_middleware(request: Request, call_next):
    request_id = request.headers.get("x-request-id") or uuid.uuid4().hex[:12]
    request.state.request_id = request_id

    response = await call_next(request)

    response.headers["x-request-id"] = request_id
    return response