# This dependency will authenticate the user and retrieve their domain identity (e.g., employee code, roles, permissions)

from fastapi import Depends
from app.services.employee_service import EmployeeService
from app.core.errors.common import UnauthorizedError, NotFoundError
from app.dependencies.security_dependency import authenticate_user
from .services import get_employee_service

async def get_actor(
        current_user: dict = Depends(authenticate_user),
        service: EmployeeService = Depends(get_employee_service)
) -> dict:
    sub = current_user.get("sub")

    if not sub:
        raise UnauthorizedError(message="Authentication failed: 'sub' claim missing")
    
    try:
        result = await service.get_employee_code_by_sub(sub)
    except NotFoundError:
        raise UnauthorizedError(message="Authentication failed: Employee not found for given 'sub'")
    
    roles = []

    return {
        "employee_id": result["employee_id"],
        "employee_code": result["employee_code"],
        "roles": roles,
        "sub": sub,
    }
    
