from .db import get_db_with_user_context
from app.repositories.employee_repository import EmployeeRepository
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import Depends

def get_employee_repository(db: AsyncSession = Depends(get_db_with_user_context)) -> EmployeeRepository:
    return EmployeeRepository(db=db)