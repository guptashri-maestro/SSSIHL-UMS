from collections.abc import AsyncGenerator
from fastapi import Depends
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import AsyncSessionLocal
from app.dependencies.security_dependency import authenticate_user
from sqlalchemy import text

async def get_db() -> AsyncGenerator:
    """Basic database session without user context."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()

async def get_db_with_user_context(
    current_user = Depends(authenticate_user)
) -> AsyncGenerator:
    """
    Database session with user context set for audit triggers.
    
    Sets PostgreSQL session variables that can be read by database triggers:
    - app.current_user_id: The ID of the user making the change
    - app.current_user_email: The email of the user (optional)
    """
    async with AsyncSessionLocal() as session:
        try:
            # Extract user info
            user_id = current_user.get("user_id", "anonymous") if isinstance(current_user, dict) else str(current_user)
            user_email = current_user.get("email", "") if isinstance(current_user, dict) else ""
            
            # Set PostgreSQL session variables that triggers can read
            await session.execute(
                text("SELECT set_config('app.current_user_id', :user_id, true)"),
                {"user_id": user_id},
            )
            # if user_email:
            #     await session.execute(
            #         text("SET LOCAL app.current_user_email = :user_email", {"user_email": user_email})
            #     )
            
            yield session
        finally:
            await session.close()
