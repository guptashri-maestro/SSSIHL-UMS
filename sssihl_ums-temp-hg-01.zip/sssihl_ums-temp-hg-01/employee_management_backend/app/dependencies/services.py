import os
import dotenv
from app.services.employee_service import EmployeeService
from app.services.iam_service import IAMService

from app.core.aws import cognito_client, get_secret
from botocore.client import BaseClient

from app.repositories.employee_repository import EmployeeRepository
from fastapi import Depends
from .repositories import get_employee_repository

from app.core.errors.common import InternalConfigurationError

dotenv.load_dotenv()


def get_employee_service(employee_repository: EmployeeRepository = Depends(get_employee_repository)) -> EmployeeService:
    return EmployeeService(employee_repository=employee_repository)

def get_iam_service(cognito_client: BaseClient = Depends(cognito_client)) -> IAMService:
    COGINTO_SECRET_NAME = os.getenv("COGNITO_SECRET_NAME")
    if not COGINTO_SECRET_NAME:
        raise InternalConfigurationError(message="COGINTO_SECRET_NAME environment variable is not set")
    
    secrets = get_secret(COGINTO_SECRET_NAME)
    user_pool_id = secrets.get("AWS_COGNITO_USER_POOL_ID")
    if not user_pool_id:
        raise InternalConfigurationError(message="USER_POOL_ID not found in Cognito secrets")

    return IAMService(cognito_client=cognito_client, user_pool_id=user_pool_id)
