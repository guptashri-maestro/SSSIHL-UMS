import logging, uuid
from fastapi import Request
from app.core.logging_config import get_logger

class RequestLogger(logging.LoggerAdapter):
    def process(self, msg, kwargs):
        extra = self.extra
        prefix = f"[{extra['request_id']}] {extra['method']} {extra['path']}"

        return f"{prefix} | {msg}", kwargs
    
def logger(request: Request) -> logging.LoggerAdapter:
    rid = getattr(request.state, "request_id", None) or "no-req-id"

    base = get_logger("api")

    extra = {
        "request_id": rid,
        "method": request.method,
        "path": request.url.path,
        "client": request.client.host if request.client else None
    }

    return RequestLogger(base, extra)