from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

from app.core.auth.jwt_verifier import (
    verify_and_decode_cognito_jwt,
)

bearer_scheme = HTTPBearer(auto_error=False)

async def authenticate_user(
        credentials: HTTPAuthorizationCredentials = Depends(bearer_scheme)
):  

    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing authorization header"
        )
    
    token = credentials.credentials

    claims = await verify_and_decode_cognito_jwt(token)    

    return {
        "sub": claims["sub"],
        "username": claims.get("username"),
        "groups": claims.get("cognito:groups", []),
        "scope": claims.get("scope"),
        "token_use": claims.get("token_use"),
        "raw": claims,
        "is_authenticated": True,
    }