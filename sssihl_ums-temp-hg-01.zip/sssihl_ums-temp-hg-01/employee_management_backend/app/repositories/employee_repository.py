from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.db.models.employee import Employee
from app.schemas.filters import Filter
from app.db.filters.filter_compiler import compile_node
from app.core.logging_config import get_logger

from datetime import datetime, timezone
from datetime import datetime
from typing import Optional

from sqlalchemy.exc import IntegrityError
from sqlalchemy import func, extract

from app.core.errors.common import AlreadyExistsError, NotFoundError

log = get_logger("employee_repository")

class EmployeeRepository:
    EMPLOYEE_FIELD_MAP = {
        "employee_id": {
            "expr": Employee.employee_id,
            "ops": {"eq", "in"}
        },
        "employee_code": {
            "expr": Employee.employee_code,
            "ops": {"eq", "in"}
        },
        "first_name": {
            "expr": Employee.first_name,
            "ops": {"eq", "contains"}
        },
        "last_name": {
            "expr": Employee.last_name,
            "ops": {"eq", "contains"}
        },
        "name": {
            "expr": (Employee.first_name, Employee.last_name),
            "ops": {"contains"}
        },
        "gender": {
            "expr": Employee.gender_code,
            "ops": {"eq", "in"}
        },
        # "date_of_birth": Employee.date_of_birth_val,
        "age": {
            "expr": extract("year", func.age(func.current_date(), Employee.date_of_birth_val)),
            "ops": {"eq", "gte", "lte"}
        },
        "community_code": {
            "expr": Employee.community_code,
            "ops": {"eq", "in"}
        },
        #"marital_status": Employee.marital_status_code,
        "official_email": {
            "expr": Employee.official_email,
            "ops": {"eq", "in"}
        },
        "personal_email": {
            "expr": Employee.personal_email,
            "ops": {"eq", "in"}
        },
        "department_id": {
            "expr": Employee.department_id,
            "ops": {"eq", "in"}
        },
        "unit_id": {
            "expr": Employee.unit_id,
            "ops": {"eq", "in"}
        },
        "campus_id": {
            "expr": Employee.campus_id,
            "ops": {"eq", "in"}
        },
        "reporting_manager_id": {
            "expr": Employee.reporting_manager_id,
            "ops": {"eq", "in"}
        },
        "employee_category_code": {
            "expr": Employee.employee_category_code,
            "ops": {"eq", "in"}
        },
        "employee_type_code": {
            "expr": Employee.employee_type_code,
            "ops": {"eq", "in"}
        },
        "designation": {
            "expr": Employee.designation,
            "ops": {"eq", "in"}
        },
        "role_nm": {
            "expr": Employee.role_nm,
            "ops": {"eq", "in"}
        },
        "hire_date": {
            "expr": Employee.hire_date,
            "ops": {"eq", "gte", "lte"}
        },
        "employment_status_code": {
            "expr": Employee.employment_status_code,
            "ops": {"eq", "in"}
        },
        "probation_ended_dt": {
            "expr": Employee.probation_ended_dt,
            "ops": {"eq", "gte", "lte"}
        },
        "created_at": {
            "expr": Employee.created_at,
            "ops": {"eq", "gte", "lte"}
        },
        "updated_at": {
            "expr": Employee.updated_at,
            "ops": {"eq", "gte", "lte"}
        },
        "created_by": {
            "expr": Employee.created_by,
            "ops": {"eq", "in"}
        },
        "updated_by": {
            "expr": Employee.updated_by,
            "ops": {"eq", "in"}
        },
        "seperation_date": {
            "expr": Employee.separation_date,
            "ops": {"eq", "gte", "lte"}
        },
        "cognito_sub": {
            "expr": Employee.cognito_sub,
            "ops": {"eq", "in"}
        }
        # "street_address": Employee.street_address,
        # "city": {
        #     "expr": Employee.city,
        #     "ops": {"eq", "in"}
        # },
        # "state": {
        #     "expr": Employee.state,
        #     "ops": {"eq", "in"}
        # },
        # "postal_code": {
        #     "expr": Employee.postal_code,
        #     "ops": {"eq", "in"}
        # },
        # "country": {
        #     "expr": Employee.country,
        #     "ops": {"eq", "in"}
        # }
    }

    def __init__(self, db: AsyncSession):
        self.db = db

    async def commit(self):
        await self.db.commit()

    async def refresh(self, instance: Employee):
        await self.db.refresh(instance)

    async def rollback(self):
        await self.db.rollback()



    async def create_employee(self, employee: Employee, actor_employee_code: str) -> Employee:
        try:
            log.debug(
                "Attempting to create new employee",
                extra={
                    "employee_code": employee.employee_code,
                    "actor": actor_employee_code,
                },
            )

            # Set audit fields
            current_time = datetime.now(timezone.utc)
            employee.created_at = current_time
            employee.created_by = actor_employee_code
            employee.updated_at = current_time
            employee.updated_by = actor_employee_code

            # Try to add employee record to DB
            # Convention: Service layer handles commit/rollback
            self.db.add(employee)
            await self.db.flush()
            # await self.db.commit()
            # await self.db.refresh(employee)

            return employee
        
        except IntegrityError as ie:
            orig = ie.orig
            message = str(orig)
            log.error(
                f"Failed to create employee due to integrity error: {message[message.index('DETAIL'):]}",
                extra={
                    "employee_code": employee.employee_code,
                    "actor": actor_employee_code,
                    "error": message,
                    "message_details": message[message.index('DETAIL'):],
                },
            )
            raise AlreadyExistsError(entity="Employee", identifier=employee.employee_code, custom_message=message[message.index("DETAIL"):]) from ie
    
    

    async def update_employee(self, actor_employee_code: str, employee: Employee, updates: dict) -> bool:
        
        log.debug(f"Attempting to update employee with employee code {employee.employee_code} and updates: {updates}")
        
        # if employee is None:
        #     log.error("Employee to update doesn't exist")
        #     raise NotFoundError(entity="Employee", identifier="Unknown")

        # Apply updates
        for field, value in updates.items():
            setattr(employee, field, value)
        
        # Update audit fields
        timestamp = datetime.now(timezone.utc)
        employee.updated_at = timestamp
        employee.updated_by = actor_employee_code

        self.db.add(employee)
        # await self.db.commit() # Convention: Service layer handles commit/rollback
        # await self.db.refresh(employee) 


        log.debug(f"Employee with code {employee.employee_code} updated successfully")
        return True
    


    async def delete(self, employee: Employee) -> None:
        log.debug(f"Deleting employee with code {employee.employee_code}")

        # if employee is None:
        #     log.error("Employee to delete doesn't exist")
        #     raise NotFoundError(entity="Employee", identifier="Unknown")

        # Delete employee
        await self.db.delete(employee)
        # await self.db.commit() # Convention: Service layer handles commit/rollback
        log.debug(f"Employee with code {employee.employee_code} deleted successfully")

        return True
    


    async def search(self, filter: Filter | None, limit: int, offset:int) -> list[Employee]:
        log.debug(f"Searching employees with limit={limit}, offset={offset}")
        stmt = select(Employee)

        if filter:
            stmt = stmt.where(compile_node(filter.root, self.EMPLOYEE_FIELD_MAP))

        stmt = stmt.order_by(Employee.employee_id.asc())

        stmt = stmt.limit(limit).offset(offset)

        result = await self.db.execute(stmt)
        employees = result.scalars().all()
        log.debug(f"Search returned {len(employees)} employees")
        return employees
    


    async def get_employee_code_by_sub(self, cognito_sub: str) -> dict:
        log.debug(f"Querying employee with Cognito sub {cognito_sub}")

        result = await self.db.execute(
            select(Employee.employee_id, Employee.employee_code).where(Employee.cognito_sub == cognito_sub)
        )

        row = result.mappings().first()

        if row is None:
            log.debug(f"No employee found with Cognito sub {cognito_sub}")
            raise NotFoundError(entity="Employee", identifier=cognito_sub)
        
        return dict(row)



    async def get_by_code(self, employee_code: str) -> Employee:
        log.debug(f"Querying employee with code {employee_code}")
        result = await self.db.execute(
            select(Employee).where(Employee.employee_code == employee_code)
        )

        employee = result.scalar_one_or_none()

        if employee is None:
            log.debug(f"Employee with code {employee_code} not found")
            raise NotFoundError(entity="Employee", identifier=employee_code)
        
        return employee