from __future__ import annotations

from pydantic import BaseModel
from typing import Literal, Any, List, Union
from app.db.models.employee import Employee
from sqlalchemy import func, extract
from pydantic import model_validator

from app.core.errors.common import ValidationError

class Condition(BaseModel):
    field: str
    operator: Literal["eq", "in", "contains", "gte", "lte"]
    value: Any

class FilterGroup(BaseModel):
    and_: List[Union[FilterGroup, Condition]] | None = None
    or_: List[Union[FilterGroup, Condition]] | None = None

    @model_validator(mode="after")
    def validate_group(self):
        if (self.and_ is None and self.or_ is None) or (self.and_ is not None and self.or_ is not None):
            raise ValidationError(message="FilterGroup must have exactly one of 'and_' or 'or_'")

        return self
FilterNode = Union[Condition, FilterGroup]

class Filter(BaseModel):
    root: FilterNode

    @model_validator(mode="after")
    def normalize_root(self):
        if isinstance(self.root, Condition):
            self.root = FilterGroup(and_=[self.root])
        
        return self