from pydantic import BaseModel
from typing import Any, Optional, Dict

class ErrorBody(BaseModel):
    code: str
    message: str
    details: Dict[str, Any] = {}

class ErrorResponse(BaseModel):
    error: ErrorBody