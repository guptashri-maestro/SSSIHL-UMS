import datetime as dt
from pydantic import BaseModel, EmailStr, ConfigDict, Field
from typing import List
from typing import Optional
from app.dependencies.pagination_dependency import PaginationParams
from pydantic import model_validator
from app.schemas.filters import Filter

class EmployeeCreate(BaseModel):
    """Schema for creating a new employee (incoming request)"""
    employee_code: str = Field(..., min_length=1, max_length=50)
    salutation: Optional[str] = Field(None, max_length=10)
    first_name: str = Field(..., min_length=1, max_length=255)
    last_name: str = Field(..., min_length=1, max_length=255)
    gender_code: Optional[str] = Field(None, max_length=10)
    date_of_birth_val: dt.date
    blood_group: Optional[str] = Field(None, max_length=10)
    community_code: Optional[str] = Field(None, max_length=20)
    marital_status_code: Optional[str] = Field(None, max_length=20)
    official_email: Optional[EmailStr] = None
    personal_email: Optional[EmailStr] = None
    mobile_number: Optional[str] = Field(None, max_length=20)
    alternate_mobile_number: Optional[str] = Field(None, max_length=20)
    emergency_contact_name: Optional[str] = Field(None, max_length=100)
    emergency_contact_phone: Optional[str] = Field(None, max_length=20)
    department_id: Optional[int] = None
    unit_id: Optional[int] = None
    campus_id: Optional[int] = None
    reporting_manager_id: Optional[int] = None
    employee_category_code: Optional[str] = Field(None, max_length=20)
    employee_type_code: Optional[str] = Field(None, max_length=20)
    designation: Optional[str] = Field(None, max_length=100)
    role_nm: Optional[str] = Field(None, max_length=50)
    hire_date: dt.date
    employment_status_code: Optional[str] = Field(None, max_length=20)
    aadhaar_no: Optional[str] = Field(None, max_length=20)
    pan_no: Optional[str] = Field(None, max_length=20)
    uan_no: Optional[str] = Field(None, max_length=20)

class EmployeeResponse(BaseModel):
    """Schema for employee response (outgoing from ORM)"""
    employee_id: int
    employee_code: str
    salutation: Optional[str]
    first_name: str
    last_name: str
    gender_code: Optional[str]
    date_of_birth_val: dt.date
    blood_group: Optional[str]
    community_code: Optional[str]
    marital_status_code: Optional[str]
    official_email: Optional[EmailStr]
    personal_email: Optional[EmailStr]
    mobile_number: Optional[str]
    alternate_mobile_number: Optional[str]
    emergency_contact_name: Optional[str]
    emergency_contact_phone: Optional[str]
    department_id: Optional[int]
    unit_id: Optional[int]
    campus_id: Optional[int]
    reporting_manager_id: Optional[int]
    employee_category_code: Optional[str]
    employee_type_code: Optional[str]
    designation: Optional[str]
    role_nm: Optional[str]
    hire_date: dt.date
    probation_ended_dt: Optional[dt.date]
    employment_status_code: Optional[str]
    separation_date: Optional[dt.date]
    aadhaar_no: Optional[str]
    pan_no: Optional[str]
    uan_no: Optional[str]
    # cognito_sub: Optional[str]
    created_at: dt.datetime
    created_by: Optional[str]
    updated_at: dt.datetime
    updated_by: Optional[str]
    
    model_config = ConfigDict(from_attributes=True)

class CognitoUserResponse(BaseModel):
    username: str
    temp_password:str
    status: str
class EmployeeCreateResponse(BaseModel):
    employee: EmployeeResponse
    cognito_user: CognitoUserResponse

class EmployeeSearch(BaseModel):
    """Schema for searching employees based on various parameters"""
    filter: Filter | None = None
    pagination: PaginationParams

class EmployeeUpdate(BaseModel):
    """Schema for updating an existing employee (incoming request)"""
    employee_code: Optional[str] = Field(None, min_length=1, max_length=50)
    salutation: Optional[str] = Field(None, max_length=10)
    first_name: Optional[str] = Field(None, min_length=1, max_length=255)
    last_name: Optional[str] = Field(None, min_length=1, max_length=255)
    gender_code: Optional[str] = Field(None, max_length=10)
    date_of_birth_val: Optional[dt.date] = None
    blood_group: Optional[str] = Field(None, max_length=10)
    community_code: Optional[str] = Field(None, max_length=20)
    marital_status_code: Optional[str] = Field(None, max_length=20)
    official_email: Optional[EmailStr] = None
    personal_email: Optional[EmailStr] = None
    mobile_number: Optional[str] = Field(None, max_length=20)
    alternate_mobile_number: Optional[str] = Field(None, max_length=20)
    emergency_contact_name: Optional[str] = Field(None, max_length=100)
    emergency_contact_phone: Optional[str] = Field(None, max_length=20)
    department_id: Optional[int] = None
    unit_id: Optional[int] = None
    campus_id: Optional[int] = None
    reporting_manager_id: Optional[int] = None
    employee_category_code: Optional[str] = Field(None, max_length=20)
    employee_type_code: Optional[str] = Field(None, max_length=20)
    designation: Optional[str] = Field(None, max_length=100)
    role_nm: Optional[str] = Field(None, max_length=50)
    hire_date: Optional[dt.date] = None
    probation_ended_dt: Optional[dt.date] = None
    employment_status_code: Optional[str] = Field(None, max_length=20)
    separation_date: Optional[dt.date] = None
    aadhaar_no: Optional[str] = Field(None, max_length=20)
    pan_no: Optional[str] = Field(None, max_length=20)
    uan_no: Optional[str] = Field(None, max_length=20)
    # cognito_sub: Optional[str] = Field(None, max_length=255)
    # created_at: Optional[dt.datetime] = Field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))
    # updated_at: Optional[dt.datetime] = Field(default_factory=lambda: dt.datetime.now(dt.timezone.utc))
    # created_by: Optional[str] = Field(None, max_length=100)
    # updated_by: Optional[str] = Field(None, max_length=100)

    class Config:
        extra = "forbid"










    
# class EmployeeSearch(BaseModel):
#     """Schema for searching employees based on various parameters"""
#     # Selection based filters
#     first_name: Optional[str] = Field(default = None, description = "List of first names to filter by", max_items = 20)
#     last_name: Optional[str] = Field(default = None, description = "List of last names to filter by", max_items = 20)
#     name: Optional[str] = Field(default = None, description = "Partial name to search in first and last names", max_length = 255)
#     gender: Optional[List[str]] = Field(default = None, description = "List of genders to filter by", max_items = 5)
#     city: Optional[List[str]] = Field(default = None, description = "List of cities to filter by", max_items = 20)
#     state: Optional[List[str]] = Field(default = None, description = "List of states to filter by", max_items = 20)
#     country: Optional[List[str]] = Field(default = None, description = "List of countries to filter by", max_items = 20)
#     department_id: Optional[List[int]] = Field(default = None, description = "List of department IDs to filter by", max_items = 10)
#     designation: Optional[List[str]] = Field(default = None, description = "List of designations to filter by", max_items = 20)
#     role_name: Optional[List[str]] = Field(default = None, description = "List of role names to filter by", max_items = 10)
#     employment_status: Optional[List[str]] = Field(default = None, description = "List of employment statuses to filter by", max_items = 10)
#     employee_type: Optional[List[str]] = Field(default = None, description = "List of employee types to filter by", max_items = 10)
#     manager_employee_id: Optional[List[int]] = Field(default = None, description = "List of manager employee IDs to filter by", max_items = 20)
#     campus_id: Optional[List[int]] = Field(default = None, description = "List of campus IDs to filter by", max_items = 10)

#     # Range based filters
#     age_min: Optional[int] = Field(default = None, description = "Minimum age to filter by", ge = 0, le = 150)
#     age_max: Optional[int] = Field(default = None, description = "Maximum age to filter by", ge = 0, le = 150)
#     hire_date_start: Optional[dt.date] = Field(default = None, description = "Start hire date to filter by")
#     hire_date_end: Optional[dt.date] = Field(default = None, description = "End hire date to filter by")
#     probation_ended_start: Optional[dt.date] = Field(default = None, description = "Start probation end date to filter by")
#     probation_ended_end: Optional[dt.date] = Field(default = None, description = "End probation end date to filter by")
#     created_at_start: Optional[dt.datetime] = Field(default = None, description = "Start created at datetime to filter by")
#     created_at_end: Optional[dt.datetime] = Field(default = None, description = "End created at datetime to filter by")
#     updated_at_start: Optional[dt.datetime] = Field(default = None, description = "Start updated at datetime to filter by")
#     updated_at_end: Optional[dt.datetime] = Field(default = None, description = "End updated at datetime to filter by")

#     @model_validator(mode="after")
#     def validate_ranges(self):
#         if self.age_min is not None and self.age_max is not None:
#             if self.age_min > self.age_max:
#                 raise ValueError("age_min cannot be greater than age_max")
#         if self.hire_date_start is not None and self.hire_date_end is not None:
#             if self.hire_date_start > self.hire_date_end:
#                 raise ValueError("hire_date_start cannot be greater than hire_date_end")
#         if self.probation_ended_start is not None and self.probation_ended_end is not None:
#             if self.probation_ended_start > self.probation_ended_end:
#                 raise ValueError("probation_ended_start cannot be greater than probation_ended_end")
#         if self.created_at_start is not None and self.created_at_end is not None:
#             if self.created_at_start > self.created_at_end:
#                 raise ValueError("created_at_start cannot be greater than created_at_end")
#         if self.updated_at_start is not None and self.updated_at_end is not None:
#             if self.updated_at_start > self.updated_at_end:
#                 raise ValueError("updated_at_start cannot be greater than updated_at_end")
#         return self

# class EmployeeSearchPaginated(BaseModel):
#     filters: EmployeeSearch
#     pagination: PaginationParams
