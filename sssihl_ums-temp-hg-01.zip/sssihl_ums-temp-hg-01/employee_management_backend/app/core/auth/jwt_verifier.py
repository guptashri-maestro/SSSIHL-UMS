import jwt 
from jwt import PyJWTError
from typing import Dict

from .jwks import get_jwks
from .cognito_user_auth_settings import cognito_settings

from app.core.errors.common import AuthenticationError

class CognitoJWTError(Exception):
    pass

async def verify_and_decode_cognito_jwt(token: str) -> Dict:
    try:
        unverified_header = jwt.get_unverified_header(token)
    except PyJWTError:
        raise AuthenticationError(message="Invalid JWT Header")
    
    kid = unverified_header.get("kid")
    if not kid:
        raise AuthenticationError(message="Missing 'kid' in token header")
    
    jwks = await get_jwks()

    key = next((k for k in jwks["keys"] if k["kid"] == kid), None)

    if not key:
        raise AuthenticationError(message="Signing key not found")
    
    public_key = jwt.algorithms.RSAAlgorithm.from_jwk(key)

    try:
        claims = jwt.decode(
            token,
            public_key,
            algorithms=["RS256"],
            issuer=cognito_settings.issuer,
            options={"verify_aud": False},  # We are not verifying audience for access tokens
        )

    except PyJWTError as e:
        raise AuthenticationError(message="Invalid or expired token") from e
    
        # 🔐 Enforce correct token type
    if claims.get("token_use") != "access":
        raise AuthenticationError(message="Invalid token type")

    # 🔐 Enforce correct app client
    if claims.get("client_id") != cognito_settings.app_client_id:
        raise AuthenticationError(message="Invalid client_id")
    
    
    if claims.get("token_use") != "access":
        raise AuthenticationError(message="Invalid token use")
    
    return claims