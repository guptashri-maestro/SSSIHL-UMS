from pydantic_settings import BaseSettings
from app.core.aws import get_secret
import os

class CognitoSettings(BaseSettings):
    region: str
    user_pool_id: str
    app_client_id: str

    @property
    def issuer(self) -> str:
        return f"https://cognito-idp.{self.region}.amazonaws.com/{self.user_pool_id}"
    
    @property
    def jwks_url(self) -> str:
        return f"{self.issuer}/.well-known/jwks.json"
    
    # class Config:
    #     env_prefix = "AWS_COGNITO_"

def get_cognito_settings() -> CognitoSettings:
    COGINTO_SECRET_NAME = os.getenv("COGNITO_SECRET_NAME")
    if not COGINTO_SECRET_NAME:
        raise ValueError("COGINTO_SECRET_NAME environment variable is not set")
    
    secrets = get_secret(COGINTO_SECRET_NAME)

    return CognitoSettings(
        region=secrets["AWS_COGNITO_REGION"],
        user_pool_id=secrets["AWS_COGNITO_USER_POOL_ID"],
        app_client_id=secrets["AWS_COGNITO_APP_CLIENT_ID"],
    )




cognito_settings = get_cognito_settings()