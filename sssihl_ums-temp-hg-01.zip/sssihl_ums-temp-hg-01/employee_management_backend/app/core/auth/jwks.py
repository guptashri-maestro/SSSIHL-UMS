import httpx
import time
from typing import Dict

from .cognito_user_auth_settings import cognito_settings

_JWKS_CACHE: Dict | None = None
_JWKS_FETHCED_AT: float | None = None
_JWKS_TTL = 60 * 60 * 24 # 24 hours

async def get_jwks() -> Dict:
    global _JWKS_CACHE, _JWKS_FETCHED_AT

    now = time.time()

    if _JWKS_CACHE and _JWKS_FETCHED_AT:
        if now - _JWKS_FETCHED_AT < _JWKS_TTL:
            return _JWKS_CACHE
    
    # Fetch new JWKS
    async with httpx.AsyncClient(timeout=10) as client:
        response = await client.get(cognito_settings.jwks_url)
        response.raise_for_status()
        _JWKS_CACHE = response.json()
        _JWKS_FETCHED_AT = now

    return _JWKS_CACHE