from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from sqlalchemy.sql import Select

async def paginate_async(
        db: AsyncSession,
        stmt: Select,
        limit: int, 
        offset: int
):
    # Total count 
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = await db.scalar(count_stmt)
    total = int(total or 0)

    # Page slice
    result = await db.execute(stmt.limit(limit).offset(offset))
    items = result.scalars().all()

    return {
        "items": items,
        "total": total,
        "limit": limit,
        "offset": offset,
        "has_more": (offset + limit) < total
    }