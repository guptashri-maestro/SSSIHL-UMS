import logging, logging.config, os, sys, dotenv

dotenv.load_dotenv()

log_namespace = "employee_management"

def setup_logging():
    level = os.getenv("LOG_LEVEL", "INFO").upper()

    LOG_CONFIG = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": "%(asctime)s %(levelname)s [%(name)s] %(message)s",
                "datefmt": "%Y-%m-%dT%H:%M:%S",
            }
        },
        "handlers": {
            "stdout": {
                "class": "logging.StreamHandler", 
                "stream": sys.stdout,
                "level": level,
                "formatter": "default",
            }
        },
        "loggers": {
            log_namespace: {
                "handlers": ["stdout"],
                "level": level,
                "propagate": False,
            }
        }
    }
    logging.config.dictConfig(LOG_CONFIG)

def get_logger(name: str | None = None) -> logging.Logger:
    return logging.getLogger(f"{log_namespace}{('.' + name) if name else ''}")