from typing import Optional, Dict, Any

class AppError(Exception):
    """Base application error class"""
    
    code: str = "INTERNAL_ERROR"
    message: str = "An unexpected error occured"
    http_status: int = 500

    def __init__(self, *, message: Optional[str] = None, details: Optional[Dict[str, Any]] = None):
        self.details = details or {}

        if message:
            self.message = message
        
        super().__init__(self.message)

        
