# This file will contain common domain error definitions

from .base import AppError

class NotFoundError(AppError):
    http_status = 404
    code = "RESOURCE_NOT_FOUND"

    def __init__(self, *, entity: str, identifier: str):
        super().__init__(
            message=f"{entity} with identifier '{identifier}' not found.",
            details={"entity": entity, "identifier": identifier},
        )


class AlreadyExistsError(AppError):
    http_status = 409
    code = "RESOURCE_ALREADY_EXISTS"

    def __init__(self, *, entity: str, identifier: str, custom_message: str | None = None):
        super().__init__(
            message=custom_message or f"{entity} with identifier '{identifier}' already exists.",
            details={"entity": entity, "identifier": identifier},
        )

class ValidationError(AppError):
    http_status = 400
    code = "VALIDATION_ERROR"

    def __init__(self, *, message: str, details: dict | None = None):
        super().__init__(
            message=message,
            details=details,
        )

class PermissionError(AppError):
    http_status = 403
    code = "PERMISSION_DENIED"

    def __init__(self, *, message: str = "Permission denied", details: dict | None = None):
        super().__init__(
            message=message,
            details=details,
        )

class UnauthorizedError(AppError):
    http_status = 401
    code = "UNAUTHORIZED"

    def __init__(self, *, message: str = "Unauthorized access", details: dict | None = None):
        super().__init__(
            message=message,
            details=details,
        )

class AuthenticationError(AppError):
    http_status = 401
    code = "UNAUTHENTICATED"

    def __init__(self, *, message: str = "Authentication failed", details: dict | None = None):
        super().__init__(
            message=message,
            details=details,
        )

class ExternalServiceError(AppError):
    http_status = 502
    code = "EXTERNAL_SERVICE_ERROR"

    def __init__(self, *, service_name: str, message: str = "External service error", details: dict | None = None):
        super().__init__(
            message=f"{service_name} error: {message}",
            details=details,
        )

class InternalConfigurationError(AppError):
    http_status = 500
    code = "INTERNAL_CONFIGURATION_ERROR"

    def __init__(self, *, message: str = "Internal configuration error", details: dict | None = None):
        super().__init__(
            message=message,
            details=details,
        )