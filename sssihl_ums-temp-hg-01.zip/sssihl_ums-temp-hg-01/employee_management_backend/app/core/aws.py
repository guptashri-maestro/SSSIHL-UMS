# Set up AWS secrets manager client

import boto3
from botocore.config import Config
import json
from functools import lru_cache

@lru_cache
def secrets_client():
    return boto3.client("secretsmanager")

@lru_cache
def cognito_client():
    return boto3.client(
        "cognito-idp",
        config=Config(
            retries={"max_attempts": 5, "mode": "standard"},
            connect_timeout=3,
            read_timeout=10,
            )
    )

def get_secret(secret_name: str) -> dict:
    client = secrets_client()
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response["SecretString"])
