from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List

from app.schemas.EmployeeModels import EmployeeCreate, EmployeeResponse, EmployeeSearch, EmployeeUpdate, EmployeeCreateResponse


from app.dependencies.services import get_employee_service, get_iam_service
from app.services.employee_service import EmployeeService

from app.dependencies.logging_dependency import logger
from app.dependencies.security_dependency import authenticate_user
from app.dependencies.actor_dependency import get_actor
from app.services.iam_service import IAMService

import logging

import time
from datetime import datetime, timezone

from app.schemas.error_responses import ErrorResponse

from app.core.errors.common import NotFoundError, AlreadyExistsError, UnauthorizedError, ValidationError

router = APIRouter(prefix="/employees", tags=["employees"], dependencies=[Depends(authenticate_user)])

@router.get("/test-log")
async def test_log(log: logging.LoggerAdapter = Depends(logger)):
    log.info("Logging test called from employees route")
    return {"ok": True}

@router.post("/create", 
             response_model=EmployeeCreateResponse,
            status_code=status.HTTP_201_CREATED,
             summary="Create a new employee record",
             responses={
                   status.HTTP_201_CREATED: {"description": "Employee created successfully"},
                   status.HTTP_400_BAD_REQUEST: {"description": "Bad Request - Invalid Input", "model": ErrorResponse},
                   status.HTTP_409_CONFLICT: {"description": "Conflict - Resource already exists", "model": ErrorResponse},
                   status.HTTP_500_INTERNAL_SERVER_ERROR: {"description": "Internal server error", "model": ErrorResponse},
                   status.HTTP_502_BAD_GATEWAY: {"description": "Bad Gateway - External service error", "model": ErrorResponse}
               }
             )
async def create_employee(
    payload: EmployeeCreate,
    employee_service: EmployeeService = Depends(get_employee_service),
    iam_service: IAMService = Depends(get_iam_service),
    log: logging.LoggerAdapter = Depends(logger),
    actor: dict = Depends(get_actor),
) -> EmployeeCreateResponse:
    # First we create the user in Cognito
    given_name = payload.first_name
    family_name = payload.last_name
    username = given_name.lower() + "." + family_name.lower()
    email = payload.official_email
    temporary_password = "TempPass123!"

    # Make call to IAM service to create Cognito user
    cognito_user = await iam_service.admin_create_cognito_user(username=username,
                                        temporary_password=temporary_password, given_name=given_name,
                                        family_name=family_name, email=email)
    
    # Now we create the employee record in our DB
    actor_employee_code = actor["employee_code"]

    employee_data = payload.model_dump()

    employee_data["cognito_sub"] = cognito_user.pop("sub")  # Popping cognito sub for use in DB employee creation and so it isn't returned in response
    # employee_data["cognito_sub"] = "dummy-sub-for-testing"  # Temporary line for testing without Cognito

    employee = await employee_service.create_employee(actor_employee_code, employee_data)

    # Parse ORM result to dict
    # employee_out = EmployeeResponse.model_validate(employee)

    return EmployeeCreateResponse(employee=employee, cognito_user=cognito_user)

@router.get("/get-by-code/{employee_code}", response_model=EmployeeResponse,
            summary="Get employee record by employee code",
            status_code=status.HTTP_200_OK,
            responses={
                   status.HTTP_200_OK: {"description": "Employee record fetched successfully"},
                   status.HTTP_404_NOT_FOUND: {"description": "Employee not found", "model": ErrorResponse},
                   status.HTTP_500_INTERNAL_SERVER_ERROR: {"description": "Internal server error", "model": ErrorResponse}
               }
            )
async def get_employee_by_code(employee_code: str, service: EmployeeService = Depends(get_employee_service), log: logging.LoggerAdapter = Depends(logger), current_user = Depends(authenticate_user)) -> EmployeeResponse:
    
    employee = await service.get_employee_by_code(employee_code)

    return employee

@router.get("/me", response_model=EmployeeResponse,
            summary="Get current logged-in user's employee record",
            status_code=status.HTTP_200_OK,
            responses={
                   status.HTTP_200_OK: {"description": "Employee record fetched successfully"},
                   status.HTTP_404_NOT_FOUND: {"description": "Employee not found", "model": ErrorResponse},
                   status.HTTP_500_INTERNAL_SERVER_ERROR: {"description": "Internal server error", "model": ErrorResponse}
               }
            )
async def get_current_user_employee_record(service: EmployeeService = Depends(get_employee_service), log: logging.LoggerAdapter = Depends(logger), actor: dict = Depends(get_actor)) -> EmployeeResponse:
    
    employee = await service.get_employee_by_code(actor["employee_code"])

    return employee


"""Example input for this search endpoint:
curl -X 'POST' \
  'http://localhost:8000/employees/search' \
  -H 'accept: application/json' \
  -H 'Content-Type: application/json' \
  -d '{
  "filter": {
    "root": {
      "and_": [
        { "field": "employee_id", "operator": "eq", "value": 6 },
        { "field": "first_name", "operator": "eq", "value": "joe" }
      ]
    }
  },
  "pagination": {
    "limit": 20,
    "offset": 0
  }
}
'
"""
# Allows querying employees based on various parameters
@router.post("/search", response_model=List[EmployeeResponse], status_code=status.HTTP_200_OK, summary="Search employees based on various filters", responses={
                status.HTTP_200_OK: {"description": "Employee search completed successfully"},
                status.HTTP_400_BAD_REQUEST: {"description": "Bad Request - Invalid Input", "model": ErrorResponse},
                status.HTTP_500_INTERNAL_SERVER_ERROR: {"description": "Internal server error", "model": ErrorResponse}
            })
async def search_employees(payload: EmployeeSearch, service: EmployeeService = Depends(get_employee_service), log: logging.LoggerAdapter = Depends(logger), current_user = Depends(authenticate_user)) -> List[EmployeeResponse]:
    employees = await service.search_employees(filter=payload.filter, pagination=payload.pagination)

    return employees

# Updates an existing employee record
@router.patch("/{employee_code}", 
            summary="Update an existing employee record",
            status_code=status.HTTP_204_NO_CONTENT,
            responses={
                   status.HTTP_204_NO_CONTENT: {"description": "Employee updated successfully"},
                   status.HTTP_404_NOT_FOUND: {"description": "Employee not found", "model": ErrorResponse},
                   status.HTTP_500_INTERNAL_SERVER_ERROR: {"description": "Internal server error", "model": ErrorResponse}
               },)
async def update_employee(
    employee_code: str,
    payload: EmployeeUpdate,
    service: EmployeeService = Depends(get_employee_service),
    log: logging.LoggerAdapter = Depends(logger),
    actor: dict = Depends(get_actor),
):
    # Get actor employee code from current user
    actor_employee_code = actor["employee_code"]

    await service.update_employee(employee_code, payload, actor_employee_code)

    return None

# Deletes an employee record
@router.delete("/{employee_code}", 
               summary="Delete an employee record",
               status_code=status.HTTP_204_NO_CONTENT,
               responses={
                   status.HTTP_204_NO_CONTENT: {"description": "Employee deleted successfully"},
                   status.HTTP_404_NOT_FOUND: {"description": "Employee not found", "model": ErrorResponse},
                   status.HTTP_500_INTERNAL_SERVER_ERROR: {"description": "Internal server error", "model": ErrorResponse}
               })
async def delete_employee(
    employee_code: str,
    service: EmployeeService = Depends(get_employee_service),
    log: logging.LoggerAdapter = Depends(logger),
    actor: dict = Depends(get_actor)
):
    
    await service.delete_employee(employee_code)
    return None