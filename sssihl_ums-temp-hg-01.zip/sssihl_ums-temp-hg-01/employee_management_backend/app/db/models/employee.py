import datetime as dt
from sqlalchemy import String, Date, DateTime
from sqlalchemy.orm import Mapped, mapped_column
from app.db.base import Base

class Employee(Base):
    __tablename__ = "employee"
    __table_args__ = {"schema": "employee_mgmt"}

    employee_id: Mapped[int] = mapped_column( primary_key=True)
    employee_code: Mapped[str] = mapped_column(String(), nullable=False, unique=True)
    salutation: Mapped[str | None] = mapped_column(String())
    first_name: Mapped[str] = mapped_column(String(), nullable=False)
    last_name: Mapped[str] = mapped_column(String(), nullable=False)
    gender_code: Mapped[str | None] = mapped_column(String())
    date_of_birth_val: Mapped[dt.date] = mapped_column(Date, nullable=False)
    blood_group: Mapped[str | None] = mapped_column(String())
    community_code: Mapped[str | None] = mapped_column(String())
    marital_status_code: Mapped[str | None] = mapped_column(String())
    official_email: Mapped[str | None] = mapped_column(String())
    personal_email: Mapped[str | None] = mapped_column(String())
    mobile_number: Mapped[str | None] = mapped_column(String())
    alternate_mobile_number: Mapped[str | None] = mapped_column(String())
    emergency_contact_name: Mapped[str | None] = mapped_column(String())
    emergency_contact_phone: Mapped[str | None] = mapped_column(String())
    department_id: Mapped[int | None] = mapped_column()
    unit_id: Mapped[int | None] = mapped_column()
    campus_id: Mapped[int | None] = mapped_column()
    reporting_manager_id: Mapped[int | None] = mapped_column()
    employee_category_code: Mapped[str | None] = mapped_column(String())
    employee_type_code: Mapped[str | None] = mapped_column(String())
    designation: Mapped[str | None] = mapped_column(String())
    role_nm: Mapped[str | None] = mapped_column(String())
    hire_date: Mapped[dt.date] = mapped_column(Date, nullable=False)
    probation_ended_dt: Mapped[dt.date | None] = mapped_column(Date)
    employment_status_code: Mapped[str | None] = mapped_column(String())
    separation_date: Mapped[dt.date | None] = mapped_column(Date)
    aadhaar_no: Mapped[str | None] = mapped_column(String())
    pan_no: Mapped[str | None] = mapped_column(String())
    uan_no: Mapped[str | None] = mapped_column(String())
    cognito_sub: Mapped[str | None] = mapped_column(String())
    created_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True))
    created_by: Mapped[str | None] = mapped_column(String())
    updated_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    updated_by: Mapped[str | None] = mapped_column(String())
