from sqlalchemy.sql import Select
from typing import Iterable

def apply_in_filter(stmt: Select, column, values: Iterable | None):
    if values:
        stmt = stmt.where(column.in_(values))
    return stmt

# Range filter is inclusive of max and min values
def apply_range_filter(stmt: Select, column, min_val, max_val):
    if min_val is not None:
        stmt = stmt.where(column >= min_val)
    if max_val is not None:
        stmt = stmt.where(column <= max_val)
    return stmt

def apply_boolean_filter(stmt: Select, column, value: bool | None):
    if value is not None:
        stmt = stmt.where(column.is_(value))
    return stmt