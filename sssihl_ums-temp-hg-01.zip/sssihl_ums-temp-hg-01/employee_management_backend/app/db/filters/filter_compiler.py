from sqlalchemy import and_, or_
from sqlalchemy.sql.elements import ClauseElement

from app.schemas.filters import Condition, FilterGroup, FilterNode

from app.core.errors.common import ValidationError

def compile_condition(cond: Condition, field_map: dict) -> ClauseElement:
    entry = field_map.get(cond.field)

    if not entry:
        raise ValidationError(message=f"Unsupported field: {cond.field}", details={"field": cond.field})
    
    if cond.operator not in entry["ops"]:
        raise ValidationError(message=f"Unsupported operator '{cond.operator}' for field '{cond.field}'", details={"field": cond.field, "operator": cond.operator, "supported_operators": list(entry["ops"])})
    
    expr = entry["expr"]

    value = cond.value

    if cond.operator == "eq":
        return expr == value

    if cond.operator == "in":
        if not isinstance(value, list):
            raise ValidationError(message=f"Value for 'in' operator must be a list", details={"field": cond.field, "operator": cond.operator})
        return expr.in_(value)
    
    if cond.operator == "contains":
        if not isinstance(value, str):
            raise ValidationError(message=f"Value for 'contains' operator must be a string", details={"field": cond.field, "operator": cond.operator})
        
        if isinstance(expr, tuple):
            return or_(*(e.ilike(f"%{value}%") for e in expr))
        else:
            return expr.ilike(f"%{value}%")
        
    if cond.operator == "gte":
        return expr >= value
    
    if cond.operator == "lte":
        return expr <= value
    
    raise ValidationError(f"Unsupported operator: {cond.operator} for field: {cond.field}; Supported operators: {entry['ops']}")

def compile_group(group: FilterGroup, field_map: dict) -> ClauseElement:
    children = group.and_ or group.or_

    compiled = [compile_node(child, field_map) for child in children]

    if group.and_ is not None:
        return and_(*compiled)
    
    return or_(*compiled)

def compile_node(node: FilterNode, field_map: dict) -> ClauseElement:
    if isinstance(node, Condition):
        return compile_condition(node, field_map)
    
    if isinstance(node, FilterGroup):
        return compile_group(node, field_map)
    
    raise ValidationError(f"Unknown FilterNode type : {type(node)}")
    

