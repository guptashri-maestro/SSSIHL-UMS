from fastapi import FastAPI
from app.routes.employees import router as employee_router
from app.core.logging_config import setup_logging, get_logger
from app.middleware.request_context import request_context_middleware
from fastapi.middleware.cors import CORSMiddleware
from app.core.errors.exception_handlers import register_exception_handlers
import os
import dotenv
from mangum import Mangum

dotenv.load_dotenv()

setup_logging()
log = get_logger("startup")
log.info("Logging active")

app = FastAPI()

app.middleware("http")(request_context_middleware)

register_exception_handlers(app)

is_dev = os.getenv("ENV", "dev") 

if is_dev:
    origins = ["*"]
else:
    origins = [
        "https://production-domain",
    ]

# origins = ["*"]  # Temporary for testing; adjust in production

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(employee_router)

handler = Mangum(app)


@app.get("/health")
async def health():
    log.info("Health check called")
    return {"status": "ok"}
