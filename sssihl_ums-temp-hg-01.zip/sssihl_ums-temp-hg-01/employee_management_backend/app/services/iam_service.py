import boto3
import os
import dotenv
from app.core.errors.common import AlreadyExistsError, ExternalServiceError, ValidationError
from pydantic import EmailStr
from typing import List
from botocore.exceptions import ClientError
from app.core.logging_config import get_logger
from botocore.client import BaseClient

log = get_logger("iam_service")

class IAMService:
    def __init__(self, cognito_client: BaseClient, user_pool_id: str):
        self.cognito_client = cognito_client
        self.cognito_user_pool_id = user_pool_id
    
    def check_cognito_user_exists_email(self, email: EmailStr) -> bool:
        res = self.cognito_client.list_users(
            UserPoolId=self.cognito_user_pool_id,
            Filter=f'email = "{email}"',
            Limit=1
        )

        return len(res.get("Users", [])) > 0
 
    async def admin_create_cognito_user(self, *, username: str, temporary_password: str, given_name: str, family_name: str, email: EmailStr, groups: List[str] | None = None) -> dict:
        log.debug(f"Creating Cognito user with details: username={username}, email={email}, given_name={given_name}, family_name={family_name}, groups={groups}")

        try:
            attributes = [
                {"Name": "given_name", "Value": given_name},
                {"Name": "family_name", "Value": family_name},
                {"Name": "email", "Value": email},
                {"Name": "email_verified", "Value": "true"},
            ]

            response = self.cognito_client.admin_create_user(
                UserPoolId=self.cognito_user_pool_id,
                Username=username,
                TemporaryPassword=temporary_password,
                UserAttributes=attributes,
                MessageAction="SUPPRESS",  # Do not send welcome email
            )

            # Optional: assign groups (roles)
            if groups:
                for group in groups:
                    self.cognito_client.admin_add_user_to_group(
                        UserPoolId=self.cognito_user_pool_id,
                        Username=username,
                        GroupName=group,
                    )

            user = response["User"]

            sub = ""
            for i in user["Attributes"]:
                if i["Name"] == "sub":
                    sub = i["Value"]

            log.info(f"USER CREATED IN COGNITO: {user}")

            return {
                "username": user["Username"],
                "status": user["UserStatus"],
                "sub": sub
            }
        except self.cognito_client.exceptions.UsernameExistsException:
            log.error(f"User creation failed: Username {username} already exists")
            raise AlreadyExistsError(entity="User", identifier=username, custom_message=f"User with username '{username}' and email '{email}' already exists in Cognito.")
        except ClientError as e:
            error_code = e.response['Error'].get("Code", "")
            error_message = e.response['Error'].get("Message", "")

            if error_code in ("InvalidParameterException", "InvalidPasswordException"):
                log.error(f"User creation failed due to invalid parameters: {error_message}", exc_info=True)
                raise ValidationError(message=f"Invalid user attributes or password", details={"aws_message": error_message})
            
            raise ExternalServiceError(service_name="Cognito", message="Failed to create user", details={"aws_code": error_code}) from e



















