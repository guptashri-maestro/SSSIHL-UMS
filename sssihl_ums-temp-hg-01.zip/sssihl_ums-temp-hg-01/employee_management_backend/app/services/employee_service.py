from sqlalchemy.ext.asyncio import AsyncSession
from app.schemas.EmployeeModels import EmployeeCreate, EmployeeResponse, EmployeeUpdate
from app.repositories.employee_repository import EmployeeRepository
from app.db.models.employee import Employee
from sqlalchemy import select
from app.db.filters.filter_compiler import compile_node
from app.core.pagination_helper import paginate_async
from fastapi import HTTPException, status
from app.core.logging_config import get_logger


from app.core.errors.base import AppError
from app.core.errors.common import ValidationError, AlreadyExistsError

from app.schemas.filters import Filter, Condition, FilterGroup
from app.dependencies.pagination_dependency import PaginationParams

log = get_logger("employee_service")

class EmployeeService:
    COMBINATION_KEY_FIELDS = ["first_name", "last_name", "employee_code", "cognito_sub", "official_email"]

    def __init__(self, employee_repository: EmployeeRepository):
        self.repo = employee_repository
    
    def build_combination_key_filter(self, data: dict) -> Filter:
        """
        Build a filter for combination key fields to check for duplicate records.
        
        Args:
            data: Dictionary containing employee data
            
        Returns:
            Filter object with AND conditions for all combination key fields
        """
        conditions = []
        
        for field in self.COMBINATION_KEY_FIELDS:
            if field in data and data[field] is not None:
                conditions.append(Condition(field=field, operator="eq", value=data[field]))
        
        if not conditions:
            raise ValidationError(message="No combination key fields found in data")
        
        filter_group = FilterGroup(and_=conditions)
        return Filter(root=filter_group)
    


    async def create_employee(self, actor_employee_code: str, data: dict) -> Employee:
        log.debug(f"Service: Creating employee {data.get('first_name')} {data.get('last_name')}")
            
        # First checking if an employee with the same combination key fields exists
        combination_key_filter = self.build_combination_key_filter(data)
        # exists = await self.repo.search(filter=combination_key_filter, limit=1, offset=0)

        # if exists:
        #     log.error("Service: Employee with same combination key fields already exists")
        #     raise AlreadyExistsError(entity="Employee", identifier="Combination Key Fields")
        
        try:    
            # Now try creating the employee
            employee = Employee(**data)

            employee = await self.repo.create_employee(employee, actor_employee_code)

            await self.repo.commit()
            
            log.debug(f"Service: Successfully created employee with code {employee.employee_code}")
            
            return employee
        except Exception as e:
            await self.repo.rollback()
            raise
    
    async def get_employee_by_code(self, employee_code: str) -> Employee:
        log.debug(f"Service: Fetching employee with code {employee_code}")
        
        employee = await self.repo.get_by_code(employee_code)
        
        log.debug(f"Service: Found employee with code {employee_code}: {employee}")
        
        return employee
        
        
        
    async def get_employee_code_by_sub(self, cognito_sub: str) -> dict:
        log.debug(f"Service: Fetching employee code for Cognito sub {cognito_sub}")

        result = await self.repo.get_employee_code_by_sub(cognito_sub)
        
        log.debug(f"Service: Found employee code for Cognito sub {cognito_sub}: {result}")

        return result



    async def search_employees(self, filter: Filter, pagination: PaginationParams) -> list[Employee]:
        log.debug(f"Service: Searching employees with limit={pagination.limit}, offset={pagination.offset}")
            
        results = await self.repo.search(filter=filter, limit=pagination.limit, offset=pagination.offset)
            
        log.debug(f"Service: Found {len(results)} employees")
        return results
        
        
    
    async def update_employee(self, employee_code: str, payload: EmployeeUpdate, actor_employee_code: str | None = None) -> None:
        try:
            updates = payload.model_dump(exclude_unset=True)
            
            if not updates:
                log.warning(f"Service: No fields provided to update for employee Code {employee_code}")
                raise ValidationError(message="No fields provided to update", details={})

            log.debug(f"Service: Updating employee Code {employee_code} with fields: {list(updates.keys())}, actor: {actor_employee_code}")
            employee = await self.repo.get_by_code(employee_code)

            await self.repo.update_employee(actor_employee_code, employee, updates)
            await self.repo.commit()
            await self.repo.refresh(employee)

            log.debug(f"Service: Successfully updated employee Code {employee_code}")
            
        except Exception:
            await self.repo.rollback()
            raise
            


    async def delete_employee(self, employee_code: str) -> None:
        try:
            log.debug(f"Service: Deleting employee Code {employee_code}")
            employee = await self.repo.get_by_code(employee_code)
            
            await self.repo.delete(employee)
            await self.repo.commit()
    
            log.debug(f"Service: Successfully deleted employee Code {employee_code}")
            
        except Exception:
            await self.repo.rollback()
            raise